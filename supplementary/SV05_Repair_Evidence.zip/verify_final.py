"""Read-only final evidence and OOXML verification; records results in qa/."""
from pathlib import Path
from zipfile import ZipFile
from lxml import etree as E
from collections import Counter
import json,hashlib,datetime,re
ROOT=Path(__file__).resolve().parent; QA=ROOT/'qa'
OLD=ROOT.parent/'ars_security_execution_2026_10_11/delivery/Research_Report_Chapters_1_to_6_v1_10_SecurityValidation_Highlighted_20261011.docx'
NEW=ROOT/'delivery/Research_Report_Chapters_1_to_6_v1_11_SV05_Fixed_Highlighted_20261012.docx'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
R='{http://schemas.openxmlformats.org/package/2006/relationships}'
def read(p):
    with ZipFile(p) as z:
        assert z.testzip() is None
        d={n:z.read(n) for n in z.namelist()}
        for n,b in d.items():
            if n.endswith(('.xml','.rels')):E.fromstring(b)
        return d
a=read(OLD);b=read(NEW)
assert sha(OLD)=='8272f409292acee709e5735530e8be778ba5bef73165c081ec5aaadb63728eff'
da=E.fromstring(a['word/document.xml']);db=E.fromstring(b['word/document.xml'])
ta=da.find(W+'body').findall(W+'tbl');tb=db.find(W+'body').findall(W+'tbl')
assert len(ta)==len(tb)==68
changed=[i for i,(x,y) in enumerate(zip(ta,tb)) if E.tostring(x)!=E.tostring(y)]
assert changed==[27,28,29,65],changed
media=[n for n in a if n.startswith('word/media/')]
assert set(media)=={n for n in b if n.startswith('word/media/')}
assert all(a[n]==b[n] for n in media)
def refs(d):
    ps=d.find(W+'body').findall(W+'p');txt=lambda x:''.join(t.text or '' for t in x.iter(W+'t'))
    i=next(i for i,p in enumerate(ps) if txt(p)=='REFERENCES')
    j=next(j for j in range(i+1,len(ps)) if txt(ps[j])=='APPENDIX A: LITERATURE SEARCH DETAILS')
    return [E.tostring(p) for p in ps[i+1:j]]
assert refs(da)==refs(db) and len(refs(db))==43
ca=E.fromstring(a['word/comments.xml']);cb=E.fromstring(b['word/comments.xml'])
old={c.get(W+'id'):E.tostring(c) for c in ca};new={c.get(W+'id'):E.tostring(c) for c in cb}
assert len(old)==370 and len(new)==375
assert all(new[k]==v for k,v in old.items())
def anchors(d):
    return {name:Counter(n.get(W+'id') for n in d.iter(W+name)) for name in ('commentRangeStart','commentRangeEnd','commentReference')}
oldanchors=anchors(da);newanchors=anchors(db)
for typ in oldanchors:
    assert all(newanchors[typ][k]==v for k,v in oldanchors[typ].items())
    assert all(newanchors[typ][k]==1 for k in set(new)-set(old))
relationships=E.fromstring(b['word/_rels/document.xml.rels'])
attachments=[x.get('Target') for x in relationships if x.get('Target','').lower().endswith('.zip')]
assert 'SV05_Repair_Evidence.zip' in attachments
text=' '.join(t.text or '' for t in db.iter(W+'t'))
assert not re.search(r'(?:11October|12October|the101-case|failure:59|tested12|That11)',text)
nav=load(QA/'Navigation_Verified.json');assert nav['all_match'] and nav['navigation_references']==174 and nav['pages']==134
word={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS','docx_sha256':sha(NEW),'source_sha256':sha(OLD),'all_xml_and_zip_crc':'PASS','tables':68,'changed_table_indices':changed,'unchanged_tables':64,'unchanged_reference_entries':43,'unchanged_media':len(media),'preserved_comments':370,'new_comments':5,'comment_anchors':'PASS','navigation_references_verified':174,'pages':134,'attachment_targets':attachments,'attachment_existence':'Pending final package verification'}
(QA/'Final_Word_Structural_QA.json').write_text(json.dumps(word,indent=2),encoding='utf-8')
seals={
 'source_base':[{k:v for k,v in x.items() if k in ('path','sha256')} for x in load(ROOT/'Original_Seal.json')['original_source_records'] if x['section']=='source'],
 'source_candidate':load(ROOT/'Final_Source_Seal.json')['source_files']}
counts={}
for directory,records in seals.items():
    actual={p.relative_to(ROOT/directory).as_posix() for p in (ROOT/directory).rglob('*') if p.is_file()}
    assert actual=={x['path'] for x in records}
    for x in records:assert sha(ROOT/directory/x['path'])==x['sha256']
    counts[directory]=len(records)
assert counts=={'source_base':215,'source_candidate':218}
receipts=[]
for p in sorted((ROOT/'runs').glob('*/Receipt.json')):
    q=load(p);assert q['status']=='FINISHED'
    assert sha(p.parent/'Executed_Script.py')==q['script_sha256']
    assert sha(p.parent/'Executed_Contract.json')==q['contract_sha256']
    assert (p.parent/'stdout.log').exists() and (p.parent/'stderr.log').exists()
    receipts.append({'run':p.parent.name,'exit_code':q['exit_code'],'executed_script_contract_identity':'PASS'})
assert len(receipts)==9
selected=[]
for name,n in [('candidate_retained',59),('production_final',11),('nonsequential_final',1)]:
    q=load(ROOT/'runs'/name/'results/Protocol_Results.json');assert len(q['cases'])==n
    assert Counter(c['status'] for c in q['cases'])=={'PASS':n}
    selected.append({'run':name,'pass':n,'actual_production_guard':q['actual_production_guard']})
q=load(ROOT/'runs/source_checks_final/results/Source_Checks.json');assert q['tests_run']==75 and q['success'] and q['failures']==q['errors']==q['skips']==0
assert sha(ROOT/'Acceptance_Contract.json')=='ad167328e3ebd66e191bccfe37b56a1245ef1c77a4af9016ebe2f9c45f826ea7'
assert sha(ROOT/'SV05_Repair.patch')==load(ROOT/'Final_Source_Seal.json')['final_patch_sha256']
evidence={'status':'PASS','source_counts':counts,'all_sealed_source_bytes':'PASS','retained_attempt_receipts':receipts,'selected_protocol_runs':selected,'selected_protocol_case_records':71,'unit_tests_separate_count':75,'original_contract_unchanged':True,'patch_matches_seal':True,'original_preservation_execution_record':load(ROOT/'Original_Preservation_Verified.json')}
(QA/'Final_Code_Evidence_QA.json').write_text(json.dumps(evidence,indent=2),encoding='utf-8')
pixels=load(QA/'Final_Pixel_Map.json')['pages']; records=[]
for rec in pixels:
    if 46<=rec['page']<=90:
        assert rec['identical_to_initial'] or rec['page'] in [81,82,83]
        records.append({'physical_page':rec['page'],'sha256':rec['sha256'],'verification':'Individual original-resolution review of final image' if rec['page'] in [81,82,83] else 'Pixel-identical to individually approved initial image'})
(QA/'Visual_Review_Delivery_46_90.json').write_text(json.dumps({'reviewer':'root','docx_sha256':sha(NEW),'pages':records,'status':'PASS','findings':'Joined dates corrected; no visible layout defects in the approved images.'},indent=2),encoding='utf-8')
print(json.dumps({'word':'PASS','code_evidence':'PASS','final_pages46_90':'PASS','source_counts':counts,'protocol_pass':71,'unit_tests':75,'new_comments':5}))
