"""Public routing fixtures through the real project guard; no EHR data."""
import copy, unittest
from flwr.common import Context, RecordDict, ConfigRecord, Message
from flwr.common.secure_aggregation.secaggplus_constants import Key, Stage, RECORD_KEY_CONFIGS, RECORD_KEY_STATE
from ehr_secagg.client_app import guarded_secaggplus_mod
from ehr_secagg.wire import check_collect_request

class RoutingGuardTests(unittest.TestCase):
    def fixture(self):
        record=ConfigRecord({Key.STAGE:Stage.COLLECT_MASKED_VECTORS,
            Key.SOURCE_LIST:[11,22],Key.CIPHERTEXT_LIST:[b'PUBLIC_A',b'PUBLIC_B']})
        context=Context(run_id=1,node_id=33,node_config={},run_config={},
            state=RecordDict({RECORD_KEY_STATE:ConfigRecord({'nid':33,'public_keys_dict:K':[11,22,33]})}))
        message=Message(content=RecordDict({RECORD_KEY_CONFIGS:record}),dst_node_id=33,message_type='train')
        return record,context,message

    def reject_without_mutation_or_fit(self, mutate):
        record,context,message=self.fixture();mutate(record,context)
        before_record=copy.deepcopy(dict(record));before_state=copy.deepcopy(dict(context.state.config_records))
        callbacks=[]
        def callback(*args):callbacks.append(1);raise AssertionError('Forbidden fit reached')
        with self.assertRaises(ValueError):guarded_secaggplus_mod(message,context,callback)
        self.assertEqual(callbacks,[])
        self.assertEqual(dict(record),before_record)
        self.assertEqual(dict(context.state.config_records),before_state)

    def test_missing_ciphertext_field(self):
        self.reject_without_mutation_or_fit(lambda r,c:r.pop(Key.CIPHERTEXT_LIST))
    def test_missing_source_field(self):
        self.reject_without_mutation_or_fit(lambda r,c:r.pop(Key.SOURCE_LIST))
    def test_ciphertext_wrong_container(self):
        self.reject_without_mutation_or_fit(lambda r,c:r.__setitem__(Key.CIPHERTEXT_LIST,b'PUBLIC'))
    def test_ciphertext_wrong_element_type(self):
        self.reject_without_mutation_or_fit(lambda r,c:r.__setitem__(Key.CIPHERTEXT_LIST,['PUBLIC','PUBLIC']))
    def test_source_wrong_container(self):
        self.reject_without_mutation_or_fit(lambda r,c:r.__setitem__(Key.SOURCE_LIST,11))
    def test_source_wrong_element_type(self):
        self.reject_without_mutation_or_fit(lambda r,c:r.__setitem__(Key.SOURCE_LIST,['11','22']))
    def test_missing_routing_state(self):
        self.reject_without_mutation_or_fit(lambda r,c:c.state.config_records.pop(RECORD_KEY_STATE))
    def test_missing_peer_ids(self):
        self.reject_without_mutation_or_fit(lambda r,c:c.state.config_records[RECORD_KEY_STATE].pop('public_keys_dict:K'))
    def test_duplicate_peer_ids(self):
        self.reject_without_mutation_or_fit(lambda r,c:c.state.config_records[RECORD_KEY_STATE].__setitem__('public_keys_dict:K',[11,11,33]))
    def test_incomplete_retained_cohort(self):
        self.reject_without_mutation_or_fit(lambda r,c:c.state.config_records[RECORD_KEY_STATE].__setitem__('public_keys_dict:K',[11,33]))
    def test_wrong_own_identity(self):
        self.reject_without_mutation_or_fit(lambda r,c:c.state.config_records[RECORD_KEY_STATE].__setitem__('nid',22))
    def test_boolean_peer_ids(self):
        self.reject_without_mutation_or_fit(lambda r,c:c.state.config_records[RECORD_KEY_STATE].__setitem__('public_keys_dict:K',[True,False,True]))
    def test_valid_metadata_preserved(self):
        r,c,m=self.fixture();before=dict(r);self.assertIsNone(check_collect_request(r,c));self.assertEqual(dict(r),before)
    def test_aligned_permutation_preserved(self):
        r,c,m=self.fixture();r[Key.SOURCE_LIST]=[22,11];r[Key.CIPHERTEXT_LIST]=[b'PUBLIC_B',b'PUBLIC_A']
        before=dict(r);self.assertIsNone(check_collect_request(r,c));self.assertEqual(dict(r),before)
    def test_nontraining_passthrough(self):
        _,c,_=self.fixture();m=Message(content=RecordDict(),dst_node_id=33,message_type='evaluate');calls=[]
        def callback(msg,ctx):calls.append((msg,ctx));return Message(content=RecordDict(),reply_to=msg)
        reply=guarded_secaggplus_mod(m,c,callback);self.assertFalse(reply.has_error());self.assertEqual(calls,[(m,c)])

if __name__=='__main__':unittest.main()
