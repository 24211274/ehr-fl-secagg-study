"""Apply only documented typography and new inventory-row formatting fixes."""
from pathlib import Path
from zipfile import ZipFile
from lxml import etree as E
import json, hashlib
ROOT=Path(__file__).resolve().parent
P=ROOT/'delivery/Research_Report_Chapters_1_to_6_v1_11_SV05_Fixed_Highlighted_20261012.docx'
W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
with ZipFile(P) as z: infos=z.infolist(); parts={i.filename:z.read(i.filename) for i in infos}
d=E.fromstring(parts['word/document.xml']); changes=[]
replacements={'That11 October':'That 11 October','tested12 October':'tested 12 October','That11October':'That 11 October','tested12October':'tested 12 October','11October':'11 October','12October':'12 October','failure:59':'failure: 59','the101-case':'the 101-case','an open input-validation finding':'a then-open input-validation finding'}
for t in d.iter(W+'t'):
    old=t.text or ''; new=old
    for a,b in replacements.items(): new=new.replace(a,b)
    if old!=new:
        t.text=new; changes.append({'old':old,'new':new,'type':'typography'})
t=d.find(W+'body').findall(W+'tbl')[65]
for r in t.findall(W+'tr')[-1].iter(W+'r'):
    pr=r.find(W+'rPr')
    if pr is None: pr=E.SubElement(r,W+'rPr')
    for name in ('sz','szCs'):
        node=pr.find(W+name)
        if node is None:node=E.SubElement(pr,W+name)
        node.set(W+'val','21')
changes.append({'type':'format','table':'D.12','row':'SV-05 repair and retest','font_points':10.5,'reason':'Match adjacent evidence rows; avoid stranded final filename character.'})
parts['word/document.xml']=E.tostring(d,xml_declaration=True,encoding='UTF-8',standalone=True)
with ZipFile(P,'w') as z:
    for i in infos:z.writestr(i,parts[i.filename])
(ROOT/'qa/Typography_Fixes.json').write_text(json.dumps({'changes':changes,'docx_sha256':hashlib.sha256(P.read_bytes()).hexdigest()},indent=2),encoding='utf-8')
print(json.dumps({'text_fixes':len(changes)-1,'inventory_row_font':10.5}))
