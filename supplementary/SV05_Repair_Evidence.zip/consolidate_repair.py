from pathlib import Path
import json,hashlib,csv,datetime,shutil
ROOT=Path(__file__).resolve().parent;OLD=ROOT.parent/'ars_security_execution_2026_10_11'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
rows=[];reports={}
for label in ['baseline','candidate_retained','production_final','nonsequential_final']:
    run=ROOT/'runs'/label;receipt=read(run/'Receipt.json');result=read(run/'results/Protocol_Results.json')
    script=run/'Executed_Script.py'
    if not script.exists():shutil.copy2(ROOT/'Original_Runner.py',script)
    contract=run/'Executed_Contract.json'
    if not contract.exists():shutil.copy2(ROOT/'Acceptance_Contract.json',contract)
    assert sha(script)==receipt['script_sha256'] and sha(contract)==receipt['contract_sha256']
    reports[label]={'counts':result['counts'],'receipt':receipt,'result_sha256':sha(run/'results/Protocol_Results.json')}
    for case in result['cases']:
        rows.append({'run':label,'id':case['id'],'status':case['status'],'exception':(case.get('exception') or {}).get('type'),
          'total_local_fit_callbacks':case.get('total_local_fit_callbacks'),'affected_node33_fit_callbacks':case.get('local_fit_callbacks',{}).get('33'),
          'aggregate_callbacks':case.get('aggregate_callbacks'),'stages':'|'.join(case.get('observed_stages',[])),
          'max_abs_average_error':case.get('max_abs_average_error'),'quantization_bound':case.get('quantization_bound')})
assert reports['baseline']['counts']['PASS']==58 and reports['baseline']['counts']['FAIL']==1
assert reports['candidate_retained']['counts']['PASS']==59
assert reports['production_final']['counts']['PASS']==11 and reports['nonsequential_final']['counts']['PASS']==1
base=read(ROOT/'runs/baseline/results/SV05_PARALLEL_LIST_LENGTH_MISMATCH.json')
fixed=read(ROOT/'runs/candidate_retained/results/SV05_PARALLEL_LIST_LENGTH_MISMATCH.json')
prod=read(ROOT/'runs/production_final/results/PROD_PARALLEL_LIST_LENGTH_MISMATCH.json')
assert base['exception']['type']=='KeyError' and base['aggregate_callbacks']==0
for r in [fixed,prod]:
    assert r['exception']['type']=='ValueError' and r['aggregate_callbacks']==0 and r['model_advancements']==0
    assert r['local_fit_callbacks']['33']==0 and 'unmask' not in r['observed_stages']
for label in ['production_final','nonsequential_final']:
    for r in read(ROOT/'runs'/label/'results/Protocol_Results.json')['cases']:
        assert r['actual_production_guard']
        if r['expectation']=='reject':assert r['early_rejection_assertions_passed']
        else:assert r['aggregate_callbacks']==1 and r['total_local_fit_callbacks']==3 and r['max_abs_average_error']<=r['quantization_bound']
unit=read(ROOT/'runs/source_checks_final/results/Source_Checks.json')
assert unit['success'] and unit['tests_run']==75 and unit['errors']==unit['failures']==unit['skips']==0
seal=read(ROOT/'Final_Source_Seal.json');candidate=ROOT/'source_candidate'
for r in seal['source_files']:assert sha(candidate/r['path'])==r['sha256']
oldseal=read(OLD/'Consolidated_Source_Seal.json');runtime=Path(r'\\wsl.localhost\Ubuntu-24.04\home\mai\ehr_me06_reproduction_20261011_v1')
for r in oldseal['source_files']:assert sha(runtime/r['section']/r['relative_path'])==r['sha256']
for r in oldseal['protected_runtime_files']:
    p=runtime/Path(r['path']).relative_to('/home/mai/ehr_me06_reproduction_20261011_v1');assert sha(p)==r['sha256']
summary={'material_passport':{'origin_skill':'academic-research-suite','origin_mode':'run/validate','origin_date':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'verification_status':'VERIFIED','version_label':'SV05-REPAIR-v1','repro_lock':{'source_manifest_sha256':seal['manifest_sha256'],'runtime':'retained ME06 Python3.12.3/Flower1.22.0+mai.prg7570.1','original_contract_sha256':sha(ROOT/'Acceptance_Contract.json')}},
 'outcome':'FIXED_WITHIN_TESTED_PROJECT_BOUNDARY','local_execution_date':'2026-10-12','timezone':'Asia/Singapore',
 'reports':reports,'selected_candidate_protocol_cases':71,'selected_candidate_protocol_pass':71,
 'production_guard_cases':12,'production_positive_controls':3,'production_negative_cases':9,
 'unit_regression_tests':unit,'baseline_failure':base['exception'],'candidate_failure_fixture':fixed['exception'],
 'target_fit_callbacks_after_repair':fixed['local_fit_callbacks']['33'],'total_fit_callbacks_observed_after_repair':fixed['total_local_fit_callbacks'],
 'original_source_preprocessing_files_verified':299,'protected_runtime_files_verified':4,'frozen_originals_changed':False,
 'candidate_source_files':len(seal['source_files']),'functional_production_files_changed':2,
 'historical_101_case_suite_rewritten_or_fully_rerun':False,'original_main_performance_tables_recalculated':False,
 'SV07_metadata_boundary_resolved':False,'formal_security_certification':False,
 'corrections_retained':['Harness_Correction_01.json','Source_Gate_Revision.json','Harness_Order_Correction.json']}
(ROOT/'Repair_Summary.json').write_text(json.dumps(summary,indent=2)+'\n')
with (ROOT/'Repair_Results.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
(ROOT/'Original_Preservation_Verified.json').write_text(json.dumps({'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_preprocessing_files':299,'protected_runtime_files':4,'zero_mismatches':True},indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ['outcome','selected_candidate_protocol_cases','production_guard_cases','production_positive_controls','production_negative_cases','target_fit_callbacks_after_repair','total_fit_callbacks_observed_after_repair']}))
