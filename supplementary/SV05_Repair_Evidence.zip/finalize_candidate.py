from pathlib import Path
import json,hashlib,ast,datetime,difflib,shutil
ROOT=Path(__file__).resolve().parent;base=ROOT/'source_base';candidate=ROOT/'source_candidate'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old_wire=base/'app/ehr_secagg/wire.py';new_wire=candidate/'app/ehr_secagg/wire.py'
text=old_wire.read_text();old_function=next(ast.get_source_segment(text,n) for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name=='check_masked_reply')
newtext=new_wire.read_text();assert old_function==next(ast.get_source_segment(newtext,n) for n in ast.parse(newtext).body if isinstance(n,ast.FunctionDef) and n.name=='check_masked_reply')
revision={'app/ehr_secagg/wire.py':{'predecessor_sha256':sha(old_wire),'successor_sha256':sha(new_wire),
 'reason':'SV-05 adds collection-request validation; prior response validator is unchanged.',
 'unchanged_functions':{'check_masked_reply':hashlib.sha256(old_function.encode()).hexdigest()}}}
(candidate/'reference/sv05_authorised_source_revision.json').write_text(json.dumps(revision,indent=2)+'\n')
shutil.copy2(ROOT/'SV05_Repair.patch',ROOT/'Initial_Production_Repair.patch')
patch=[];changes=[]
for p in sorted(candidate.rglob('*')):
    if not p.is_file() or p.name=='PACKAGE_SHA256SUMS.txt':continue
    rel=p.relative_to(candidate);q=base/rel
    if not q.exists() or p.read_bytes()!=q.read_bytes():
        patch.extend(difflib.unified_diff(q.read_text().splitlines(True) if q.exists() else [],p.read_text().splitlines(True),fromfile='a/'+rel.as_posix() if q.exists() else '/dev/null',tofile='b/'+rel.as_posix()))
        changes.append({'path':rel.as_posix(),'old_sha256':sha(q) if q.exists() else None,'new_sha256':sha(p)})
(ROOT/'SV05_Repair.patch').write_text(''.join(patch))
manifest=candidate/'PACKAGE_SHA256SUMS.txt'
manifest.write_text(''.join(sha(p)+'  '+p.relative_to(candidate).as_posix()+'\n' for p in sorted(candidate.rglob('*')) if p.is_file() and p!=manifest))
seal={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_files':[{'path':p.relative_to(candidate).as_posix(),'sha256':sha(p)} for p in sorted(candidate.rglob('*')) if p.is_file()],
 'changes':changes,'manifest_sha256':sha(manifest),'final_patch_sha256':sha(ROOT/'SV05_Repair.patch'),
 'scope':'Two production files; one new regression test; one versioned historical source gate adjustment and its reference record. Cryptographic wheel and all numerical/response functions preserved.'}
(ROOT/'Final_Source_Seal.json').write_text(json.dumps(seal,indent=2)+'\n')
print(json.dumps({'source_files':len(seal['source_files']),'changed_or_new':len(changes),'manifest_sha256':seal['manifest_sha256']}))
