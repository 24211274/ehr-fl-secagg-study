from pathlib import Path
import json,hashlib,shutil,datetime
ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'ars_security_execution_2026_10_11'
RUNTIME=Path(r'\\wsl.localhost\Ubuntu-24.04\home\mai\ehr_me06_reproduction_20261011_v1')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
seal=json.loads((OLD/'Consolidated_Source_Seal.json').read_text())
records=[]
for row in seal['source_files']:
    p=RUNTIME/row['section']/row['relative_path']
    assert sha(p)==row['sha256'],str(p)
    records.append(dict(section=row['section'],path=row['relative_path'],sha256=sha(p)))
for name in ['source_base','source_candidate']:
    target=ROOT/name
    assert not target.exists(),target
    for row in records:
        if row['section']!='source':continue
        src=RUNTIME/'source'/row['path'];dst=target/row['path']
        dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
    assert all(sha(target/r['path'])==r['sha256'] for r in records if r['section']=='source')
for name in ['Acceptance_Contract.json']:
    shutil.copy2(OLD/'protocol'/name,ROOT/name)
shutil.copy2(OLD/'protocol/attempt_02/Executed_Script.py',ROOT/'Original_Runner.py')
doc=OLD/'delivery/Research_Report_Chapters_1_to_6_v1_10_SecurityValidation_Highlighted_20261011.docx'
assert sha(doc)=='8272f409292acee709e5735530e8be778ba5bef73165c081ec5aaadb63728eff'
payload={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_source_records':records,
 'original_word':{'path':str(doc),'sha256':sha(doc)},'original_contract_sha256':sha(ROOT/'Acceptance_Contract.json'),
 'original_runner_sha256':sha(ROOT/'Original_Runner.py'),'scope':'Separate project copy. Frozen runtime, source, preprocessing, earlier results and manuscript preserved. No EHR training or inference.'}
(ROOT/'Original_Seal.json').write_text(json.dumps(payload,indent=2)+'\n')
print(json.dumps({'source_copied':sum(r['section']=='source' for r in records),'original_inventory_verified':len(records),'contract':payload['original_contract_sha256']}))
