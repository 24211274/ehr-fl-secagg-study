from pathlib import Path
from zipfile import ZipFile
from lxml import etree as E
from pypdf import PdfReader
import json, re, sys, unicodedata
ROOT=Path(__file__).resolve().parent
DOCX=ROOT/'delivery/Research_Report_Chapters_1_to_6_v1_11_SV05_Fixed_Highlighted_20261012.docx'
W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
NS={'w':W[1:-1]}
def text(el):return ''.join((n.text or '') if n.tag==W+'t' else '\t' for n in el.iter() if n.tag in (W+'t',W+'tab'))
def norm(s):return ''.join(c for c in unicodedata.normalize('NFKD',s).lower() if c.isalnum())
with ZipFile(DOCX) as z:infos=z.infolist();parts={i.filename:z.read(i.filename) for i in infos}
root=E.fromstring(parts['word/document.xml']);body=root.find(W+'body')
pages=[]
for i,p in enumerate(PdfReader(sys.argv[1]).pages,1):
    s=p.extract_text() or '';m=re.match(r'\s*(\d+)\s*\n',s);mr=re.match(r'\s*([ivxlcdm]+)\s*\n',s)
    pages.append({'physical_page':i,'printed_page':int(m.group(1)) if m else None,'printed_roman':mr.group(1) if mr else None,'text':s,'norm':norm(s)})
bodypages=[p for p in pages if p['printed_page'] is not None];mapping=[];failures=[]
for p in body:
    style=p.xpath('./w:pPr/w:pStyle/@w:val',namespaces=NS)
    if not style or style[0] not in ('TOCMain','TOCEntry'):continue
    s=text(p)
    if '\t' not in s:continue
    label,old=s.rsplit('\t',1)
    roman=bool(re.fullmatch('[ivxlcdm]+',old))
    if not old.isdecimal() and not roman:continue
    if roman:matches=[pg for pg in pages if pg['printed_roman'] and any(l.strip()==label for l in pg['text'].splitlines())]
    else:matches=[pg for pg in bodypages if (any(l.strip()=='REFERENCES' for l in pg['text'].splitlines()) if label=='REFERENCES' else norm(label) in pg['norm'])]
    if not matches:failures.append({'label':label,'old':old});continue
    pg=matches[0];new=pg['printed_roman'] if roman else str(pg['printed_page']);mapping.append({'label':label,'old':old,'new':new,'physical_page':pg['physical_page']})
    if '--verify' not in sys.argv and old!=new:
        last=p.xpath('.//w:tab',namespaces=NS)[-1];nodes=list(p.iter());tails=[n for n in nodes[nodes.index(last)+1:] if n.tag==W+'t'];assert ''.join(n.text or '' for n in tails)==old
        tails[0].text=new
        for n in tails[1:]:n.text=''
        r=tails[0].getparent();pr=r.find(W+'rPr')
        if pr is None:pr=E.Element(W+'rPr');r.insert(0,pr)
        hi=pr.find(W+'highlight')
        if hi is None:hi=E.SubElement(pr,W+'highlight')
        hi.set(W+'val','cyan')
assert not failures,failures
assert len(mapping)==174,len(mapping)
(ROOT/'qa/Page_Text.json').write_text(json.dumps([{k:v for k,v in p.items() if k!='norm'} for p in pages],ensure_ascii=False,indent=2),encoding='utf-8')
if '--verify' in sys.argv:
    assert all(m['old']==m['new'] for m in mapping),[m for m in mapping if m['old']!=m['new']]
    (ROOT/'qa/Navigation_Verified.json').write_text(json.dumps({'navigation_references':len(mapping),'all_match':True,'pages':len(pages)},indent=2),encoding='utf-8')
else:
    (ROOT/'qa/Pagination_Changes.json').write_text(json.dumps(mapping,ensure_ascii=False,indent=2),encoding='utf-8')
    parts['word/document.xml']=E.tostring(root,xml_declaration=True,encoding='UTF-8',standalone=True)
    with ZipFile(DOCX,'w') as z:
        for info in infos:z.writestr(info,parts[info.filename])
print(json.dumps({'navigation_references':len(mapping),'changed':sum(m['old']!=m['new'] for m in mapping),'pages':len(pages),'verified':'--verify' in sys.argv}))
