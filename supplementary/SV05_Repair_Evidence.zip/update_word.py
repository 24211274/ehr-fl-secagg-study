"""Preserve the prior OOXML package, scientific tables and historical comments."""
from pathlib import Path
from zipfile import ZipFile
from copy import deepcopy
from lxml import etree as E
import hashlib,json,datetime,shutil
ROOT=Path(__file__).resolve().parent;OLD=ROOT.parent/'ars_security_execution_2026_10_11'
SRC=OLD/'delivery/Research_Report_Chapters_1_to_6_v1_10_SecurityValidation_Highlighted_20261011.docx'
OUT=ROOT/'delivery/Research_Report_Chapters_1_to_6_v1_11_SV05_Fixed_Highlighted_20261012.docx'
OUT.parent.mkdir(exist_ok=True);(ROOT/'qa').mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(SRC)=='8272f409292acee709e5735530e8be778ba5bef73165c081ec5aaadb63728eff'
summary=json.loads((ROOT/'Repair_Summary.json').read_text());assert summary['selected_candidate_protocol_pass']==71
with ZipFile(SRC) as z:infos=z.infolist();parts={i.filename:z.read(i.filename) for i in infos}
W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}';XML='{http://www.w3.org/XML/1998/namespace}'
REL='{http://schemas.openxmlformats.org/package/2006/relationships}';R='{http://schemas.openxmlformats.org/officeDocument/2006/relationships}'
NS={'w':W[1:-1]};doc=E.fromstring(parts['word/document.xml']);body=doc.find(W+'body')
ps=[p for p in body if p.tag==W+'p'];tables=[t for t in body if t.tag==W+'tbl']
comments=E.fromstring(parts['word/comments.xml']);original_comment_count=len(comments);cid=max(int(c.get(W+'id')) for c in comments)+1;ledger=[]
def text(el):return ''.join(n.text or '' for n in el.iter(W+'t'))
def run(s,color):
    r=E.Element(W+'r');pr=E.SubElement(r,W+'rPr');E.SubElement(pr,W+'rFonts',{W+'ascii':'Times New Roman',W+'hAnsi':'Times New Roman'})
    E.SubElement(pr,W+'highlight',{W+'val':color});E.SubElement(pr,W+'lang',{W+'val':'en-GB'})
    E.SubElement(r,W+'t',{XML+'space':'preserve'}).text=s;return r
def replace(p,needle,replacement,color='yellow'):
    before=text(p);assert before.count(needle)==1,(needle,before)
    start=before.index(needle);end=start+len(needle);at=0;nodes=list(p.iter(W+'t'))
    for t in nodes:
        value=t.text or '';lo=at;at+=len(value)
        if lo<=start<at:
            r=t.getparent();assert r.tag==W+'r' and len(r.findall(W+'t'))==1
            tail=deepcopy(r);tail.find(W+'t').text=value[start-lo:];tail.find(W+'t').set(XML+'space','preserve')
            t.text=value[:start-lo];t.set(XML+'space','preserve');parent=r.getparent();index=parent.index(r)
            parent.insert(index+1,run(replacement,color));parent.insert(index+2,tail)
            remaining=end-start
            for target in [tail.find(W+'t')]+nodes[nodes.index(t)+1:]:
                val=target.text or '';cut=min(remaining,len(val));target.text=val[cut:];target.set(XML+'space','preserve');remaining-=cut
                if not remaining:break
            assert remaining==0;break
    assert text(p)==before[:start]+replacement+before[end:]
    ledger.append({'operation':'revision','old':before,'new':text(p),'color':color})
def revise(i,new,color='yellow'):replace(ps[i],text(ps[i]),new,color)
def comment(p,note):
    global cid
    ident=str(cid);cid+=1
    c=E.SubElement(comments,W+'comment',{W+'id':ident,W+'author':'Research audit SV05 repair',W+'date':datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00','Z')})
    cp=E.SubElement(c,W+'p');cr=E.SubElement(cp,W+'r');E.SubElement(cr,W+'t').text=note
    p.insert(1 if p.find(W+'pPr') is not None else 0,E.Element(W+'commentRangeStart',{W+'id':ident}))
    p.append(E.Element(W+'commentRangeEnd',{W+'id':ident}));rr=E.SubElement(p,W+'r');E.SubElement(rr,W+'commentReference',{W+'id':ident})
def add_after(p,s,color='green'):
    new=E.Element(W+'p');pr=E.SubElement(new,W+'pPr');E.SubElement(pr,W+'pStyle',{W+'val':'BodyText'});new.append(run(s,color))
    body.insert(body.index(p)+1,new);ledger.append({'operation':'addition','text':s,'color':color});return new
def cell(t,r,c):return tables[t].findall(W+'tr')[r].findall(W+'tc')[c]
def cell_replace(t,r,c,needle,replacement,color='yellow'):
    tc=cell(t,r,c);p=next(p for p in tc.iter(W+'p') if needle in text(p));replace(p,needle,replacement,color)

replace(ps[32],'A later bounded security-validation suite recorded 99 passing cases, one unmet controlled-rejection criterion and one diagnostic-metadata boundary; it did not certify security.',
 'The bounded security audit initially retained one rejection failure and a metadata boundary. A subsequent patch and targeted retest resolved SV-05; the metadata boundary remains.')
replace(ps[36],'Pengujian keselamatan terhad kemudian merekodkan 99 PASS, 1 FAIL bagi penolakan terkawal dan 1 batas metadata; keselamatan tidak diperakui.',
 'Audit keselamatan terhad merekodkan satu kegagalan penolakan dan batas metadata; pembaikan serta ujian semula menyelesaikan SV-05, tetapi batas metadata kekal.')
comment(ps[32],'12 October 2026 local time: separate project copy repaired and retested. Historical101-case audit remains99PASS/1FAIL/1boundary. See4.11/D.9 and SV05_Repair_Evidence.zip. Old dated comments describe their original revision.')
comment(ps[36],'Malay security summary aligned to actual subsequent SV05 repair; no security certification or new benchmark performance claim.')
new=add_after(ps[365],'SV-05 remediation and retesting (12 October 2026). A separate project copy added collection-request validation before the upstream fit callback. It requires equal ciphertext/source-list lengths and each retained external peer exactly once, while accepting aligned permutations. The original 59-case contract and mutation were retained. Its toy guard invoked the same new project validator. Twelve additional cases exercised the actual project guard with public arrays and configuration-valid acknowledgement fields. These were implementation fixtures, without EHR optimisation, network deployment or changes to the installed cryptographic helper.')
comment(new,'Source changes are client_app.py and wire.py; versioned source gate and regression tests accompany them. Frozen source/runtime and historical campaign preserved. Native guard controls are separately identified from toy-guard replay.')
replace(ps[516],'The selected result set contains 101 case records:','The historical selected result set contains 101 case records:','cyan')
revise(519,'The historical failure was SV05_PARALLEL_LIST_LENGTH_MISMATCH. Removing one source ID while retaining its ciphertext list caused KeyError at UNMASK after three toy fit callbacks; the recorded exception message was 22. No aggregate callback was accepted and the toy aggregate state did not advance. The sealed criterion required controlled ValueError or RuntimeError rejection. A baseline replay reproduced the failure. In the separately versioned repair, the unchanged malformed-list fixture raised ValueError during collection, before the affected client fit callback and before UNMASK, with zero accepted aggregates. This closes the named finding for the repaired copy and tested inputs; the original FAIL record is retained.')
new=add_after(ps[519],'The repaired copy passed all 59 cases under the original contract, including all seven SV-05 fixtures. The 12 additional production-guard cases also passed: three complete controls (normal order, reversed aligned pairs and nonsequential node IDs) and nine malformed-routing cases. Each positive control completed four stages and one aggregate within its numerical bound. The negative cases rejected before the affected client fit and accepted no aggregate. The observed total fit count for the original malformed-list fixture was zero; earlier clients may still fit under a different request order. Separately, 75 unit/regression tests passed without failures, errors or skips. These counts do not represent a rerun of the complete historical 101-case suite.')
comment(new,'Evidence: candidate_retained59PASS; production_final11PASS + nonsequential_final1PASS; source_checks_final75 tests. Supplementary early-rejection criteria explicitly checked; ordering correction retained. No aggregation or detector performance claims added.')
replace(ps[521],'Both protocol attempts are retained.','Both 11 October protocol attempts are retained.','cyan')
add_after(ps[521],'The new baseline, candidate and regression attempts, executed programs, contracts, timestamps, exit codes and stdout/stderr are retained in SV05_Repair_Evidence.zip. The initial unit discovery error and predecessor whole-file equality failure are disclosed, together with their corrections. The successor source gate pins the exact repaired file and verifies that the previous response-validator function remains unchanged. A supplementary callback-order assumption was corrected before the selected production rerun; the original 59-case rejection criterion was unchanged. All 299 original source/preprocessing entries and four protected runtime/build files still matched their preserved hashes.','cyan')
replace(ps[535],'It recorded an unexpected late error for unequal routing-list lengths, and a diagnostic-metadata boundary.',
 'The 11October audit recorded a late malformed-list error and a diagnostic-metadata boundary. The 12October repair resolved the named error in the separate tested copy; the metadata boundary remains.')
replace(ps[577],'It leaves the SV-05 controlled-rejection finding open and assumes that permitted diagnostic metadata is public and trusted.',
 'The subsequent repair and targeted retest closed the named SV-05 finding in a separate source version. Permitted diagnostic metadata is still assumed public and trusted.')
revise(597,'The 11October audit completed seven bounded groups, retaining 99 PASS, one controlled-rejection FAIL and one diagnostic-metadata boundary among 101 selected records (Section 4.11; Appendix D.9). The 12October source revision resolved the named SV-05 failure:59 original-contract cases, 12 additional production-guard cases and 75 unit/regression tests passed in their selected runs. This supports the specific input-validation correction while preserving the historical failure and metadata limitation. It does not establish quantified privacy protection, comprehensive replay resistance or security against the shared-host administrator. Original RQ utility and cost conclusions remain unchanged.')
replace(ps[769],'Execution status:','Historical execution status (11 October 2026):','cyan')
revise(775,'SV-05 remediation status (12 October 2026): FIXED WITHIN THE TESTED PROJECT BOUNDARY. The original unequal-list fixture and its FAIL records remain preserved. The repaired project copy validates lengths and the complete unique external-peer set before upstream fitting. The unchanged fixture now raises ValueError during COLLECT, with no affected-client fit, no UNMASK and no accepted aggregate. The separate production-guard malformed-list case confirms the same behaviour. The original benchmark source was not overwritten, and no evidence shows that its training contained this malformed request. The repair is a project policy guard, not a change to the cryptographic wheel.','cyan')
new=add_after(ps[775],'Retest accounting. The original-contract replay recorded 59 PASS, covering SV-02 to SV-05. The production-guard extension recorded 12 PASS: 3 positive controls and 9 negative cases. The positives included reversed aligned pairs and different node identities; their aggregate errors met the fixture-specific bounds. The 75 passing unit/regression checks include 15 new routing-guard tests and 60 existing measurement-contract tests. They are separate counting units. SV-01/SV-06/SV-07 were not rerun in full on this source revision, so the101-case historical ledger is not recast as a newly executed all-pass suite.')
comment(new,'Repair_Summary.json, Repair_Results.csv and exact run receipts. Original 101-case status and 75 unit checks have distinct denominators. Missing network/attack scope in Table D.13 is unchanged.')
replace(ps[779],'with the retained SV-05 finding and metadata limitation;',
 'with the historical SV-05 finding, its separately verified repair and the continuing metadata limitation;')
revise(790,'The later security-validation evidence supports only the named implementation observations in Section 4.11. The historical controlled-rejection failure is retained, and its separately versioned SV-05 repair passed the targeted retest. The diagnostic-metadata boundary and untested scope remain. Neither the historical suite nor the repair supports a comprehensive-protection statement, quantified privacy assurance or independent production certification.')
replace(ps[792],'Neither the source implementation nor the original predictive/system-cost tables were changed by that suite.',
 'That11October suite changed neither the source nor the original predictive/system-cost tables. The 12October repair changed a separate source copy; it did not retrain the main detector or recalculate those tables. The fixed-copy results therefore support input validation, not new performance or cost estimates.')
attachment=add_after(ps[780],'SV05_Repair_Evidence.zip accompanies the 12October repair. It contains the base and repaired source snapshots, complete patch, source manifests, retained attempts and logs, per-case results, unit-test outcomes and correction records. Receipt commands identify the retained runtime and new output directories needed for repetition. This is a source-and-evidence package, not a new installation certificate. Historical comments describe the earlier versions and remain alongside the new dated repair comments.','cyan')
add_after(ps[794],'Highlight key for the 12October SV-05 update: green marks added repair methods and executed results; yellow marks revised interpretation and limitations; cyan marks status, provenance, attachment links and corrected navigation. Earlier highlights and dated comments are preserved.','cyan')

cell_replace(27,0,1,'Selected outcome','11 Oct baseline / SV-05 retest','cyan')
cell_replace(27,5,1,'6 PASS; 1 FAIL','11 Oct: 6 PASS; 1 FAIL. 12 Oct: 7 PASS.','cyan')
cell_replace(27,5,2,'Unequal ciphertext/source-list lengths caused late KeyError at UNMASK. Zero aggregate accepted, but the required controlled rejection was not achieved.',
 'Historical late KeyError retained. After repair, the unchanged fixture was rejected by ValueError during collection, before affected-client fit and any accepted aggregate. Separate native-guard controls passed.')
cell_replace(28,2,1,'one controlled-rejection criterion remains unmet.','the historical controlled-rejection failure was resolved in the separately tested12October source copy.')
cell_replace(29,3,1,'(one FAIL; metadata boundary)','(historical FAIL, verified SV-05 repair; metadata boundary)')
cell_replace(29,3,2,'the later suite retained one unmet controlled-rejection criterion and a metadata boundary.',
 'the historical suite retained one rejection failure, resolved by the separate targeted repair, and a continuing metadata boundary.')
# Extend the evidence inventory with a concise fourth-category record.
row=deepcopy(tables[65].findall(W+'tr')[-1])
for tc,value in zip(row.findall(W+'tc'),['SV-05 repair and retest','SV05_Repair_Evidence.zip','Base/repaired sources; patch and manifests; runs/ receipts, executed scripts, contracts, stdout/stderr and results; Repair_Summary/Results; correction records.']):
    p=tc.find(W+'p');pr=deepcopy(p.find(W+'pPr'));tc[:]=[x for x in tc if x.tag==W+'tcPr'];new=E.SubElement(tc,W+'p')
    if pr is not None:new.append(pr)
    new.append(run(value,'cyan'))
tables[65].append(row);ledger.append({'operation':'evidence_inventory_row','color':'cyan'})
rels=E.fromstring(parts['word/_rels/document.xml.rels']);rid='rIdSV05RepairEvidence'
assert not any(x.get('Id')==rid for x in rels)
E.SubElement(rels,REL+'Relationship',{'Id':rid,'Type':R[1:-1]+'/hyperlink','Target':'SV05_Repair_Evidence.zip','TargetMode':'External'})
link=E.SubElement(attachment,W+'hyperlink',{R+'id':rid});link.append(run(' Open repair evidence package.','cyan'))
parts['word/document.xml']=E.tostring(doc,xml_declaration=True,encoding='UTF-8',standalone=True)
parts['word/comments.xml']=E.tostring(comments,xml_declaration=True,encoding='UTF-8',standalone=True)
parts['word/_rels/document.xml.rels']=E.tostring(rels,xml_declaration=True,encoding='UTF-8',standalone=True)
core=E.fromstring(parts['docProps/core.xml']);ns={'cp':'http://schemas.openxmlformats.org/package/2006/metadata/core-properties','dcterms':'http://purl.org/dc/terms/'}
modified=core.find('dcterms:modified',ns);modified.text=datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds').replace('+00:00','Z')
revision=core.find('cp:revision',ns)
if revision is not None:revision.text=str(int(revision.text or 0)+1)
parts['docProps/core.xml']=E.tostring(core,xml_declaration=True,encoding='UTF-8',standalone=True)
with ZipFile(OUT,'w') as z:
    for info in infos:z.writestr(info,parts[info.filename])
for name in ['Security_Validation_Evidence.zip','ME06_Evidence.zip']:shutil.copy2(OLD/'delivery'/name,OUT.parent/name)
(ROOT/'Word_Change_Ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
(ROOT/'qa/Initial_Word_Integrity.json').write_text(json.dumps({'source_sha256':sha(SRC),'output_sha256':sha(OUT),'changes':len(ledger),'comments_preserved':original_comment_count,'new_comments':len(comments)-original_comment_count,'new_tables':0,'new_inventory_rows':1},indent=2)+'\n')
print(json.dumps({'output':str(OUT),'changes':len(ledger),'new_comments':len(comments)-original_comment_count,'sha256':sha(OUT)}))
