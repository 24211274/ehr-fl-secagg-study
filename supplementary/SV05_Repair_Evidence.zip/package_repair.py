"""Package the SV05 repair after final QA; never edit Word or source files.

Run explicitly, only after the parent task has completed final QA:
    python package_repair.py package --qa-ready
    python package_repair.py delivery-manifest

The commands are separate so the delivery manifest records the final Word and
archive bytes. Full source snapshots include their inherited decision-record
DOCX; QA and delivery Word/PDF/PNG artifacts are excluded from the evidence ZIP.
"""

from __future__ import annotations

import argparse
import collections
import datetime as dt
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import tempfile
import zipfile


ROOT = Path(__file__).resolve().parent
EXPECTED_ROOT_NAME = "ars_sv05_fix_2026_10_12"
SOURCE_COUNTS = {"source_base": 215, "source_candidate": 218}
REQUIRED_RUNS = {
    "baseline", "candidate_retained", "production", "production_final",
    "nonsequential", "nonsequential_final", "source_checks",
    "source_checks_attempt02", "source_checks_final",
}
ROOT_SUFFIXES = {
    ".json", ".md", ".py", ".patch", ".csv", ".txt", ".sh", ".ps1",
    ".diff", ".log", ".toml", ".yaml", ".yml",
}
QA_SUFFIXES = {".json", ".md"}
WORD_NAME = (
    "Research_Report_Chapters_1_to_6_v1_11_"
    "SV05_Fixed_Highlighted_20261012.docx"
)
ZIP_NAME = "SV05_Repair_Evidence.zip"
REPORT_NAME = "SV05_Repair_Report_AR.md"
VERIFICATION_NAME = "SV05_Repair_Package_Verification.json"
DELIVERY_MANIFEST_NAME = "Delivery_Manifest.json"
REQUIRED_ROOT_FILES = {
    "README_AR.md", "Repair_Summary.json", "Repair_Results.csv",
    "Original_Seal.json", "Final_Source_Seal.json", "SV05_Repair.patch",
    "Acceptance_Contract.json", "Production_Contract_v2.json",
    "Nonsequential_Contract_v2.json", "Source_Checks_Contract.json",
    "Harness_Correction_01.json", "Source_Gate_Revision.json",
    "Harness_Order_Correction.json", "Original_Preservation_Verified.json",
    "package_repair.py",
}


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical_json(value: object) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def checked_root() -> Path:
    if ROOT.name != EXPECTED_ROOT_NAME or not ROOT.is_dir():
        raise RuntimeError(f"Unexpected packaging root: {ROOT}")
    return ROOT


def inside_root(path: Path) -> Path:
    resolved = path.resolve(strict=True)
    if not resolved.is_relative_to(checked_root()):
        raise RuntimeError(f"Path escapes the repair root: {path}")
    return resolved


def regular_files(directory: Path) -> list[Path]:
    inside_root(directory)
    files = []
    for path in sorted(directory.rglob("*")):
        if path.is_symlink():
            raise RuntimeError(f"Symlinks are not allowed in evidence: {path}")
        if path.is_file():
            inside_root(path)
            files.append(path)
    return files


def atomic_write(path: Path, data: bytes) -> None:
    # Only generated delivery files are written; parent paths are verified.
    delivery = (checked_root() / "delivery").resolve(strict=True)
    if path.parent.resolve(strict=True) != delivery:
        raise RuntimeError(f"Output must be directly inside delivery: {path}")
    descriptor, temporary = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=delivery
    )
    temporary_path = Path(temporary)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(data)
        os.replace(temporary_path, path)
    finally:
        if temporary_path.exists():
            temporary_path.unlink()


def validate_source_seals(source_files: dict[str, list[Path]]) -> None:
    base_seal = json.loads((ROOT / "Original_Seal.json").read_text(encoding="utf-8"))
    candidate_seal = json.loads(
        (ROOT / "Final_Source_Seal.json").read_text(encoding="utf-8")
    )
    expected = {
        "source_base": {
            item["path"]: item["sha256"]
            for item in base_seal["original_source_records"]
            if item["section"] == "source"
        },
        "source_candidate": {
            item["path"]: item["sha256"] for item in candidate_seal["source_files"]
        },
    }
    for scope, files in source_files.items():
        actual = {path.relative_to(ROOT / scope).as_posix(): path for path in files}
        if len(actual) != SOURCE_COUNTS[scope]:
            raise RuntimeError(
                f"{scope} has {len(actual)} files; expected {SOURCE_COUNTS[scope]}"
            )
        if set(actual) != set(expected[scope]):
            raise RuntimeError(f"{scope} file inventory differs from its final seal")
        for relative, path in actual.items():
            if sha256_file(path) != expected[scope][relative]:
                raise RuntimeError(f"Sealed source bytes changed: {scope}/{relative}")
    if sha256_file(ROOT / "SV05_Repair.patch") != candidate_seal["final_patch_sha256"]:
        raise RuntimeError("Final repair patch differs from Final_Source_Seal.json")


def select_payload() -> tuple[list[Path], dict[str, object]]:
    checked_root()
    source_files = {
        scope: regular_files(ROOT / scope) for scope in SOURCE_COUNTS
    }
    validate_source_seals(source_files)
    run_directory = ROOT / "runs"
    present_runs = {path.name for path in run_directory.iterdir() if path.is_dir()}
    if not REQUIRED_RUNS.issubset(present_runs):
        raise RuntimeError(f"Missing retained run folders: {sorted(REQUIRED_RUNS - present_runs)}")
    runs = regular_files(run_directory)
    root_files = [
        path for path in sorted(ROOT.iterdir())
        if path.is_file()
        and (path.suffix.lower() in ROOT_SUFFIXES or path.name == "README")
    ]
    if not REQUIRED_ROOT_FILES.issubset({path.name for path in root_files}):
        missing = REQUIRED_ROOT_FILES - {path.name for path in root_files}
        raise RuntimeError(f"Missing required root evidence: {sorted(missing)}")
    for path in root_files:
        if path.is_symlink():
            raise RuntimeError(f"Root evidence must not be a symlink: {path}")
        inside_root(path)
    all_qa_files = regular_files(ROOT / "qa")
    qa = [path for path in all_qa_files if path.suffix.lower() in QA_SUFFIXES]
    payload = sorted(
        source_files["source_base"] + source_files["source_candidate"]
        + runs + root_files + qa,
        key=lambda path: path.relative_to(ROOT).as_posix(),
    )
    names = [path.relative_to(ROOT).as_posix() for path in payload]
    if len(names) != len(set(names)):
        raise RuntimeError("Duplicate payload path")
    if any(name.startswith("delivery/") for name in names):
        raise RuntimeError("Delivery artifacts must not enter the evidence ZIP")
    exceptions = [
        name for name in names
        if name.startswith(("source_base/", "source_candidate/"))
        and PurePosixPath(name).suffix.lower() in {".docx", ".doc", ".pdf", ".png"}
    ]
    policy = {
        "source_base": "Complete sealed source snapshot, 215 files",
        "source_candidate": "Complete final sealed source snapshot, 218 files",
        "runs": "Every file in every retained run folder, including unsuccessful attempts",
        "root": "Root contracts, seals, patches, CSVs, receipts, readmes and helper scripts",
        "qa": "Only JSON and Markdown audit records, recursively",
        "excluded": "The complete delivery directory and QA image/PDF/Word artifacts",
        "inherited_source_document_exceptions": exceptions,
        "qa_excluded_extensions": dict(collections.Counter(
            path.suffix.lower() for path in all_qa_files if path not in qa
        )),
        "counts": {
            "source_base": len(source_files["source_base"]),
            "source_candidate": len(source_files["source_candidate"]),
            "runs": len(runs), "root": len(root_files), "qa": len(qa),
            "payload_files": len(payload),
        },
        "run_folders": sorted(present_runs),
    }
    return payload, policy


def verify_archive(path: Path) -> dict[str, object]:
    with zipfile.ZipFile(path, "r") as archive:
        entries = archive.infolist()
        names = [entry.filename for entry in entries]
        if len(names) != len(set(names)):
            raise RuntimeError("ZIP contains duplicate entry names")
        if any(entry.is_dir() for entry in entries):
            raise RuntimeError("ZIP must contain files only")
        for name in names:
            posix = PurePosixPath(name)
            if posix.is_absolute() or ".." in posix.parts or "\\" in name:
                raise RuntimeError(f"Unsafe ZIP path: {name}")
        bad_crc = archive.testzip()
        if bad_crc is not None:
            raise RuntimeError(f"ZIP CRC verification failed: {bad_crc}")
        manifest = json.loads(archive.read("MANIFEST.json"))
        records = manifest["payloads"]
        expected_names = {record["path"] for record in records} | {"MANIFEST.json"}
        if set(names) != expected_names or len(records) + 1 != len(names):
            raise RuntimeError("ZIP entry inventory differs from MANIFEST.json")
        for record in records:
            data = archive.read(record["path"])
            if len(data) != record["bytes"]:
                raise RuntimeError(f"ZIP size mismatch: {record['path']}")
            if hashlib.sha256(data).hexdigest() != record["sha256"]:
                raise RuntimeError(f"ZIP SHA-256 mismatch: {record['path']}")
        return {
            "crc_test": "PASS", "entry_inventory": "PASS",
            "every_payload_size_and_sha256": "PASS",
            "verified_payloads": len(records), "verified_zip_entries": len(names),
            "manifest_sha256": hashlib.sha256(archive.read("MANIFEST.json")).hexdigest(),
            "selection": manifest["selection"],
        }


def package(qa_ready: bool) -> None:
    if not qa_ready:
        raise RuntimeError("Run package only after final QA, with --qa-ready")
    checked_root()
    delivery = ROOT / "delivery"
    delivery.mkdir(exist_ok=True)
    inside_root(delivery)
    if not (delivery / WORD_NAME).is_file():
        raise RuntimeError("Final Word deliverable is missing")
    payload, selection = select_payload()
    records = [
        {"path": path.relative_to(ROOT).as_posix(),
         "bytes": path.stat().st_size, "sha256": sha256_file(path)}
        for path in payload
    ]
    manifest = {
        "schema_version": 1, "package": ZIP_NAME, "created_utc": utc_now(),
        "selection": selection, "payloads": records,
        "manifest_self_hash_note": (
            "MANIFEST.json is the inventory, not a payload. Its SHA-256 is recorded "
            "in the separate delivery verification record and delivery manifest."
        ),
    }
    descriptor, temporary = tempfile.mkstemp(
        prefix=".SV05_Repair_Evidence.", suffix=".zip.tmp", dir=delivery
    )
    os.close(descriptor)
    temporary_path = Path(temporary)
    try:
        with zipfile.ZipFile(
            temporary_path, "w", compression=zipfile.ZIP_DEFLATED,
            compresslevel=6, allowZip64=True,
        ) as archive:
            for source, record in zip(payload, records):
                archive.write(source, arcname=record["path"])
            archive.writestr("MANIFEST.json", canonical_json(manifest))
        verification = verify_archive(temporary_path)
        # A changed file during ZIP creation fails the archived-byte hash checks.
        readme_bytes = (ROOT / "README_AR.md").read_bytes()
        readme_record = next(item for item in records if item["path"] == "README_AR.md")
        if hashlib.sha256(readme_bytes).hexdigest() != readme_record["sha256"]:
            raise RuntimeError("README changed during packaging; rerun after it is stable")
        atomic_write(delivery / REPORT_NAME, readme_bytes)
        os.replace(temporary_path, delivery / ZIP_NAME)
        verification.update({
            "created_utc": utc_now(), "archive": ZIP_NAME,
            "archive_bytes": (delivery / ZIP_NAME).stat().st_size,
            "archive_sha256": sha256_file(delivery / ZIP_NAME),
            "arabic_report": REPORT_NAME,
            "arabic_report_matches_root_readme": True,
        })
        atomic_write(delivery / VERIFICATION_NAME, canonical_json(verification))
        print(json.dumps(verification, ensure_ascii=False, indent=2))
        print("Package verified. Run delivery-manifest separately after final deliverables are stable.")
    finally:
        if temporary_path.exists():
            temporary_path.unlink()


def delivery_manifest() -> None:
    checked_root()
    delivery = ROOT / "delivery"
    inside_root(delivery)
    required = {
        WORD_NAME, ZIP_NAME, REPORT_NAME, VERIFICATION_NAME,
        "Security_Validation_Evidence.zip", "ME06_Evidence.zip",
    }
    missing = [name for name in sorted(required) if not (delivery / name).is_file()]
    if missing:
        raise RuntimeError(f"Missing final delivery files: {missing}")
    verification = verify_archive(delivery / ZIP_NAME)
    if (delivery / REPORT_NAME).read_bytes() != (ROOT / "README_AR.md").read_bytes():
        raise RuntimeError("Arabic delivery report differs from the packaged root README")
    saved_verification = json.loads(
        (delivery / VERIFICATION_NAME).read_text(encoding="utf-8")
    )
    if saved_verification["archive_sha256"] != sha256_file(delivery / ZIP_NAME):
        raise RuntimeError("Archive hash differs from its separate verification record")
    files = [
        path for path in sorted(delivery.iterdir())
        if path.is_file() and path.name != DELIVERY_MANIFEST_NAME
        and not path.name.startswith((".", "~$"))
        and path.suffix.lower() in {".docx", ".zip", ".md", ".json", ".txt"}
    ]
    for path in files:
        if path.is_symlink():
            raise RuntimeError(f"Delivery artifact is a symlink: {path}")
        inside_root(path)
    manifest = {
        "schema_version": 1, "created_utc": utc_now(),
        "scope": "Final Word, evidence ZIPs, reports and delivery verification records",
        "manifest_self_excluded": True,
        "repair_archive_payload_verification": verification,
        "files": [
            {"path": path.name, "bytes": path.stat().st_size,
             "sha256": sha256_file(path)} for path in files
        ],
    }
    atomic_write(delivery / DELIVERY_MANIFEST_NAME, canonical_json(manifest))
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    build = commands.add_parser("package", help="Create and verify evidence ZIP after final QA")
    build.add_argument("--qa-ready", action="store_true", help="Final QA has been completed")
    commands.add_parser("delivery-manifest", help="Hash final delivery files after packaging")
    args = parser.parse_args()
    if args.command == "package":
        package(args.qa_ready)
    else:
        delivery_manifest()


if __name__ == "__main__":
    main()
