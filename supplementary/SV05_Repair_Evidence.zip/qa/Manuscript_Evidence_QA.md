# Manuscript-to-evidence QA: SV05 repair

Audit time: 2026-10-11T18:23:32.814211+00:00.

Audited Word: `C:\Users\RNO\Desktop\Coureses\P1\ars_sv05_fix_2026_10_12\delivery\Research_Report_Chapters_1_to_6_v1_11_SV05_Fixed_Highlighted_20261012.docx`.

Audited snapshot SHA-256: `aa898121eecaaf109ad64d61d85956d459b11b986f888794ba9878284a4173bd`.

Read-only scientific-content and OOXML audit. No document edits or test reruns were performed. No page-layout or pagination approval is claimed. P and T indices below are zero based and match python-docx Document.paragraphs and Document.tables.

## Assessment

PASS for the revised scientific counts, status and bounded interpretation. No unsupported full-suite all-pass claim or contradictory current SV05-open status was found. Original suite results, later protocol cases and unit checks have separate denominators. The parent task is reviewing visual layout separately.

## Verified counts and observations

| Manuscript claim | Verification against retained records | Result |
|---|---|---|
| Original suite: 101 records, 99 PASS, 1 FAIL, 1 OBSERVED_BOUNDARY | Independently counted delivery/Security_Validation_Evidence.zip Results.csv. Security_Validation_Summary.json agrees. | PASS |
| Repaired original-contract replay: 59 PASS | All individual records in runs/candidate_retained/results match their aggregate report entries. Group totals: SV02 17, SV03 7, SV04 28, SV05 7. | PASS |
| Added production guard extension: 12 PASS | runs/production_final contains 11 PASS; runs/nonsequential_final contains 1 PASS. All twelve report actual_production_guard=true. | PASS |
| Three controls and nine negative cases | Positive IDs are PROD_NORMAL, PROD_REVERSE_ALIGNED and PROD_NONSEQUENTIAL_IDS. The other nine have expectation=reject. | PASS |
| Positive controls complete four stages and one aggregate within their bounds | All three positive records report SETUP, SHARE_KEYS, COLLECT, UNMASK, aggregate_callbacks=1 and error within their recorded quantization bound. | PASS |
| Baseline reproduces the original failure | runs/baseline/results/SV05_PARALLEL_LIST_LENGTH_MISMATCH.json records KeyError, message 22, three total fits, UNMASK reached, zero accepted aggregates, zero advancement and FAIL. | PASS |
| Repaired unchanged mismatch rejects before affected fit | runs/candidate_retained/results/SV05_PARALLEL_LIST_LENGTH_MISMATCH.json records ValueError during COLLECT, node 33 fit count 0, no UNMASK, aggregate count 0, advancement 0 and PASS. | PASS |
| Native production mismatch confirms that behavior | runs/production_final/results/PROD_PARALLEL_LIST_LENGTH_MISMATCH.json records the same ValueError/COLLECT/target 0/no UNMASK/aggregate 0 behavior, with actual_production_guard=true and early assertions passed. | PASS |
| Nine native negatives reject before affected fit | Every selected negative records ValueError at COLLECT, affected fit 0, no UNMASK, aggregate 0 and advancement 0. All observed total fit counts are 0. | PASS |
| Observed total fits 0 is qualified by request order | Contracts v2 require target fit 0 and total fits at most 2. Harness_Order_Correction.json retains the ordering correction. P521 says earlier clients may fit under another order. | PASS |
| 75 unit checks = 15 routing + 60 measurement | source_checks_final/stderr.log names that split and ends Ran 75 tests / OK. Source_Checks.json reports failures/errors/skips 0 and syntax PASS. Receipt exit is 0. | PASS |
| Earlier discovery and integrity-gate errors are retained | runs/source_checks and runs/source_checks_attempt02 logs remain. Harness_Correction_01, Source_Gate_Revision and Harness_Order_Correction explain the changes. | PASS |
| Original 299 source/preprocessing entries and four runtime/build files preserved | Original_Seal contains 215 source and 84 preprocessing_source entries. Original_Preservation_Verified reports 299 + 4, zero mismatches. Its producer checks each retained hash before writing the receipt. | PASS against preserved hash-check evidence |

Selected protocol cases total 71 PASS = 59 + 11 + 1. These are not combined with the 75 unit checks as a single security-test denominator. The original 101-case suite remains historical. SV-01, SV-06 and SV-07 were not rerun in full on the repaired source version.

The candidate replay uses a toy guard calling the same new validator; the twelve extension cases use the actual project guard. The revised manuscript explicitly distinguishes these execution paths. The original malformed-list mutation and original acceptance contract remain unchanged. The installed cryptographic helper was not replaced.

## Exact revised claim locations

### P32

English abstract: historical failure, subsequent targeted resolution and continuing metadata boundary.

Federated learning (FL) applied to electronic health record (EHR) access logs can support anomaly detection without requiring the centralisation of raw log data. However, sharing individual client model updates with a central server raises privacy concerns. This study evaluates the role of secure aggregation in limiting direct server inspection of individual client updates, alongside observed differences in detection performance and training-workflow cost. A Flower-based architecture was implemented in which simulated clients trained a compact long short-term memory (LSTM) autoencoder locally. Three configurations were compared: pooled centralised training, standard Federated Averaging (FedAvg), and a locally modified Secure Aggregation Plus (SecAgg+) path. A fixed synthetic benchmark was evaluated under Reference and controlled Non-IID client-sampling conditions across five seeds, using routine-validation calibration and two separate test sets from the same synthetic source. On the primary test, the mean paired average-precision (AP) difference between SecAgg+ and FedAvg was +0.0047 under Reference sampling and +0.0001 under Non-IID sampling; equivalence was not established. The SecAgg+ workflow increased mean fit-path time by 132.8% and 128.6%, respectively, and application-message content by approximately 49.9%, while federation did not consistently outperform pooled training. On the secondary test, SecAgg+ false-positive rates reached 98.58% and 96.40%, indicating poor handling of unusual legitimate activity. These findings show that SecAgg+ can limit direct inspection of individual updates, but with substantial training-workflow overhead and no clear utility gain in this benchmark. A fresh-environment replay on the same host reproduced the compared predictive results exactly, with a disclosed scaler-metadata compatibility exception. The bounded security audit initially retained one rejection failure and a metadata boundary. A subsequent patch and targeted retest resolved SV-05; the metadata boundary remains. Protection claims are limited to trusted-host and honest-participant assumptions, while the simulated data source constrains deployment conclusions.

### P36

Malay abstract: the same bounded status transition.

Analisis kolaboratif terhadap log capaian rekod kesihatan elektronik (Electronic Health Record, EHR) dapat menyokong pengesanan anomali, namun pemusatan rekod sensitif atau pendedahan kemas kini individu daripada klien menimbulkan kebimbangan terhadap privasi. Kajian ini menilai peranan pengagregatan selamat (secure aggregation) dalam mengehadkan pemeriksaan langsung pelayan terhadap kemas kini individu daripada klien, serta perbezaan prestasi pengesanan dan kos aliran kerja latihan yang diperhatikan. Satu seni bina berasaskan Flower telah dibangunkan, di mana klien simulasi melatih secara setempat sebuah autoenkoder Long Short-Term Memory (LSTM) yang ringkas. Tiga konfigurasi telah dibandingkan, iaitu latihan berpusat terkumpul (pooled centralised training), Federated Averaging (FedAvg) standard, dan laluan Secure Aggregation Plus (SecAgg+) yang diubah suai secara setempat. Satu penanda aras sintetik tetap telah dinilai di bawah keadaan pensampelan klien Reference dan Non-IID terkawal merentasi lima seed, dengan penentukuran berdasarkan data rutin dalam set pengesahan sahaja serta dua set ujian berasingan daripada sumber sintetik yang sama. Dalam ujian utama, perbezaan min berpasangan bagi average precision (AP) antara SecAgg+ dan FedAvg ialah +0.0047 di bawah pensampelan Reference dan +0.0001 di bawah pensampelan Non-IID; namun, kesetaraan tidak dapat dibuktikan. Aliran kerja SecAgg+ meningkatkan purata masa fit-path masing-masing sebanyak 132.8% dan 128.6%, serta kandungan mesej aplikasi kira-kira 49.9%, manakala pembelajaran bersekutu tidak secara konsisten mengatasi latihan berpusat terkumpul. Dalam ujian sekunder, kadar positif palsu (false-positive rate) SecAgg+ mencapai 98.58% dan 96.40%, yang menunjukkan kelemahan dalam mengendalikan aktiviti sah yang luar biasa. Dapatan ini menunjukkan bahawa SecAgg+ dapat mengehadkan pemeriksaan langsung terhadap kemas kini individu, tetapi dengan kos aliran kerja latihan yang ketara dan tanpa peningkatan utiliti yang jelas dalam penanda aras ini. Pelaksanaan semula dalam persekitaran baharu pada hos yang sama menghasilkan semula keputusan ramalan yang dibandingkan secara tepat, dengan pengecualian keserasian metadata penskala yang dinyatakan. Audit keselamatan terhad merekodkan satu kegagalan penolakan dan batas metadata; pembaikan serta ujian semula menyelesaikan SV-05, tetapi batas metadata kekal. Tuntutan perlindungan adalah terhad kepada andaian hos yang dipercayai (trusted host) dan peserta yang jujur (honest participant), manakala penggunaan sumber data sintetik mengehadkan kesimpulan berkaitan kesediaan untuk penerapan sebenar.

### P366

Methods: separate source copy, shared validator, original contract and mutation, twelve actual guard fixtures and workload limitations.

SV-05 remediation and retesting (12 October 2026). A separate project copy added collection-request validation before the upstream fit callback. It requires equal ciphertext/source-list lengths and each retained external peer exactly once, while accepting aligned permutations. The original 59-case contract and mutation were retained. Its toy guard invoked the same new project validator. Twelve additional cases exercised the actual project guard with public arrays and configuration-valid acknowledgement fields. These were implementation fixtures, without EHR optimisation, network deployment or changes to the installed cryptographic helper.

### P517

Historical 101-case totals and counting unit.

The seven groups completed on 11 October 2026 in the retained local environment. The historical selected result set contains 101 case records: 99 PASS, one FAIL and one OBSERVED_BOUNDARY (Table 4.16). Case records, rather than assertions or repeated sessions, are the counting unit. No selected contract case was NOT_RUN. These outcomes describe tested implementation behaviour under the local trusted-host assumptions; they do not establish a general security guarantee.

### P520

Historical failure and baseline replay, followed by the repaired mismatch behavior and bounded closure.

The historical failure was SV05_PARALLEL_LIST_LENGTH_MISMATCH. Removing one source ID while retaining its ciphertext list caused KeyError at UNMASK after three toy fit callbacks; the recorded exception message was 22. No aggregate callback was accepted and the toy aggregate state did not advance. The sealed criterion required controlled ValueError or RuntimeError rejection. A baseline replay reproduced the failure. In the separately versioned repair, the unchanged malformed-list fixture raised ValueError during collection, before the affected client fit callback and before UNMASK, with zero accepted aggregates. This closes the named finding for the repaired copy and tested inputs; the original FAIL record is retained.

### P521

59 original-contract cases; 12 added cases split into three controls and nine negatives; ordering qualification; 75 separate unit checks.

The repaired copy passed all 59 cases under the original contract, including all seven SV-05 fixtures. The 12 additional production-guard cases also passed: three complete controls (normal order, reversed aligned pairs and nonsequential node IDs) and nine malformed-routing cases. Each positive control completed four stages and one aggregate within its numerical bound. The negative cases rejected before the affected client fit and accepted no aggregate. The observed total fit count for the original malformed-list fixture was zero; earlier clients may still fit under a different request order. Separately, 75 unit/regression tests passed without failures, errors or skips. These counts do not represent a rerun of the complete historical 101-case suite.

### P523

Original attempt history and unchanged performance/cost tables.

Both 11 October protocol attempts are retained. Attempt 01 had 57 PASS and two FAIL records; one failure was a harness decoder call missing keep_input=True. Only that API call was repaired. Attempt 02 had 58 PASS and one target FAIL, with the acceptance contract and target code unchanged. Both exited with code 2 because an unmet criterion remained. The other groups completed in their first attempts. The original 299 source/preprocessing inventory entries and the four sealed runtime/build files matched before and after execution. Performance and system-cost tables were not recalculated or replaced.

### P524

Corrections, successor gate, original criterion and source preservation.

The new baseline, candidate and regression attempts, executed programs, contracts, timestamps, exit codes and stdout/stderr are retained in SV05_Repair_Evidence.zip. The initial unit discovery error and predecessor whole-file equality failure are disclosed, together with their corrections. The successor source gate pins the exact repaired file and verifies that the previous response-validator function remains unchanged. A supplementary callback-order assumption was corrected before the selected production rerun; the original 59-case rejection criterion was unchanged. All 299 original source/preprocessing entries and four protected runtime/build files still matched their preserved hashes.

### P538

Discussion: the old error, separate repair and continuing limitations.

The later validation in Section 4.11 adds direct server-ingress observations for public fixtures and selected negative tests. The 11October audit recorded a late malformed-list error and a diagnostic-metadata boundary. The 12October repair resolved the named error in the separate tested copy; the metadata boundary remains. These findings narrow the implementation claim: the tested C interface omitted populated plaintext parameter records, but neither inference resistance nor comprehensive malformed-message handling was established. The tests did not measure attack success or privacy loss.

### P580

Validity: targeted closure, metadata assumptions and untested threat scope.

The later bounded suite improves evidence for helper conformance, selected message checks, numerical aggregation and observed context freshness. The subsequent repair and targeted retest closed the named SV-05 finding in a separate source version. Permitted diagnostic metadata is still assumed public and trusted. No formal cryptographic certification, arbitrary-collusion test, shared-host isolation test or TLS deployment validation was performed. These tests do not resolve the separate data-provenance, clinical-label or ethics uncertainties.

### P600

Conclusion: historical and new denominators reported separately.

The 11October audit completed seven bounded groups, retaining 99 PASS, one controlled-rejection FAIL and one diagnostic-metadata boundary among 101 selected records (Section 4.11; Appendix D.9). The 12October source revision resolved the named SV-05 failure:59 original-contract cases, 12 additional production-guard cases and 75 unit/regression tests passed in their selected runs. This supports the specific input-validation correction while preserving the historical failure and metadata limitation. It does not establish quantified privacy protection, comprehensive replay resistance or security against the shared-host administrator. Original RQ utility and cost conclusions remain unchanged.

### P772

Appendix D.9: original 101-case historical status.

Historical execution status (11 October 2026): all seven named groups and all 101 selected contract records were executed. Selected status totals are 99 PASS, 1 FAIL and 1 OBSERVED_BOUNDARY; no selected case was NOT_RUN. PASS means that the case-specific contract was met. For negative fixtures it means the expected refusal was observed, while the SETUP-restart case records allowed behaviour. The 20 freshness sessions are one grouped diagnostic case, not 20 independent security experiments.

### P778

Appendix D.9: remediation status, collection-stage controlled error and target fit/aggregate behavior.

SV-05 remediation status (12 October 2026): FIXED WITHIN THE TESTED PROJECT BOUNDARY. The original unequal-list fixture and its FAIL records remain preserved. The repaired project copy validates lengths and the complete unique external-peer set before upstream fitting. The unchanged fixture now raises ValueError during COLLECT, with no affected-client fit, no UNMASK and no accepted aggregate. The separate production-guard malformed-list case confirms the same behaviour. The original benchmark source was not overwritten, and no evidence shows that its training contained this malformed request. The repair is a project policy guard, not a change to the cryptographic wheel.

### P779

Appendix D.9: 59/12/75 accounting and 15/60 unit-test split; no full 101-case rerun.

Retest accounting. The original-contract replay recorded 59 PASS, covering SV-02 to SV-05. The production-guard extension recorded 12 PASS: 3 positive controls and 9 negative cases. The positives included reversed aligned pairs and different node identities; their aggregate errors met the fixture-specific bounds. The 75 passing unit/regression checks include 15 new routing-guard tests and 60 existing measurement-contract tests. They are separate counting units. SV-01/SV-06/SV-07 were not rerun in full on this source revision, so the101-case historical ledger is not recast as a newly executed all-pass suite.

### P783

ME-10: historical finding, verified repair and continuing metadata limitation.

Status of the earlier missing-evidence items. For ME-10, bounded implementation validation is now executed with the historical SV-05 finding, its separately verified repair and the continuing metadata limitation; broad privacy/security assurance remains unestablished. ME-11 is unchanged: these checks do not measure isolated cryptographic time or full-wire traffic. ME-06 remains the separately documented computational replay. The present validation also does not resolve ME-02 label validity, ME-04/05 historical discovery records, external generalisation or the formal ethics status.

### P785

New evidence attachment and interpretation of old dated comments.

SV05_Repair_Evidence.zip accompanies the 12October repair. It contains the base and repaired source snapshots, complete patch, source manifests, retained attempts and logs, per-case results, unit-test outcomes and correction records. Receipt commands identify the retained runtime and new output directories needed for repetition. This is a source-and-evidence package, not a new installation certificate. Historical comments describe the earlier versions and remain alongside the new dated repair comments. Open repair evidence package.

### P795

Final protection claim stays bounded.

The later security-validation evidence supports only the named implementation observations in Section 4.11. The historical controlled-rejection failure is retained, and its separately versioned SV-05 repair passed the targeted retest. The diagnostic-metadata boundary and untested scope remain. Neither the historical suite nor the repair supports a comprehensive-protection statement, quantified privacy assurance or independent production certification.

### P797

Chronology: original audit and separate source repair; no main retraining or replacement performance/cost estimates.

The separately dated bounded security validation was executed later on 11 October 2026, after the ME-06 replay. It adds the actual outcomes, retained unsuccessful attempt and open input-validation finding in Section 4.11 and Appendix D.9. That11October suite changed neither the source nor the original predictive/system-cost tables. The 12October repair changed a separate source copy; it did not retrain the main detector or recalculate those tables. The fixed-copy results therefore support input validation, not new performance or cost estimates.

### P800

New highlight key.

Highlight key for the 12October SV-05 update: green marks added repair methods and executed results; yellow marks revised interpretation and limitations; cyan marks status, provenance, attachment links and corrected navigation. Earlier highlights and dated comments are preserved.

## Exact changed table cells

### T27

Row 0, column 1:
11 Oct baseline / SV-05 retest

Row 5, column 1:
11 Oct: 6 PASS; 1 FAIL. 12 Oct: 7 PASS.

Row 5, column 2:
Historical late KeyError retained. After repair, the unchanged fixture was rejected by ValueError during collection, before affected-client fit and any accepted aggregate. Separate native-guard controls passed.

### T28

Row 2, column 1:
Execution of the pinned SecAgg+ path under the stated trusted-host and honest-participant assumptions. Later public-fixture checks: Section 4.11 and Appendix D.9; the historical controlled-rejection failure was resolved in the separately tested12October source copy.

### T29

Row 3, column 1:
Section 3.8; Tables C.2/C.5; attributed source patch; later checks in Section 4.11 and Appendix D.9 (historical FAIL, verified SV-05 repair; metadata boundary)

Row 3, column 2:
Aggregation path and bounded numerical checks completed; no comprehensive privacy certification; the historical suite retained one rejection failure, resolved by the separate targeted repair, and a continuing metadata boundary.

### T65

Row 5, column 0:
SV-05 repair and retest

Row 5, column 1:
SV05_Repair_Evidence.zip

Row 5, column 2:
Base/repaired sources; patch and manifests; runs/ receipts, executed scripts, contracts, stdout/stderr and results; Repair_Summary/Results; correction records.

Only T27, T28, T29 and T65 changed. All other 64 tables have identical cell text, including the main prediction and system-cost tables. All embedded media bytes are unchanged. The statement that main performance and cost tables remain unchanged is therefore consistent with the manuscript diff. Security-summary and evidence-inventory tables are explicitly revised.

## Source gate and correction history

Exactly two production app Python files differ between source_base and source_candidate: app/ehr_secagg/client_app.py and app/ehr_secagg/wire.py. The latter file has predecessor SHA-256 e224589f53235d639ffbc845ae1482b96ffa93117a625d48c0da9c06b10d2e2d and successor SHA-256 807764a73fbcaee990e48ffa32e88c3682c9fa84732a9be8a9808cd9740a9337. These match the versioned reference. The check_masked_reply function source is identical, SHA-256 6cf8bb5aed809ad7222a0660023f9389971872e710ac24220b4a0da253bb3a9e.

The earlier reference still retains the predecessor whole-file pin. The successor gate explicitly pins the repaired file and separately requires the old response validator to remain unchanged. The 74/75 predecessor-gate attempt and the earlier discovery error remain retained. This supports the manuscript correction-history statement without portraying the earlier attempts as passing.

The exact external-peer-set rule is a strict three-client project policy. The manuscript does not claim generic upstream partial-cohort compatibility, arbitrary retained-state robustness, network security or cryptographic certification.

## Comments, chronology and attachment link

All 370 historical comments remain with identical author, date and text; none were removed or silently rewritten. 5 new dated comments were added. Their UTC time on 11 October at 18:18 corresponds to 12 October in Asia/Singapore, and their text says local time.

Comment 625, 2026-10-11T18:18:30.314315Z:
12 October 2026 local time: separate project copy repaired and retested. Historical101-case audit remains99PASS/1FAIL/1boundary. See4.11/D.9 and SV05_Repair_Evidence.zip. Old dated comments describe their original revision.

Comment 626, 2026-10-11T18:18:30.314315Z:
Malay security summary aligned to actual subsequent SV05 repair; no security certification or new benchmark performance claim.

Comment 627, 2026-10-11T18:18:30.314315Z:
Source changes are client_app.py and wire.py; versioned source gate and regression tests accompany them. Frozen source/runtime and historical campaign preserved. Native guard controls are separately identified from toy-guard replay.

Comment 628, 2026-10-11T18:18:30.314315Z:
Evidence: candidate_retained59PASS; production_final11PASS + nonsequential_final1PASS; source_checks_final75 tests. Supplementary early-rejection criteria explicitly checked; ordering correction retained. No aggregation or detector performance claims added.

Comment 629, 2026-10-11T18:18:30.315065Z:
Repair_Summary.json, Repair_Results.csv and exact run receipts. Original 101-case status and 75 unit checks have distinct denominators. Missing network/attack scope in Table D.13 is unchanged.

Old security comments 615–623 retain their original 11 October claims, including the then-open failure and the fact that targets were not patched at that stage. P785 and new comment 625 explicitly explain that historical comments describe earlier revisions. P797 attributes the open input-validation finding to the 11 October suite and follows it with the 12 October repair; it is not a current-open status claim.

The new relationship rIdSV05RepairEvidence is an external hyperlink with relative Target SV05_Repair_Evidence.zip. Existing ME06_Evidence.zip and Security_Validation_Evidence.zip links resolve beside the Word file.

Repair archive exists beside Word at audit time: False. Packaging is still pending; include the archive and verify its manifest before final delivery.

## Editorial observations and audit limit

Earlier audit observations about missing spaces around dates/counts were sent to the parent. Those edits do not affect scientific status or counts. The word then-open in P797 would further clarify the already dated historical reference, if desired.

This report covers the snapshot hash above. Later text, pagination or packaging changes must retain the verified scientific statements and receive the relevant final check. Visual review and final archive/manifest verification remain separate.


Final packaging addendum (12 October2026 local): the repair ZIP has now been created and verified. All relative ZIP attachment targets exist beside Word. Final Word SHA-256: ef5c31e4a51d909ecd2ea9cdadd03254ecfea0b3c3c0660f3cd5b038e6a93912. Final structural/evidence/pagination/visual checks are recorded separately; earlier pending statements describe the audit snapshot.
