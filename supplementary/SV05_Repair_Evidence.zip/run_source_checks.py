from pathlib import Path
import sys,json,unittest,datetime,hashlib,argparse
ap=argparse.ArgumentParser();ap.add_argument('--source',required=True);ap.add_argument('--contract',required=True);ap.add_argument('--contract-sha256',required=True);ap.add_argument('--out',required=True);a=ap.parse_args()
assert hashlib.sha256(Path(a.contract).read_bytes()).hexdigest()==a.contract_sha256
contract=json.loads(Path(a.contract).read_text());source=Path(a.source);out=Path(a.out);out.mkdir(parents=True,exist_ok=False)
sys.path[:0]=[str(source),str(source/'app'),str(source/'validation_support')]
for rel in ['app/ehr_secagg/client_app.py','app/ehr_secagg/wire.py','tests/test_sv05_routing.py']:
    compile((source/rel).read_bytes(),str(source/rel),'exec')
from main_study.common import package_integrity
manifest=package_integrity()
suite=unittest.TestSuite()
for pattern in contract['test_patterns']:
    suite.addTests(unittest.defaultTestLoader.discover(str(source/'tests'),pattern=pattern))
result=unittest.TextTestRunner(verbosity=2).run(suite)
output={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'syntax':'PASS','package_integrity_sha256':manifest,
 'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),
 'success':result.wasSuccessful(),'patterns':['test_sv05_routing.py','test_measurement.py'],
 'scope':'Public unit/regression checks only; no benchmark training or inference'}
(out/'Source_Checks.json').write_text(json.dumps(output,indent=2)+'\n');print(json.dumps(output))
sys.exit(0 if result.wasSuccessful() else 2)
