from pathlib import Path
import json,shutil,hashlib,datetime
ROOT=Path(__file__).resolve().parent
shutil.copy2(ROOT/'Candidate_Runner.py',ROOT/'Candidate_Runner_First.py')
p=ROOT/'Candidate_Runner.py';s=p.read_text()
needle="        contexts.clear()\n        return r"
assert s.count(needle)==1
s=s.replace(needle,"""        if spec['expectation']=='reject' and 'maximum_target_fit_callbacks' in spec:
            strong=(calls[str(nids[-1])]<=spec['maximum_target_fit_callbacks']
                    and sum(calls.values())<=spec['maximum_total_fit_callbacks']
                    and Stage.UNMASK not in stages)
            r['early_rejection_assertions_passed']=strong
            if not strong:r['status']='FAIL'
        contexts.clear()
        return r""")
p.write_text(s)
contract=json.loads((ROOT/'Production_Contract.json').read_text())
for spec in contract['cases']:
    if 'expected_total_fit_callbacks' in spec:
        del spec['expected_total_fit_callbacks'];spec['maximum_total_fit_callbacks']=2
        spec['order_note']='Request order is supplied by the workflow; only earlier clients may have fit. Affected node must never fit.'
(ROOT/'Production_Contract_v2.json').write_text(json.dumps(contract,indent=2)+'\n')
contract['node_ids']=[104,208,33];contract['cases']=[{'id':'PROD_NONSEQUENTIAL_IDS','group':'SV05-REPAIR','expectation':'complete'}]
(ROOT/'Nonsequential_Contract_v2.json').write_text(json.dumps(contract,indent=2)+'\n')
note={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'retained_first_attempts':['runs/production/','runs/nonsequential/'],
 'cause':'The initial supplementary contract assumed exact total two prior fits. Workflow iteration can visit affected node33 first; actual initial negative records had zero total fits. This unused ordering metadata was incorrect.',
 'correction':'Require affected node zero fits, total at most two, no UNMASK and zero aggregates. Explicitly assert these in the candidate runner.',
 'original_59_case_contract_unchanged':True,'production_source_changed':False,
 'original_security_expectation_weakened':False,'runner_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
 'production_contract_v2_sha256':hashlib.sha256((ROOT/'Production_Contract_v2.json').read_bytes()).hexdigest()}
(ROOT/'Harness_Order_Correction.json').write_text(json.dumps(note,indent=2)+'\n')
print(json.dumps(note,indent=2))
