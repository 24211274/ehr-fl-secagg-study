from pathlib import Path
import sys,subprocess,json,datetime,hashlib,shutil
ROOT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
linux=lambda p:'/mnt/c/'+str(p.resolve()).replace('\\','/')[3:]
label,runner,source,contract=sys.argv[1:5]
out=ROOT/'runs'/label;out.mkdir(parents=True,exist_ok=False)
script=ROOT/runner;ctr=ROOT/contract
shutil.copy2(script,out/'Executed_Script.py');shutil.copy2(ctr,out/'Executed_Contract.json')
command=['wsl.exe','-d','Ubuntu-24.04','-u','mai','--',
 '/home/mai/ehr_me06_reproduction_20261011_v1/.venv/bin/python','-I','-B',linux(script),
 '--source',linux(ROOT/source),'--contract',linux(ctr),'--contract-sha256',sha(ctr),'--out',linux(out/'results')]
if len(sys.argv)>5:command+=sys.argv[5:]
receipt={'command':command,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'script_sha256':sha(script),'contract_sha256':sha(ctr),'source':source,'status':'RUNNING','timeout_seconds':300}
(out/'Receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
with (out/'stdout.log').open('w') as stdout,(out/'stderr.log').open('w') as stderr:
    process=subprocess.Popen(command,stdout=stdout,stderr=stderr)
    receipt['pid']=process.pid
    (out/'Receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    try:code=process.wait(timeout=300)
    except subprocess.TimeoutExpired:
        process.kill();code=-9;receipt['timeout']=True
receipt.update(end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=code,status='FINISHED')
assert sha(script)==receipt['script_sha256'] and sha(ctr)==receipt['contract_sha256']
(out/'Receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
