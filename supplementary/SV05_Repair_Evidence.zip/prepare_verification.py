from pathlib import Path
import json,hashlib,datetime,difflib
ROOT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=(ROOT/'Original_Runner.py').read_text()
def replace(a,b):
    global source
    assert source.count(a)==1,a
    source=source.replace(a,b)
replace("a=ap.parse_args()","ap.add_argument('--production-guard',action='store_true'); a=ap.parse_args()")
replace('from ehr_secagg.wire import check_masked_reply','from ehr_secagg.wire import check_masked_reply, check_collect_request\n    from ehr_secagg.client_app import guarded_secaggplus_mod\n    from ehr_fedavg.task import cfg\n    production_config=cfg() if a.production_guard else None')
replace('nids=[11,22,33]; public_input=',"nids=contract.get('node_ids',[11,22,33]); public_input=")
replace("weights=spec.get('weights',[64,128,256])","weights=([production_config['training_sessions_per_client'][f'C{i+1}'] for i in range(3)] if a.production_guard else spec.get('weights',[64,128,256]))")
replace("'steps':0,'draws':weights[self.i]","'steps':production_config['local_updates_per_round'][f'C{self.i+1}'] if a.production_guard else 0,'draws':weights[self.i]")
replace('reply=secaggplus_mod(msg,ctx,call_next)',"if st==Stage.COLLECT_MASKED_VECTORS: check_collect_request(rec,ctx)\n            reply=secaggplus_mod(msg,ctx,call_next)")
replace('mods=[guard])','mods=[guarded_secaggplus_mod if a.production_guard else guard])')
replace("elif mode=='parallel_list_length_mismatch': c[Key.SOURCE_LIST]=list(c[Key.SOURCE_LIST])[:-1]", """elif mode=='parallel_list_length_mismatch': c[Key.SOURCE_LIST]=list(c[Key.SOURCE_LIST])[:-1]
            elif mode=='short_ciphertext': c[Key.CIPHERTEXT_LIST]=list(c[Key.CIPHERTEXT_LIST])[:-1]
            elif mode=='extra_ciphertext': c[Key.CIPHERTEXT_LIST]=list(c[Key.CIPHERTEXT_LIST])+[b'PUBLIC_EXTRA_CIPHERTEXT']
            elif mode=='extra_source': c[Key.SOURCE_LIST]=list(c[Key.SOURCE_LIST])+[999]
            elif mode=='duplicate_source': c[Key.SOURCE_LIST]=[c[Key.SOURCE_LIST][0]]*2
            elif mode=='unknown_source': c[Key.SOURCE_LIST]=[c[Key.SOURCE_LIST][0],999]
            elif mode=='self_source': c[Key.SOURCE_LIST]=[c[Key.SOURCE_LIST][0],33]
            elif mode=='both_short':
                c[Key.SOURCE_LIST]=list(c[Key.SOURCE_LIST])[:-1];c[Key.CIPHERTEXT_LIST]=list(c[Key.CIPHERTEXT_LIST])[:-1]
            elif mode=='boolean_sources': c[Key.SOURCE_LIST]=[True,False]
            elif mode=='reverse_aligned':
                c[Key.SOURCE_LIST]=list(reversed(c[Key.SOURCE_LIST]));c[Key.CIPHERTEXT_LIST]=list(reversed(c[Key.CIPHERTEXT_LIST]))""")
replace("'runtime_or_original_source_modified':False", "'runtime_or_original_source_modified':False,'separate_candidate_copy':True,'actual_production_guard':a.production_guard")
replace("'main_crypto_parameters':params,'benchmark_data_read':False", "'actual_production_guard':a.production_guard,'main_crypto_parameters':params,'benchmark_data_read':False")
(ROOT/'Candidate_Runner.py').write_text(source)
original=json.loads((ROOT/'Acceptance_Contract.json').read_text())
def case(name,mode=None):
    return {'id':name,'group':'SV05-REPAIR','expectation':'complete' if mode in (None,'reverse_aligned') else 'reject',
      **({'mutation':mode,'stage':'collect_masked_vectors'} if mode else {}),
      **({'expected_exception_types':['ValueError'],'maximum_target_fit_callbacks':0,'expected_total_fit_callbacks':2,'unmask_must_not_be_reached':True} if mode not in (None,'reverse_aligned') else {})}
negative_modes=['parallel_list_length_mismatch','short_ciphertext','extra_ciphertext','extra_source','duplicate_source','unknown_source','self_source','both_short','boolean_sources']
contract={'version':1,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'purpose':'Additional production-guard regression cases; original contract unchanged in separate replay',
 'main_crypto_parameters':original['main_crypto_parameters'],'cases':[case('PROD_NORMAL'),case('PROD_REVERSE_ALIGNED','reverse_aligned')]+[case('PROD_'+m.upper(),m) for m in negative_modes],
 'scope':'Actual guarded_secaggplus_mod, actual fixed_config acknowledgement budgets, public arrays and toy fit callback; no EHR model optimisation.'}
(ROOT/'Production_Contract.json').write_text(json.dumps(contract,indent=2)+'\n')
contract['node_ids']=[104,208,33];contract['cases']=[case('PROD_NONSEQUENTIAL_IDS')]
(ROOT/'Nonsequential_Contract.json').write_text(json.dumps(contract,indent=2)+'\n')
base=ROOT/'source_base';candidate=ROOT/'source_candidate';patch=[];changes=[]
for p in sorted(base.rglob('*')):
    if not p.is_file():continue
    rel=p.relative_to(base);q=candidate/rel
    if p.read_bytes()!=q.read_bytes():
        patch.extend(difflib.unified_diff(p.read_text().splitlines(True),q.read_text().splitlines(True),fromfile='a/'+rel.as_posix(),tofile='b/'+rel.as_posix()))
        changes.append({'path':rel.as_posix(),'old_sha256':sha(p),'new_sha256':sha(q)})
assert {c['path'] for c in changes}=={'app/ehr_secagg/client_app.py','app/ehr_secagg/wire.py'}
(ROOT/'SV05_Repair.patch').write_text(''.join(patch))
manifest=candidate/'PACKAGE_SHA256SUMS.txt'
manifest.write_text(''.join(sha(p)+'  '+p.relative_to(candidate).as_posix()+'\n' for p in sorted(candidate.rglob('*')) if p.is_file() and p!=manifest))
seal={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'patch_files':changes,
 'candidate_manifest_sha256':sha(manifest),'patch_sha256':sha(ROOT/'SV05_Repair.patch'),
 'original_contract_sha256':sha(ROOT/'Acceptance_Contract.json'),'candidate_runner_sha256':sha(ROOT/'Candidate_Runner.py'),
 'production_contract_sha256':sha(ROOT/'Production_Contract.json'),'nonsequential_contract_sha256':sha(ROOT/'Nonsequential_Contract.json'),
 'acceptance':'Original failure must become controlled ValueError before node33 local fit and UNMASK, zero accepted aggregates. Legitimate aligned permutations and varied IDs must complete within original numerical bounds. Preserve original failing record.'}
(ROOT/'Repair_Acceptance_Seal.json').write_text(json.dumps(seal,indent=2)+'\n')
print(json.dumps(seal,indent=2))
