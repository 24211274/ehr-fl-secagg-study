import json,csv,re,urllib.parse,collections
from pathlib import Path
B=Path(__file__).resolve().parent
def rd(p):return json.loads((B/p).read_text(encoding='utf-8-sig'))
def urlnorm(s):
    p=urllib.parse.urlsplit(s or ''); host=p.netloc.lower().removeprefix('www.')
    return urllib.parse.urlunsplit((p.scheme.lower(),host,p.path.rstrip('/'),p.query,''))
def title(s):return re.sub(r'[^a-z0-9]+','',str(s).lower())
api=rd('public_api/Screening_Union.json'); web=rd('web/Unified_Web_Screened_Union.json')['candidates']
aliases={};alias_receipts=[]
for r in rd('challengers/Normalized_Candidates.json')['candidates']:
    if not r.get('doi'):continue
    for k in ['verified_source_url','publisher_url']:
        u=r.get(k)
        if not u or '/person/' in u or '/wieiswie/' in u:continue
        aliases[urlnorm(u)]=r['doi'].lower()
        alias_receipts.append({'url':urlnorm(u),'doi':r['doi'].lower(),'basis':'Source-specific identity declared in preserved original publisher/institution/author evidence; bibliographic linkage, not full-text certification.','record':r['record_id'],'profile':'challengers/Normalized_Candidates.json'})
for r in rd('root_sources/Root_Source_Assessment.json')['sources']:
    aliases[urlnorm(r['url'])]=r['doi'].lower()
    alias_receipts.append({'url':urlnorm(r['url']),'doi':r['doi'].lower(),'basis':'Primary source identity checked by root; DOI metadata also verified.','record':r['id'],'profile':'root_sources/Root_Source_Assessment.json'})
nodes=[]
for r in api:
    ids=[r['stable_source_id'].upper(),'URL:'+urlnorm(r['source_url'])]
    if r.get('doi'):ids.append('DOI:'+r['doi'].lower())
    if r.get('pmid'):ids.append('MED:'+r['pmid'])
    if r.get('pmcid'):ids.append('PMC:'+r['pmcid'].upper())
    nodes.append({'node_id':'API:'+r['stable_source_id'],'channel':'API','title':r['title'],'doi':r.get('doi'),'identifiers':list(set(ids)),'decision':r['decision'],'reason':r['reason'],'provenance':r['database_provenance'],'url':r['source_url']})
for r in web:
    ids=['URL:'+urlnorm(r['canonical_url'])]+['DOI:'+d.lower() for d in r['verifiedDOI_fromURL']]
    mapped=aliases.get(urlnorm(r['canonical_url']))
    if mapped:ids.append('DOI:'+mapped)
    for v in r.get('public_identifiers_fromURL',[]):
        if isinstance(v,str):
            if re.fullmatch(r'PMC\d+',v,re.I):ids.append('PMC:'+v.upper())
            elif re.fullmatch(r'PMID:?\d+',v,re.I):ids.append('MED:'+re.sub(r'\D','',v))
        elif isinstance(v,dict):
            for k,val0 in v.items():
                if k.upper()=='PMID':ids.append('MED:'+str(val0))
                elif k.upper()=='PMCID':ids.append('PMC:'+str(val0).upper())
                elif k.upper() in ['IEEE_DOCUMENT_ID','OPENALEX_ID']:ids.append(k.upper()+':'+str(val0))
            kind=str(v.get('type',v.get('kind',''))).upper(); val=str(v.get('value',v.get('id','')))
            if kind in ['PMID','PUBMED']:ids.append('MED:'+val)
            elif kind=='PMCID':ids.append('PMC:'+val.upper())
    nodes.append({'node_id':r['candidate_id'],'channel':'WEB','title':r['titles'][0],'doi':mapped or (r['verifiedDOI_fromURL'][0] if len(r['verifiedDOI_fromURL'])==1 else None),'identifiers':ids,'decision':r['decision'],'reason':r['decision_reasons'],'provenance':{'record_ids':r['record_ids'],'batches':r['batch_ids'],'returned_occurrences':r['returned_occurrence_count']},'url':r['canonical_url']})
parents=list(range(len(nodes)))
def find(i):
    while i!=parents[i]:parents[i]=parents[parents[i]];i=parents[i]
    return i
by={};merges=[]
for i,n in enumerate(nodes):
    for key in n['identifiers']:
        if key in by:
            a,b=find(i),find(by[key])
            if a!=b:
                parents[a]=b; merges.append({'left':n['node_id'],'right':nodes[by[key]]['node_id'],'basis':key})
        else:by[key]=i
groups=collections.defaultdict(list)
for i,n in enumerate(nodes):groups[find(i)].append(n)
rows=[]
for i,ns in enumerate(groups.values(),1):
    rows.append({'catalog_id':f'CAT-{i:03}','nodes':ns,'node_count':len(ns),'channels':sorted(set(n['channel'] for n in ns)),'verified_identifier_dois':sorted(set(n['doi'].lower() for n in ns if n.get('doi'))),'decision_set':sorted(set(n['decision'] for n in ns)),'counting_boundary':'Identifier-linked discovery cluster; not certified unique underlying study.'})
titles=collections.defaultdict(set)
for r in rows:
    for n in r['nodes']:
        t=title(n['title'])
        if len(t)>20:titles[t].add(r['catalog_id'])
possible=[{'normalized_title':t,'catalog_ids':sorted(v),'action':'RETAIN_SEPARATE_PENDING_VERSION_REVIEW; NOT_AUTOMATICALLY_MERGED'} for t,v in titles.items() if len(v)>1]
out={'scope':'Cross-channel exact stable-identifier reconciliation, including source-specific DOI/URL identity aliases with recorded provenance. No global study-level count claimed. Different article versions and alternate URLs may remain distinct. Bibliographic background and non-study pages remain screened discovery candidates.','input_api_source_id_records':len(api),'input_web_url_candidates':len(web),'identifier_linked_clusters':len(rows),'cross_channel_clusters':sum(len(r['channels'])>1 for r in rows),'exact_identifier_merge_events':merges,'source_specific_doi_url_alias_receipts':alias_receipts,'possible_title_duplicate_clusters':possible,'special_version_flag':'API251/252 UCADI may be related versions; retain both records until source-level version review.','clusters':rows}
(B/'Cross_Channel_Candidate_Catalog.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
with (B/'Cross_Channel_Candidate_Catalog.csv').open('w',encoding='utf-8-sig',newline='') as f:
    fields=['catalog_id','node_count','channels','verified_identifier_dois','decision_set','node_ids','titles','counting_boundary']; w=csv.DictWriter(f,fields);w.writeheader()
    for r in rows:w.writerow({k:json.dumps(r[k],ensure_ascii=False) if isinstance(r.get(k),list) else r.get(k) for k in fields if k not in ['node_ids','titles']}|{'node_ids':';'.join(n['node_id'] for n in r['nodes']),'titles':' | '.join(n['title'] for n in r['nodes'])})
qa={'all_input_nodes_preserved':sum(r['node_count'] for r in rows)==len(nodes),'unique_input_ids':len({n['node_id'] for n in nodes})==len(nodes),'merge_count_reconciles':len(rows)==len(nodes)-len(merges),'counts_are_studies':False,'doi_or_title_heuristic_merge_performed':False,'exact_identifier_cluster_count':len(rows),'possible_title_duplicate_count':len(possible),'all_decisions_retained':True}
(B/'Cross_Channel_Catalog_QA.json').write_text(json.dumps(qa,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in out.items() if k not in ['clusters','exact_identifier_merge_events','possible_title_duplicate_clusters']},ensure_ascii=False))
