import json, hashlib, urllib.request, datetime
from pathlib import Path
from xml.etree import ElementTree as ET

BASE=Path(__file__).resolve().parent/'root_sources'
BASE.mkdir(exist_ok=True)
targets=[('Iqbal2026','https://www.ebi.ac.uk/europepmc/webservices/rest/PMC13438564/fullTextXML'),('Javed2025','https://www.mdpi.com/2079-9292/14/23/4774/xml')]
receipts=[]
for sid,url in targets:
    now=datetime.datetime.now(datetime.timezone.utc).isoformat()
    record={'id':sid,'url':url,'utc_start':now,'full_source_read':False}
    try:
        req=urllib.request.Request(url,headers={'User-Agent':'AcademicLiteratureAudit/1.0','Accept':'application/xml,text/xml,text/html'})
        with urllib.request.urlopen(req,timeout=40) as r:
            data=r.read(); record.update(http_status=r.status,final_url=r.url,content_type=r.headers.get('Content-Type'))
        p=BASE/(sid+'_response.xml'); p.write_bytes(data)
        record.update(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
        root=ET.fromstring(data)
        text='\n'.join(' '.join(x.itertext()) for x in root.findall('.//body/sec'))
        (BASE/(sid+'_body.txt')).write_text(text,encoding='utf-8')
        record['body_characters']=len(text)
        record['sections']=[' '.join(s.find('title').itertext()) for s in root.findall('.//body/sec') if s.find('title') is not None]
    except Exception as e: record['error']=str(e)
    record['utc_end']=datetime.datetime.now(datetime.timezone.utc).isoformat(); receipts.append(record)
(BASE/'Retrieval_Receipts.json').write_text(json.dumps(receipts,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(receipts,ensure_ascii=False,indent=2))
