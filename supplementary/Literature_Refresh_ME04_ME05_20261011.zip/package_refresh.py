import hashlib,json,zipfile,datetime
from pathlib import Path
B=Path(__file__).resolve().parent
qa=json.loads((B/'Final_QA.json').read_text(encoding='utf-8')); assert qa['status']=='PASS'
excluded={'Delivery_Manifest.json','Archive_QA.json','Literature_Refresh_ME04_ME05_20261011.zip'}
files=sorted(p for p in B.rglob('*') if p.is_file() and p.name not in excluded and '__pycache__' not in p.parts)
rows=[{'path':p.relative_to(B).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
manifest={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'purpose':'New targeted literature refresh ME-04/ME-05; historical records and global priority remain qualified','file_count_excluding_manifest':len(rows),'main_report':'ME04_ME05_Literature_Refresh_AR.md','correction_text':'Exact_Manuscript_Corrections_EN.md','QA_status':qa['status'],'files':rows,'not_included':'Original Word/PDFs and external prior-audit files remain in original directories. Their status and identity are cited; no complete bibliography source archive is claimed.'}
(B/'Delivery_Manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
zpath=B/'Literature_Refresh_ME04_ME05_20261011.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files+[B/'Delivery_Manifest.json']:z.write(p,p.relative_to(B).as_posix())
with zipfile.ZipFile(zpath) as z:
    checks={'archive_members_match_manifest':len(z.namelist())==len(rows)+1,'all_archived_file_hashes_match':all(hashlib.sha256(z.read(r['path'])).hexdigest()==r['sha256'] for r in rows),'zip_integrity_pass':z.testzip() is None}
out={'status':'PASS' if all(checks.values()) else 'FAIL','archive':str(zpath),'archive_bytes':zpath.stat().st_size,'archive_sha256':hashlib.sha256(zpath.read_bytes()).hexdigest(),'checks':checks,'members':len(rows)+1}
(B/'Archive_QA.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out,indent=2))
assert out['status']=='PASS'
