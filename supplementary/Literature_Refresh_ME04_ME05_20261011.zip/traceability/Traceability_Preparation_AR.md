# إعداد التتبع لتحديث الأدبيات — 11 أكتوبر 2026

فُحص XML للنسخة الحالية V1.7، وصادرات الأدبيات المتاحة وسجلات تدقيق المصادر السابقة. لم يُعدّل Word ولم يُجرَ بحث أدبي جديد في هذه المهمة الفرعية. حالة قراءة المصادر أدناه موروثة من السجلات المحددة، ولا تعني إعادة فحصها أو إعادة تنفيذ تجاربها.

## مواضع النص التي تحتاج تحديث الحالة

| الموضع | الحالة الحالية | التعديل المحدد |
|---|---|---|
| §2.8، B0288–B0290 | فجوة تجريبية مقيدة بالفعل؛ B0290 ما زالت تذكر مرشحات بالملخص وحدود الصادرات | إضافة نتيجة البحث الجديد الفعلية وتحديث حالات الأوراق التي اكتمل فحصها، مع إبقاء عدم إثبات الأولوية العالمية |
| AppendixA، B0633–B0636 | عدم مصادقة تاريخية عامة تشمل الصادرات | بيان التحقق اللاحق من محتويات الملفات فقط مع الإبقاء على حدود تنفيذ الاستعلامات القديمة |
| AppendixA.2، B0643 | مرشحات إضافية بالملخص | تحديث BFL-STPC وKamatchi وAbbasi، واستبعاد رسالة الماجستير حسب المستخدم؛ بقية المرشحات حسب حالتها الفعلية |
| AppendixB، B0647–B0681 | أعداد تاريخية مع عدم فحص الصادرات | إضافة أعداد الملفات المتحققة، تصحيح هوية ScopusS2، إبقاء PubMed/ACM غير المحسومين |
| AppendixC، B0684 | PubMed وACM غير متحققين تاريخياً | التفريق بين عدد السجلات المصدرة الذي تحقق وإجمالي البحث/السجلات المفقودة الذي لم يتحقق |

Bnnnn = عنصر مباشر مرقم من1 داخل w:body. النص الحرفي والفقرات داخل الجداول محفوظة في Current_Thesis_Logic_and_Search_Blocks.json. الأرقام تعود إلى النسخة الحالية، ولا تُخلط مع محددات V1.5 في التدقيق القديم.

## بذور المصادر الأصلية

| المصدر | السنة/الإصدار | DOI | الوجود في الصادرات المحددة |
|---|---|---|---|
| LLAMAS: Federated Learning for Privacy-Preserving Anomaly Detection in Electronic Health Record Access Control | 2025 | 10.1109/ICDCSW63273.2025.00015 | 2026-08-11_scopus_S1.ris، سجل56؛ scopus_export_Aug 11-2026_S2.ris، سجل3 |
| TANVIR: Privacy-preserving multimodal federated learning pipeline for cyber-resilient healthcare systems | 2026 | 10.1371/journal.pone.0343669 | 2026-08-11_scopus_S2.ris.ris، سجل36؛ 2026-08-11_scopus_S4.ris.ris، سجل36 |
| BFL_STPC: A Blockchain-Based Federated Learning Approach with Secure Third-Party Computation System for Securing Electronic Health Records | 2026 | 10.21203/rs.3.rs-8351477/v1 | لم يحدد في هذا الفحص المحدود؛ ليس دليلاً على الغياب من الأدبيات |
| KAMATCHI: Securing the edge: privacy-preserving federated learning for insider threats in IoT networks | 2025 | 10.1007/s11227-024-06752-z | لم يحدد في هذا الفحص المحدود؛ ليس دليلاً على الغياب من الأدبيات |
| ABBASI: A Privacy-Aware Federated Learning Approach for Insider Threat Detection | 2025 | 10.1109/ITT69610.2025.11352913 | لم يحدد في هذا الفحص المحدود؛ ليس دليلاً على الغياب من الأدبيات |
| SENTURK: Explainable Anomaly Detection Framework for Electronic Health Record Access Logs | 2025 | 10.1109/BigData66926.2025.11400768 | 2026-08-11_scopus_S1.ris، سجل37؛ 2026-08-11_scopus_S3.ri.ris، سجل1؛ export2026.08.11-00.35.08_S1.csv، سجل3؛ export2026.08.11-00.41.13_S3.csv، سجل1 |
| SUTRADHAR: Leveraging Blockchain for Enhanced EHR Access Monitoring: Integrating Context-Aware and Attribute-Based Tools for Comprehensive Data Security | 2026 | 10.1049/blc2.70035 | 2026-08-11_scopus_S1.ris، سجل23 |
| FEADSEQ: FeadSeq: A Personalized Federated Anomaly Detection Framework for Discrete Event Sequences | 2025 | 10.1145/3742896 | 2026-08-11_acm_S4.bib، سجل1 |

## حالة أدلة الجدة الموروثة

| المصدر | نطاق القراءة السابق | ما يضيّق ادعاء الجدة | الحدود |
|---|---|---|---|
| LLAMAS | Inherited original main-text/selected relevant-method and result audit; §§III–VII and Table I, not new reread or replication. | Already uses LSTM-AE, Flower and FedAvg for EHR access. A generic first-combination claim is untenable. No matched FedAvg-versus-SecAgg+ experiment reported in examined source. | Unlabelled real hospital logs; reconstruction errors/flags cannot establish verified TP/FP. One hospital/client assignment is not independent-hospital generalisation. |
| TANVIR | Inherited publisher JATS original relevant sections, §§3.3.3,4.1,4.2.6–4.2.9 and Tables8–9; not all-paper experiment or code verification. | Healthcare FL with privacy components and cost endpoints already exists. Table8 changes DP and secure aggregation together, so it does not isolate SA alone. | IoT and EMR payload task differs from staff EHR access sessions; reported latency endpoints differ from current workflow/message-content endpoints. |
| BFL_STPC | Inherited full text 50 pages; later local cover/relevant pages and all17figures/10tables visually inspected. No new reread this subtask. | Prior preprint combines blockchain/EHR security, FedAvg and STPC, with an STPC ablation. Broad absence-of-FL-plus-protection claims must be removed. | Disease/clinical-feature classification description does not establish staff-access misuse detection. Bundled STPC removal does not establish matched SecAgg+ isolation. Figure/table contradictions remain; no code/prediction replication. |
| KAMATCHI | Inherited full text49pages; later all18figures/11tables/Algorithm1 and41 relevant complete local pages visually inspected. Eight text-only pages not newly visually inspected. | Prior federated insider-detection design includes FedAvg/FedProx comparisons, grouped ablations, sensitivity and reported CI. Cannot claim these kinds of evaluation are absent globally. | IoT simulation/X-IIoTID, not direct EHR staff-access sessions. HMAC authenticity is not proof of cryptographic secure aggregation. Grouped FAWO/HMAC removal does not isolate SA; numerical/statistical ambiguities remain. |
| ABBASI | Inherited full supplied6pages, all6figures,3tables and Algorithm1; complete visual/source-text audit. Conference paper only; related thesis excluded by user. | Prior FedAvg insider detection includes simulated privacy and baselines, but does not establish real cryptographic SecAgg or a matched direct EHR experiment. | CERT4.2 user-level features; Algorithm1 selects checkpoint by testF1; §III.F calls privacy simulation/emulation. Participation and AUC descriptions conflict. Actual source code not checked; no formal DP/privacy proof certification. |
| SENTURK | Inherited all9sourcepages text and visuals;13figures and six displayed numbered tables checked. | الورقة القريبة موضوعياً لا تسد مقارنة FedAvg–SecAgg+ في الأطروحة؛ هذا حكم مقيد بهذه الورقة ولا يثبت الأولوية العالمية. | Centralised synthetic AE/LSTM-AE, not FL/SA. Raw120000logs-to200evaluations mapping, separation and explanation faithfulness unresolved; macro and anomaly-class scores differ. |
| SUTRADHAR | Inherited all21sourcepages text and visuals;8tables/4figures checked. | يوفر المصدر مثالاً مباشراً لحوكمة الوصول إلى EHR مع كشف شذوذ، فيوسع سياق الأدبيات. لكنه لا يغيّر الفجوة الضيقة الخاصة بمقارنة FedAvg/SecAgg+ المتطابقة، لأن FL عمل مستقبلي صريح ولا توجد تجربة تحديثات محمية. لا يثبت هذا المصدر وحده الأولوية العالمية أو تفوق detector الأطروحة. لا يقاس 12.3ms مقابل وقت التدريب/الجولات أو حجم رسائل SecAgg لأنها نقاط نهاية مختلفة. | CAAC/ABAC/Hyperledger/IsolationForest design, FL explicitly future work. Dataset/sample/labels/split not specified adequately; results endpoints internally inconsistent. |
| FEADSEQ | Native ACM S4 bibliographic record only in this subtask; no original full text inspected. | Potential transferable personalised sequence-FL challenge; retain for original-source screening, not rejection based on inaccessible full text. | NOT VERIFIED — FULL SOURCE NOT AVAILABLE TO THIS SUBTASK. Do not infer datasets, metrics, SA absence or comparative performance from title/abstract alone. |

## صياغات إنجليزية مقترحة — لم تُطبق

### TR01 — §2.8 B0290

The contribution is a bounded empirical comparison of standard Flower FedAvg and the implemented SecAgg+ workflow using matched model, sampling and evaluation conditions in the specified synthetic EHR benchmark. The documented literature update of 11 October 2026 evaluates this claim against direct EHR access-detection studies and separately identified transferable federated-security studies. Its executed queries, returned records, screening decisions and access limits are reported separately from the historical August searches. The resulting assessment is confined to the verified studies and retrieved candidates; it does not certify global priority, universally superior detection or complete privacy preservation.

**شرط الاستخدام:** Use only after the parent completes the actual documented11 Octobersearch; append the parent's evidence-based conclusion, including unresolved closest candidates, rather than presuming no equivalent found.

### TR02 — Appendix A opening B0633

The literature review preserves the historical searches in Appendix B and reports later verification and searching separately. On 11 October 2026, the supplied native-export files were structurally inspected and their record counts reconciled against the historical entries where possible. This verified the contents of the received files, but did not independently authenticate every original query execution, filter setting, total-hit count or screening decision. PubMed export gaps and ACM all-results coverage remain explicitly unresolved.

**شرط الاستخدام:** Supported by completed Search_Export_Verification.json; this status update does not depend on the new search.

### TR03 — Appendix A.2 B0643 final two sentences

Subsequent source follow-ups checked the full texts of the retained BFL-STPC and Kamatchi papers, including all their figures and tables, and the six-page Abbasi conference paper. Their unresolved numerical and methodological qualifications remain recorded; source availability does not establish correctness or independent replication. The related Abbasi master's thesis was excluded from the requested review scope. Other candidate access levels are reported individually in the current search register. These targeted checks do not constitute a complete Source Coverage Audit of the bibliography.

**شرط الاستخدام:** Do not say all candidates globally fulltext verified; the scope register only closes six specifically requested papers.

### TR04 — Appendix B.1 Scopus B0647/B0649/B0651/B0653

The supplied native RIS export was inspected on 11 October 2026 and contains [64/4/30/117] records, matching the respective historical count. S2 uses scopus_export_Aug 11-2026_S2.ris; the file named 2026-08-11_scopus_S2.ris.ris is a duplicate of the 117-record S4 export and must not be used as S2. File contents and embedded export dates do not independently authenticate the complete original query and interface settings.

**شرط الاستخدام:** Apply respective count to each row; never reproduce bracketed placeholders in final prose.

### TR05 — Appendix B.2 Webof Science B0656/B0658/B0660; B.4 IEEE B0670/B0672/B0674

The supplied export was inspected on 11 October 2026 and contains [the verified respective count] records, matching the historical entry. This verifies the received file's contents, rather than independently authenticating all original search settings or complete database retrieval.

**شرط الاستخدام:** WOS respective counts28/1/2; IEEE17/5/9. Use prior verification evidence and retain source-platform metadata/date distinctions.

### TR06 — Appendix B.3 PubMed B0663/B0667 and B.5ACM B0677/B0679/B0681

PubMed S1: The supplied CSV was inspected on 11 October 2026 and contains10 records. The historical15-hit total remains unverified and five records remain unreconciled, not screened exclusions. PubMed S3: The historical12-hit count still lacks a retained native export. ACM: Each of the three supplied BibTeX exports contains20 records; database total hits, export range and all-results coverage remain unverified.

**شرط الاستخدام:** Separate the platform-specific notes, retain historical count fields unchanged, and do not replace them with current search totals.

### TR07 — Appendix C opening B0684

The supplied PubMed S1 CSV was inspected on 11 October 2026 and contains10 records, compared with15 hits in the historical search record. Five records remain unreconciled, and PubMed S3 still lacks its recorded12-result export. These are evidence gaps, not screened exclusions. The three supplied ACM BibTeX exports each contain20 records, but their database total hits and complete coverage remain unverified. Other supplied platform exports were reconciled at the file-content level as documented in the11 Octoberverification record. Later search results are reported as a new dated search and are not substituted for the historical values.

**شرط الاستخدام:** Supported by yesterday's completed export audit; newsearch results remain separate.

### TR08 — §2.7 afterB0281 and references; §2.8 B0288–B0289

Related federated-security work also includes a blockchain/EHR preprint combining FedAvg and secure third-party computation (Munusamy and Jothi, 2026), IoT insider detection with grouped component ablations (Kamatchi and Uma, 2025), and a CERT-based FedAvg study with simulated privacy mechanisms (Abbasi et al., 2025). These studies prevent a broad claim that federated detection and update protection have not been combined previously. Their tasks, bundled interventions and reported security mechanisms do not establish the same matched FedAvg–SecAgg+ evaluation on labelled staff-access sessions. Numerical and methodological uncertainties in those sources qualify performance claims without removing their relevance to the research gap.

**شرط الاستخدام:** Citation metadata from local source covers; insert full references and currentsearch candidates. Do not describe abstract-only FeadSeq as absent-SA without fulltext.

### TR09 — NewAppendix A subsection after historical10 Octoberupdate

Literature refresh—11 October 2026. A targeted narrative update tested the bounded contribution claim using the executed public search surfaces listed in the preserved protocol and search log. Platform total hits are reported separately from returned records; top-N web discovery is labelled as such. The new search IDs are local to this refresh and must not be interpreted as identical to the historical S1–S4 topics. The refresh does not reconstruct the original August search, retrospectively authenticate missing historical records, or constitute a systematic review.

**شرط الاستخدام:** Populate actual platforms, exactqueries, dates/times, results, deduplication and decisions from parent finalizedrecords; institutionalnative search must not be claimed unless actually run.

## حدود يجب إبقاؤها صريحة

- البحث الجديد لا يصادق بأثر رجعي على أعداد أغسطس أو قرارات الفرز غير المحفوظة.
- أسماء S1–S4 في بروتوكول التحديث لا تساوي بالضرورة عائلات S1–S4 التاريخية؛ خصوصاً S3/S4.
- عدم العثور على نظير في البحث المستهدف لا يثبت أسبقية عالمية.
- اكتمال الوصول إلى الأوراق الست المطلوبة لا يعني تحقق قائمة المراجع كاملة أو حل تناقضات المصادر.
- رسالة Abbasi الجامعية مستبعدة حسب المستخدم؛ لا تُطلب ولا تُحسب ضمن المصادر المقروءة.
- FeadSeq موثق هنا بسجل تصدير فقط؛ لا تُستنتج منه تفاصيل منهجية أو غياب حماية التحديثات.

SHA256 للرسالة: `e2c88df972cd665596f4b5baf34b92d3c6e5f241f9b3f17e11bf750705c61454`
