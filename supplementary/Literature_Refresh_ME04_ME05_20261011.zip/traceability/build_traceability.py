from pathlib import Path
import csv
import hashlib
import json
import re
import xml.etree.ElementTree as ET
import zipfile

BASE = Path(r'C:/Users/RNO/Desktop/Coureses/P1')
OUT = BASE / 'ars_literature_refresh_2026_10_11/traceability'
DOC = BASE / 'ars_source_update_v1_7_2026_10_10/Research_Report_Chapters_1_to_6_v1_7_ThreeSources_Updated_Highlighted_20261010.docx'
EXPORTS = Path(r'C:/Users/RNO/Desktop/Coureses/FL/الادبيات')
NS = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
OUT.mkdir(parents=True, exist_ok=True)

def read(rel):
    return json.loads((BASE / rel).read_text(encoding='utf-8-sig'))

def save(name, obj):
    (OUT / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')

digest_before = hashlib.sha256(DOC.read_bytes()).hexdigest()
with zipfile.ZipFile(DOC) as z:
    body = ET.fromstring(z.read('word/document.xml')).find('w:body', NS)
blocks = []
paragraph_index = 0
for number, element in enumerate(body, 1):
    paras = []
    for paragraph in element.findall('.//w:p', NS) if element.tag != '{'+NS['w']+'}p' else [element]:
        paragraph_index += 1
        text = ''.join(t.text or '' for t in paragraph.findall('.//w:t', NS))
        paras.append({'flattened_paragraph_1based': paragraph_index, 'text': text})
    text = '\n'.join(p['text'] for p in paras)
    blocks.append({'body_block': f'B{number:04d}', 'body_child_1based': number,
                   'type': element.tag.split('}')[-1], 'text': text,
                   'normalised_text': ' '.join(text.split()), 'paragraphs': paras})

selected = [b for b in blocks if 217 <= b['body_child_1based'] <= 240
            or 273 <= b['body_child_1based'] <= 290
            or 632 <= b['body_child_1based'] <= 719]
save('Current_Thesis_Logic_and_Search_Blocks.json', {
    'date_local': '2026-10-11', 'timezone': 'Asia/Singapore',
    'source_docx': str(DOC), 'source_sha256': digest_before,
    'locator_definition': 'Bnnnn is the one-based direct child of w:body in word/document.xml. Paragraph locators count all w:p elements in body order, including table cells.',
    'text_rule': 'Each paragraph concatenates w:t runs without inserting artificial spaces; table blocks retain paragraph boundaries as newlines.',
    'manuscript_modified': False, 'blocks': selected})
byid = {b['body_block']: b for b in blocks}

seeds = [
 {'id':'LLAMAS', 'title':'Federated Learning for Privacy-Preserving Anomaly Detection in Electronic Health Record Access Control', 'doi':'10.1109/ICDCSW63273.2025.00015', 'year':2025, 'identity_basis':'Current thesis B0616; prior original full-text audit', 'directness':'direct EHR access anomaly detection'},
 {'id':'TANVIR', 'title':'Privacy-preserving multimodal federated learning pipeline for cyber-resilient healthcare systems', 'doi':'10.1371/journal.pone.0343669', 'year':2026, 'identity_basis':'Current thesis B0630; publisher JATS used in prior audit', 'directness':'indirect healthcare IoT/EMR security'},
 {'id':'BFL_STPC', 'title':'A Blockchain-Based Federated Learning Approach with Secure Third-Party Computation System for Securing Electronic Health Records', 'doi':'10.21203/rs.3.rs-8351477/v1', 'year':2026, 'version':'Research Square v1 posted 2026-03-30', 'identity_basis':'Local source cover and BFL_Local_Visual_Audit.json', 'directness':'adjacent EHR security; classification target does not establish staff access-session misuse'},
 {'id':'KAMATCHI', 'title':'Securing the edge: privacy-preserving federated learning for insider threats in IoT networks', 'doi':'10.1007/s11227-024-06752-z', 'year':2025, 'online_publication':'2024-12-05', 'identity_basis':'Local publisher-formatted cover and Kamatchi_Local_Visual_Audit.json', 'directness':'indirect IoT/network insider detection'},
 {'id':'ABBASI', 'title':'A Privacy-Aware Federated Learning Approach for Insider Threat Detection', 'doi':'10.1109/ITT69610.2025.11352913', 'year':2025, 'version':'ITT2025 conference; later 2026 portal/deposit does not change conference year', 'identity_basis':'Local supplied six-page conference PDF and completed fulltext audit', 'directness':'indirect CERT insider classification'},
 {'id':'SENTURK', 'title':'Explainable Anomaly Detection Framework for Electronic Health Record Access Logs', 'doi':'10.1109/BigData66926.2025.11400768', 'year':2025, 'identity_basis':'Local publisher PDF and current thesis B0627; IEEE online indexing March 2026', 'directness':'direct centralised EHR access detection'},
 {'id':'SUTRADHAR', 'title':'Leveraging Blockchain for Enhanced EHR Access Monitoring: Integrating Context-Aware and Attribute-Based Tools for Comprehensive Data Security', 'doi':'10.1049/blc2.70035', 'year':2026, 'identity_basis':'Local published source and current thesis B0628', 'directness':'direct EHR access governance/monitoring; FL future work'},
 {'id':'FEADSEQ', 'title':'FeadSeq: A Personalized Federated Anomaly Detection Framework for Discrete Event Sequences', 'doi':'10.1145/3742896', 'year':2025, 'identity_basis':'Supplied ACM S4 native BibTeX; bibliographic metadata only in this subtask', 'directness':'candidate transferable sequence anomaly method; full text needs separate check'}
]

records = []
for path in sorted(EXPORTS.glob('*.ris')):
    raw = path.read_text(encoding='utf-8-sig', errors='replace')
    for n, chunk in enumerate(re.split(r'^TY\s+-\s*', raw, flags=re.M)[1:], 1):
        fields = {}
        for line in chunk.splitlines()[1:]:
            match = re.match(r'^([A-Z0-9]{2})\s+-\s*(.*)', line)
            if match:
                fields.setdefault(match.group(1), []).append(match.group(2))
        records.append({'file':str(path), 'record_1based':n,
            'title':' '.join(fields.get('TI', fields.get('T1', []))),
            'doi':' '.join(fields.get('DO', [])), 'year':' '.join(fields.get('PY', fields.get('Y1', []))),
            'authors':fields.get('AU', []), 'urls':fields.get('UR', []),
            'dates':fields.get('N1', []), 'verified_as':'export metadata, not scientific full text'})
for path in sorted(EXPORTS.glob('*.csv')):
    with path.open(encoding='utf-8-sig', errors='replace', newline='') as f:
        for n,row in enumerate(csv.DictReader(f),1):
            records.append({'file':str(path), 'record_1based':n,
                'title':row.get('Document Title',row.get('Title','')),
                'doi':row.get('DOI',''), 'year':row.get('Publication Year',''),
                'authors':row.get('Authors',''), 'verified_as':'export metadata, not scientific full text'})
bib_audit = read('ars_search_export_verification_2026_10_11/Bib_RIS_Verification.json')
for f in bib_audit['files']:
    if str(f['file']).endswith('.bib'):
        for r in f['records']:
            records.append({'file':f['path'], 'record_1based':r['record_number'],
                'title':r['title'], 'doi':r.get('doi'), 'year':r.get('year'),
                'verified_as':'prior checked export metadata, not scientific full text'})
for seed in seeds:
    seed['export_occurrences'] = [r for r in records if str(r.get('doi','')).strip().lower()==seed['doi'].lower()]
    seed['export_match_status'] = 'FOUND_IN_SUPPLIED_EXPORTS' if seed['export_occurrences'] else 'NOT_IDENTIFIED_IN_BOUNDED_SUPPLIED_EXPORT_SCAN'
save('Original_Source_Seeds.json', {'date_local':'2026-10-11', 'scope':'Exact DOI matches in the supplied literature folder RIS/CSV and prior checked three ACM BibTeX records. Not a new database search or proof of historic inclusion.', 'seeds':seeds})

sent = read('ars_source_update_v1_7_2026_10_10/Senturk_Audit.json')
sutr = read('ars_source_update_v1_7_2026_10_10/Sutradhar_Audit.json')
bfl = read('ars_local_figures_closure_2026_10_10/bfl/BFL_Local_Visual_Audit.json')
kam = read('ars_local_figures_closure_2026_10_10/kamatchi/Kamatchi_Local_Visual_Audit.json')
abb = read('ars_abbasi_fulltext_update_2026_10_10/Root_Review_Evidence.json')
receipts = read('ars_source_verification_v1_5_2026_10_09/source_front_receipts.json')
front = read('ars_source_verification_v1_5_2026_10_09/source_front_extractions.json')
def find_dict(obj, key, value):
    if isinstance(obj,dict):
        if obj.get(key)==value: return obj
        for v in obj.values():
            found = find_dict(v,key,value)
            if found is not None:return found
    if isinstance(obj,list):
        for v in obj:
            found=find_dict(v,key,value)
            if found is not None:return found
    return None
llamas_receipt=find_dict(receipts,'id','MartinezLlamas2025')
llamas_extract=find_dict(front,'id','MartinezLlamas2025')
status = [
 {'id':'LLAMAS','read_scope':'Inherited original main-text/selected relevant-method and result audit; §§III–VII and Table I, not new reread or replication.', 'evidence_files':['ars_source_verification_v1_5_2026_10_09/source_front_receipts.json','ars_source_verification_v1_5_2026_10_09/source_front_extractions.json'], 'receipt':llamas_receipt, 'source_profile':llamas_extract, 'novelty_implication':'Already uses LSTM-AE, Flower and FedAvg for EHR access. A generic first-combination claim is untenable. No matched FedAvg-versus-SecAgg+ experiment reported in examined source.', 'limits':'Unlabelled real hospital logs; reconstruction errors/flags cannot establish verified TP/FP. One hospital/client assignment is not independent-hospital generalisation.'},
 {'id':'TANVIR','read_scope':'Inherited publisher JATS original relevant sections, §§3.3.3,4.1,4.2.6–4.2.9 and Tables8–9; not all-paper experiment or code verification.', 'evidence_files':['ars_literature_audit_v1_5_2026_10_09/recent_direct_matrix.json','ars_gap_audit_v1_5_2026_10_09/Tanvir2026_pone0343669_publisher.xml'], 'novelty_implication':'Healthcare FL with privacy components and cost endpoints already exists. Table8 changes DP and secure aggregation together, so it does not isolate SA alone.', 'limits':'IoT and EMR payload task differs from staff EHR access sessions; reported latency endpoints differ from current workflow/message-content endpoints.'},
 {'id':'BFL_STPC','read_scope':'Inherited full text 50 pages; later local cover/relevant pages and all17figures/10tables visually inspected. No new reread this subtask.', 'evidence_files':['ars_local_figures_closure_2026_10_10/bfl/BFL_Local_Visual_Audit.json'], 'scope_receipt':bfl['scope'], 'novelty_implication':'Prior preprint combines blockchain/EHR security, FedAvg and STPC, with an STPC ablation. Broad absence-of-FL-plus-protection claims must be removed.', 'limits':'Disease/clinical-feature classification description does not establish staff-access misuse detection. Bundled STPC removal does not establish matched SecAgg+ isolation. Figure/table contradictions remain; no code/prediction replication.'},
 {'id':'KAMATCHI','read_scope':'Inherited full text49pages; later all18figures/11tables/Algorithm1 and41 relevant complete local pages visually inspected. Eight text-only pages not newly visually inspected.', 'evidence_files':['ars_local_figures_closure_2026_10_10/kamatchi/Kamatchi_Local_Visual_Audit.json'], 'scope_receipt':kam['scope'], 'novelty_implication':'Prior federated insider-detection design includes FedAvg/FedProx comparisons, grouped ablations, sensitivity and reported CI. Cannot claim these kinds of evaluation are absent globally.', 'limits':'IoT simulation/X-IIoTID, not direct EHR staff-access sessions. HMAC authenticity is not proof of cryptographic secure aggregation. Grouped FAWO/HMAC removal does not isolate SA; numerical/statistical ambiguities remain.'},
 {'id':'ABBASI','read_scope':'Inherited full supplied6pages, all6figures,3tables and Algorithm1; complete visual/source-text audit. Conference paper only; related thesis excluded by user.', 'evidence_files':['ars_abbasi_fulltext_update_2026_10_10/Root_Review_Evidence.json','ars_abbasi_fulltext_update_2026_10_10/Abbasi_Fulltext_Audit_AR.md'], 'scope_receipt':abb, 'novelty_implication':'Prior FedAvg insider detection includes simulated privacy and baselines, but does not establish real cryptographic SecAgg or a matched direct EHR experiment.', 'limits':'CERT4.2 user-level features; Algorithm1 selects checkpoint by testF1; §III.F calls privacy simulation/emulation. Participation and AUC descriptions conflict. Actual source code not checked; no formal DP/privacy proof certification.'},
 {'id':'SENTURK','read_scope':'Inherited all9sourcepages text and visuals;13figures and six displayed numbered tables checked.', 'evidence_files':['ars_source_update_v1_7_2026_10_10/Senturk_Audit.json'], 'scope_receipt':sent['coverage'], 'novelty_implication':sent['FL_SecAgg']['gap_implication_ar'], 'limits':'Centralised synthetic AE/LSTM-AE, not FL/SA. Raw120000logs-to200evaluations mapping, separation and explanation faithfulness unresolved; macro and anomaly-class scores differ.'},
 {'id':'SUTRADHAR','read_scope':'Inherited all21sourcepages text and visuals;8tables/4figures checked.', 'evidence_files':['ars_source_update_v1_7_2026_10_10/Sutradhar_Audit.json'], 'scope_receipt':sutr['coverage'], 'novelty_implication':sutr['gap_assessment_ar'], 'limits':'CAAC/ABAC/Hyperledger/IsolationForest design, FL explicitly future work. Dataset/sample/labels/split not specified adequately; results endpoints internally inconsistent.'},
 {'id':'FEADSEQ','read_scope':'Native ACM S4 bibliographic record only in this subtask; no original full text inspected.', 'evidence_files':['ars_search_export_verification_2026_10_11/Bib_RIS_Verification.json'], 'novelty_implication':'Potential transferable personalised sequence-FL challenge; retain for original-source screening, not rejection based on inaccessible full text.', 'limits':'NOT VERIFIED — FULL SOURCE NOT AVAILABLE TO THIS SUBTASK. Do not infer datasets, metrics, SA absence or comparative performance from title/abstract alone.'}
]
for row in status:
    row['source_verification_origin']='INHERITED_COMPLETED_LOCAL_AUDIT' if row['id']!='FEADSEQ' else 'EXPORT_METADATA_ONLY'
    row['evidence_files']=[str(BASE/p) for p in row['evidence_files']]
save('Inherited_Novelty_Evidence_Status.json', {'date_local':'2026-10-11','scope':'Local evidence preparation, not a new source audit, full-bibliography coverage audit or literature search. Prior receipts are preserved and explicit about source readscope. All studies remain unreplicated.', 'related_master_thesis':'EXCLUDED_BY_USER; not requested and not counted as read', 'sources':status})

proposals=[
 {'id':'TR01','location':'§2.8 B0290','kind':'replace complete paragraph; refresh-dependent final insertion','old':byid['B0290']['text'], 'proposed':'The contribution is a bounded empirical comparison of standard Flower FedAvg and the implemented SecAgg+ workflow using matched model, sampling and evaluation conditions in the specified synthetic EHR benchmark. The documented literature update of 11 October 2026 evaluates this claim against direct EHR access-detection studies and separately identified transferable federated-security studies. Its executed queries, returned records, screening decisions and access limits are reported separately from the historical August searches. The resulting assessment is confined to the verified studies and retrieved candidates; it does not certify global priority, universally superior detection or complete privacy preservation.', 'condition':'Use only after the parent completes the actual documented11Octobersearch; append the parent\'s evidence-based conclusion, including unresolved closest candidates, rather than presuming no equivalent found.'},
 {'id':'TR02','location':'AppendixA opening B0633','kind':'replace first two sentences; preserve later September sentence','old_excerpt':'The literature review records the historical searches detailed here and in Appendix B. Their recorded counts are retained, with unresolved export completeness stated explicitly. The original dated search responses, saved histories and native exports were not independently authenticated for this revision; recorded claims that exports were retained or audited are not new verification findings.', 'proposed':'The literature review preserves the historical searches in Appendix B and reports later verification and searching separately. On 11 October 2026, the supplied native-export files were structurally inspected and their record counts reconciled against the historical entries where possible. This verified the contents of the received files, but did not independently authenticate every original query execution, filter setting, total-hit count or screening decision. PubMed export gaps and ACM all-results coverage remain explicitly unresolved.', 'condition':'Supported by completed Search_Export_Verification.json; this status update does not depend on the new search.'},
 {'id':'TR03','location':'AppendixA.2 B0643 final two sentences','kind':'replace stale candidate-status ending, preserving three-source follow-up history','old_excerpt':'Additional abstract-only preprint candidates are retained in the update register, not used as verified performance evidence. Section-specific checking does not constitute a complete Source Coverage Audit.', 'proposed':'Subsequent source follow-ups checked the full texts of the retained BFL-STPC and Kamatchi papers, including all their figures and tables, and the six-page Abbasi conference paper. Their unresolved numerical and methodological qualifications remain recorded; source availability does not establish correctness or independent replication. The related Abbasi master\'s thesis was excluded from the requested review scope. Other candidate access levels are reported individually in the current search register. These targeted checks do not constitute a complete Source Coverage Audit of the bibliography.', 'condition':'Do not say all candidates globally fulltext verified; the scope register only closes six specifically requested papers.'},
 {'id':'TR04','location':'AppendixB.1 Scopus B0647/B0649/B0651/B0653','kind':'replace integrity note only','proposed':'The supplied native RIS export was inspected on 11 October 2026 and contains [64/4/30/117] records, matching the respective historical count. S2 uses scopus_export_Aug 11-2026_S2.ris; the file named 2026-08-11_scopus_S2.ris.ris is a duplicate of the117-recordS4 export and must not be used as S2. File contents and embedded export dates do not independently authenticate the complete original query and interface settings.', 'condition':'Apply respective count to each row; never reproduce bracketed placeholders in final prose.'},
 {'id':'TR05','location':'AppendixB.2 WebofScience B0656/B0658/B0660; B.4 IEEE B0670/B0672/B0674','kind':'replace integrity notes only','proposed':'The supplied export was inspected on 11 October 2026 and contains [the verified respective count] records, matching the historical entry. This verifies the received file\'s contents, rather than independently authenticating all original search settings or complete database retrieval.', 'condition':'WOS respective counts28/1/2; IEEE17/5/9. Use prior verification evidence and retain source-platform metadata/date distinctions.'},
 {'id':'TR06','location':'AppendixB.3 PubMed B0663/B0667 and B.5ACM B0677/B0679/B0681','kind':'update partial export status without claiming historical closure','proposed':'PubMedS1: The supplied CSV was inspected on 11 October2026 and contains10records. The historical15-hit total remains unverified and five records remain unreconciled, not screened exclusions. PubMedS3: The historical12-hit count still lacks a retained native export. ACM: Each of the three supplied BibTeX exports contains20records; database total hits, export range and all-results coverage remain unverified.', 'condition':'Separate the platform-specific notes, retain historical count fields unchanged, and do not replace them with current search totals.'},
 {'id':'TR07','location':'AppendixC opening B0684','kind':'replace complete paragraph','old':byid['B0684']['text'], 'proposed':'The supplied PubMedS1 CSV was inspected on 11 October2026 and contains10records, compared with15hits in the historical search record. Five records remain unreconciled, and PubMedS3 still lacks its recorded12-result export. These are evidence gaps, not screened exclusions. The three supplied ACM BibTeX exports each contain20records, but their database total hits and complete coverage remain unverified. Other supplied platform exports were reconciled at the file-content level as documented in the11Octoberverification record. Later search results are reported as a new dated search and are not substituted for the historical values.', 'condition':'Supported by yesterday\'s completed export audit; newsearch results remain separate.'},
 {'id':'TR08','location':'§2.7 afterB0281 and references; §2.8 B0288–B0289','kind':'insert inherited closest-source contrast, verify newsearch candidates before final claim','proposed':'Related federated-security work also includes a blockchain/EHR preprint combining FedAvg and secure third-party computation (Munusamy and Jothi,2026), IoT insider detection with grouped component ablations (Kamatchi and Uma,2025), and a CERT-based FedAvg study with simulated privacy mechanisms (Abbasi et al.,2025). These studies prevent a broad claim that federated detection and update protection have not been combined previously. Their tasks, bundled interventions and reported security mechanisms do not establish the same matched FedAvg–SecAgg+ evaluation on labelled staff-access sessions. Numerical and methodological uncertainties in those sources qualify performance claims without removing their relevance to the research gap.', 'condition':'Citation metadata from local source covers; insert full references and currentsearch candidates. Do not describe abstract-only FeadSeq as absent-SA without fulltext.'},
 {'id':'TR09','location':'NewAppendixA subsection after historical10Octoberupdate','kind':'add explicit refreshscope','proposed':'Literature refresh—11October2026. A targeted narrative update tested the bounded contribution claim using the executed public search surfaces listed in the preserved protocol and search log. Platform total hits are reported separately from returned records; top-N web discovery is labelled as such. The new search IDs are local to this refresh and must not be interpreted as identical to the historical S1–S4 topics. The refresh does not reconstruct the original August search, retrospectively authenticate missing historical records, or constitute a systematic review.', 'condition':'Populate actual platforms, exactqueries, dates/times, results, deduplication and decisions from parent finalizedrecords; institutionalnative search must not be claimed unless actually run.'}
]
save('Proposed_English_Substitutions_NOT_APPLIED.json', {'date_local':'2026-10-11','source_docx_sha256':digest_before,'manuscript_modified':False,'proposal_status':'NOT_APPLIED; current-search-dependent items require final evidence-based wording from parent', 'proposals':proposals})

# Presentation-only spacing fixes; do not alter DOIs, exact source text or locators.
spacing = {'11October':'11 October', '11 October2026':'11 October 2026',
           '11October2026':'11 October 2026', 'PubMedS1':'PubMed S1',
           'PubMedS3':'PubMed S3', 'ofScience':'of Science',
           '20records':'20 records', '10records':'10 records',
           '15hits':'15 hits', 'five records':'five records',
           'the117-recordS4':'the 117-record S4', 'AppendixA':'Appendix A',
           'AppendixB':'Appendix B', 'AppendixC':'Appendix C',
           'Munusamy and Jothi,2026':'Munusamy and Jothi, 2026',
           'Kamatchi and Uma,2025':'Kamatchi and Uma, 2025',
           'Abbasi et al.,2025':'Abbasi et al., 2025',
           '10October':'10 October'}
for proposal in proposals:
    for key in ['proposed','condition','location']:
        for before,after in spacing.items():
            proposal[key]=proposal[key].replace(before,after)
save('Proposed_English_Substitutions_NOT_APPLIED.json', {'date_local':'2026-10-11','source_docx_sha256':digest_before,'manuscript_modified':False,'proposal_status':'NOT_APPLIED; current-search-dependent items require final evidence-based wording from parent', 'proposals':proposals})

extra = {
 'IKegwu_2026': {
  'title':'Advancing Federated Learning Frameworks for Privacy-preserving Cyber Threat Detection in Healthcare Systems',
  'doi':'10.1007/s44196-026-01274-3',
  'primary_html':'https://link.springer.com/article/10.1007/s44196-026-01274-3',
  'publication_date':'2026-03-30',
  'not_same_as_Tanvir':True,
  'previous_local_review':str(BASE/'ars_gap_audit_v1_5_2026_10_09/recent_counterevidence_AR.md'),
  'previous_review_lines':[31,33,35,37],
  'previous_machine_receipt':str(BASE/'ars_gap_audit_v1_5_2026_10_09/recent_counterevidence_searchlog.json'),
  'receipt_id':'R2',
  'read_scope':'Inherited full publisher HTML available; focused sections3.3–3.9 and4.1–4.2 checked. Not full-source certification or independent implementation.',
  'relevance':'Healthcare IoMT/network detection; Bonawitz in TensorFlow Federated explicitly reported. Comparators centralised/FedAvg/DP/HE/DP+HE do not clearly isolate Bonawitz on/off.',
  'limits':'CO/CL equations15–16 use TP+TN and FP+FN but later discussion treats them as communication/latency. Binary method versus three-class result description unresolved.',
  'in_current_v1_7_bibliography':False
 },
 'Iqbal_2026':{
  'title':'Enhancing healthcare information security through VAE-driven anomaly detection in EHR access patterns',
  'doi':'10.1038/s41598-026-55024-8',
  'primary_html':'https://www.nature.com/articles/s41598-026-55024-8',
  'current_bibliography':'B0610',
  'current_literature_paragraph':'§2.7 B0279',
  'current_status':'Already covered, rediscovery not a new omission.',
  'previous_local_evidence':str(BASE/'ars_literature_audit_v1_5_2026_10_09/recent_direct_matrix.json'),
  'read_scope':'Inherited original indexed publisher sections, not a new fullsource/PDF or implementation audit.'
 }
}
save('Additional_Prior_Coverage_Clarifications.json',extra)

lines=['# إعداد التتبع لتحديث الأدبيات — 11 أكتوبر 2026','',
 'فُحص XML للنسخة الحالية V1.7، وصادرات الأدبيات المتاحة وسجلات تدقيق المصادر السابقة. لم يُعدّل Word ولم يُجرَ بحث أدبي جديد في هذه المهمة الفرعية. حالة قراءة المصادر أدناه موروثة من السجلات المحددة، ولا تعني إعادة فحصها أو إعادة تنفيذ تجاربها.', '',
 '## مواضع النص التي تحتاج تحديث الحالة','',
 '| الموضع | الحالة الحالية | التعديل المحدد |','|---|---|---|',
 '| §2.8، B0288–B0290 | فجوة تجريبية مقيدة بالفعل؛ B0290 ما زالت تذكر مرشحات بالملخص وحدود الصادرات | إضافة نتيجة البحث الجديد الفعلية وتحديث حالات الأوراق التي اكتمل فحصها، مع إبقاء عدم إثبات الأولوية العالمية |',
 '| AppendixA، B0633–B0636 | عدم مصادقة تاريخية عامة تشمل الصادرات | بيان التحقق اللاحق من محتويات الملفات فقط مع الإبقاء على حدود تنفيذ الاستعلامات القديمة |',
 '| AppendixA.2، B0643 | مرشحات إضافية بالملخص | تحديث BFL-STPC وKamatchi وAbbasi، واستبعاد رسالة الماجستير حسب المستخدم؛ بقية المرشحات حسب حالتها الفعلية |',
 '| AppendixB، B0647–B0681 | أعداد تاريخية مع عدم فحص الصادرات | إضافة أعداد الملفات المتحققة، تصحيح هوية ScopusS2، إبقاء PubMed/ACM غير المحسومين |',
 '| AppendixC، B0684 | PubMed وACM غير متحققين تاريخياً | التفريق بين عدد السجلات المصدرة الذي تحقق وإجمالي البحث/السجلات المفقودة الذي لم يتحقق |', '',
 'Bnnnn = عنصر مباشر مرقم من1 داخل w:body. النص الحرفي والفقرات داخل الجداول محفوظة في Current_Thesis_Logic_and_Search_Blocks.json. الأرقام تعود إلى النسخة الحالية، ولا تُخلط مع محددات V1.5 في التدقيق القديم.', '',
 '## بذور المصادر الأصلية','', '| المصدر | السنة/الإصدار | DOI | الوجود في الصادرات المحددة |','|---|---|---|---|']
for s in seeds:
    occ='؛ '.join(f"{Path(r['file']).name}، سجل{r['record_1based']}" for r in s['export_occurrences']) or 'لم يحدد في هذا الفحص المحدود؛ ليس دليلاً على الغياب من الأدبيات'
    lines.append(f"| {s['id']}: {s['title']} | {s['year']} | {s['doi']} | {occ} |")
lines += ['', '## حالة أدلة الجدة الموروثة','', '| المصدر | نطاق القراءة السابق | ما يضيّق ادعاء الجدة | الحدود |','|---|---|---|---|']
for s in status:
    lines.append('| '+' | '.join(str(s[k]).replace('|','/').replace('\n',' ') for k in ['id','read_scope','novelty_implication','limits'])+' |')
lines += ['', '## صياغات إنجليزية مقترحة — لم تُطبق','']
for item in proposals:
    lines += [f"### {item['id']} — {item['location']}", '', item['proposed'], '', '**شرط الاستخدام:** '+item['condition'], '']
lines += ['## حدود يجب إبقاؤها صريحة','',
 '- البحث الجديد لا يصادق بأثر رجعي على أعداد أغسطس أو قرارات الفرز غير المحفوظة.',
 '- أسماء S1–S4 في بروتوكول التحديث لا تساوي بالضرورة عائلات S1–S4 التاريخية؛ خصوصاً S3/S4.',
 '- عدم العثور على نظير في البحث المستهدف لا يثبت أسبقية عالمية.',
 '- اكتمال الوصول إلى الأوراق الست المطلوبة لا يعني تحقق قائمة المراجع كاملة أو حل تناقضات المصادر.',
 '- رسالة Abbasi الجامعية مستبعدة حسب المستخدم؛ لا تُطلب ولا تُحسب ضمن المصادر المقروءة.',
 '- FeadSeq موثق هنا بسجل تصدير فقط؛ لا تُستنتج منه تفاصيل منهجية أو غياب حماية التحديثات.', '',
 'SHA256 للرسالة: `'+digest_before+'`']
(OUT/'Traceability_Preparation_AR.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
digest_after=hashlib.sha256(DOC.read_bytes()).hexdigest()
save('Traceability_QA.json', {'thesis_before_sha256':digest_before,'thesis_after_sha256':digest_after,'thesis_unchanged':digest_before==digest_after,'selected_block_count':len(selected),'seeds':len(seeds),'evidence_sources':len(status),'proposals':len(proposals),'no_new_search':True,'no_manuscript_edit':True,'output_files':[p.name for p in OUT.glob('*') if p.is_file()]})
print(json.dumps({'status':'PASS','output_folder':str(OUT),'thesis_unchanged':digest_before==digest_after,'seed_export_matches':{s['id']:len(s['export_occurrences']) for s in seeds},'files':[p.name for p in OUT.glob('*') if p.is_file()]},ensure_ascii=False))
