import urllib.request,urllib.parse,json,hashlib,datetime
from pathlib import Path
B=Path(__file__).resolve().parent/'reference_metadata'; B.mkdir(exist_ok=True)
dois=['10.51983/ijiss-2026.16.1.27','10.3233/SHTI260582','10.3390/electronics14234774','10.21203/rs.3.rs-8351477/v1','10.1007/s11227-024-06752-z','10.1109/ITT69610.2025.11352913','10.1145/3742896','10.1109/ACCESS.2024.3486810','10.1007/s44196-026-01274-3','10.3390/electronics15143124']
prior={r['doi']:r for r in json.loads((B/'Metadata_Verification.json').read_text(encoding='utf-8'))} if (B/'Metadata_Verification.json').exists() else {}
out=[]
for i,doi in enumerate(dois,1):
    if doi in prior:
        out.append(prior[doi]); continue
    url='https://api.crossref.org/works/'+urllib.parse.quote(doi,safe='')
    rec={'doi':doi,'url':url,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verification_scope':'BIBLIOGRAPHIC_METADATA_ONLY; DOES_NOT_VERIFY_SCIENTIFIC_CLAIMS'}
    try:
        req=urllib.request.Request(url,headers={'User-Agent':'AcademicLiteratureAudit/1.0'})
        with urllib.request.urlopen(req,timeout=20) as r: raw=r.read(); rec['http_status']=r.status
        p=B/f'CR{i:02}.json'; p.write_bytes(raw); m=json.loads(raw)['message']
        rec.update(raw_file=str(p),sha256=hashlib.sha256(raw).hexdigest(),title=m.get('title'),author=m.get('author'),container=m.get('container-title'),volume=m.get('volume'),issue=m.get('issue'),page=m.get('page'),published=m.get('published'),published_online=m.get('published-online'),type=m.get('type'),publisher=m.get('publisher'))
    except Exception as e: rec['error']=str(e)
    out.append(rec)
(B/'Metadata_Verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(out,ensure_ascii=False,indent=2))
