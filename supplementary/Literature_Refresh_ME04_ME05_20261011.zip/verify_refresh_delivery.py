import json,hashlib,re,csv
from pathlib import Path
B=Path(__file__).resolve().parent
if not (B/'Final_QA.json').exists():
    (B/'Final_QA.json').write_text('{"status":"IN_PROGRESS"}',encoding='utf-8')
def rd(p):return json.loads((B/p).read_text(encoding='utf-8-sig'))
checks=[]
def ck(name,result,detail=None): checks.append({'check':name,'pass':bool(result),'detail':detail})
reg=rd('Unified_Search_Register.json');api=rd('public_api/Screening_Union.json');w=rd('web/Unified_Web_Screening_QA.json');cat=rd('Cross_Channel_Catalog_QA.json');patch=rd('Exact_Manuscript_Corrections.json')
ck('51 distinct exact search queries',len(reg)==51 and len({r['refresh_query_id'] for r in reg})==51)
ck('8 publicAPI plus43 webindex queries',sum(r['platform']=='web_index' for r in reg)==43)
ck('every API sourceID screened',len(api)==281 and len({r['stable_source_id'] for r in api})==281)
ck('API screen reasons and provenance present',all(r.get('reason') and r.get('database_provenance') for r in api))
ck('API independent reconciliation passed',rd('public_api/Screening_Count_Reconciliation_QA.json')['status']=='PASS')
ck('publicAPI retrieval independentQA passed',rd('public_api/Delivery_QA.json')['status']=='PASS')
receipts=rd('public_api/HTTP_Request_Receipts.json')
ck('12 originalAPI responses preserved and hashes match',len(receipts)==12 and all(Path(r['response_raw_file']).exists() and hashlib.sha256(Path(r['response_raw_file']).read_bytes()).hexdigest()==r['sha256'] and r['http_status']==200 for r in receipts))
ck('all returnedweb records preserved and screened',w['total_returned_occurrences']==202 and w['total_normalized_unique_url_candidates']==182 and w['all_rows_decided_with_reason'] and w['all_raw_search_markers_reconciled'])
ck('web counts reconcile',sum(w['decision_counts_unique_url_candidates'].values())==182 and sum(w['decision_counts_occurrences'].values())==202)
ck('no conflicting sameURLscreening decisions',not w['same_url_decision_conflicts'])
ck('crosschannel catalog reconciles inputs and exactmerges',cat['all_input_nodes_preserved'] and cat['unique_input_ids'] and cat['merge_count_reconciles'])
ck('catalog doesnotpretend clusters are unique studies',cat['counts_are_studies'] is False)
ck('23 exact localized correction entries',len(patch['patches'])==23)
ck('correction entries contain no count placeholders',all(not re.search(r'\[64|\[the verified|\[the verified respective',p['text']) for p in patch['patches']))
ck('ten DOI bibliographicidentities verified',len(rd('reference_metadata/Metadata_Verification.json'))==10 and all(r.get('http_status')==200 for r in rd('reference_metadata/Metadata_Verification.json')))
src=rd('traceability/Current_Thesis_Logic_and_Search_Blocks.json')
ck('originalWord untouched',hashlib.sha256(Path(src['source_docx']).read_bytes()).hexdigest()==src['source_sha256'],src['source_sha256'])
report=(B/'ME04_ME05_Literature_Refresh_AR.md').read_text(encoding='utf-8')
ck('finalreport no placeholders',not re.search(r'PLACEHOLDER|\bTODO\b',report))
ck('historicalcounts and globalpriority limits explicit','PARTIALLY VERIFIED HISTORICAL RECORD' in report and 'الأولوية العالمية' in report)
ck('fulltextcoverage not inflated','NOT VERIFIED — FULL SOURCE NOT AVAILABLE' in report and 'لم تُفحص جميع النصوص الأصلية' in report)
ck('Wordcorrections labelednotapplied','لم يُعدّل' in report and 'NOT_APPLIED' in patch['status'])
ck('all localmainreport links resolve',all((B/link).exists() for link in re.findall(r'\]\(([^)]+)\)',report) if not link.startswith('http')))
plan=rd('Progress_Plan.json')['steps']
ck('plan prefixes percentages coherent',all(re.match(r'^\[(?:100|[0-9]{1,2})%\] ',s['step']) and (s['status']!='completed' or s['step'].startswith('[100%]')) for s in plan) and sum(s['status']=='in_progress' for s in plan)<=1)
out={'status':'PASS' if all(r['pass'] for r in checks) else 'FAIL','checks':checks,'checks_count':len(checks),'raw_files_modified':False,'manuscript_modified':False,'newMLexperiments_executed':False,'globalnovelty_certified':False,'historicalAugust_fullcounts_authenticated':False,'scope':'Data-flow/source-status/artifact verification; not external scientific replication or human dual screening.'}
(B/'Final_QA.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(out,ensure_ascii=False,indent=2))
raise SystemExit(0 if out['status']=='PASS' else 1)
