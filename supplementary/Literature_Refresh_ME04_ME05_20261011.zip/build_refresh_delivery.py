import csv, json, re, hashlib, datetime
from pathlib import Path

BASE=Path(__file__).resolve().parent
def read(p): return json.loads((BASE/p).read_text(encoding='utf-8-sig'))
def save(p,d): (BASE/p).write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
def csvout(p,rows):
    fields=list(dict.fromkeys(k for r in rows for k in r))
    with (BASE/p).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fields); w.writeheader()
        for r in rows: w.writerow({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else v for k,v in r.items()})

api=read('public_api/Search_Result_Manifest.json')
register=[]
for r in api['queries']:
    register.append({'refresh_query_id':'REFRESH_'+r['database'].upper()+'_'+r['search_id'],'platform':r['database'],'exact_query':r['query_string'],'source_manifest':'public_api/Search_Result_Manifest.json','counts_and_translation':'See exact preserved entry; no historical replacement','query_scope':r['query_scope'],'search_url':r['search_url']})
for p in sorted((BASE/'web').glob('WEB*Raw.json')):
    d=json.loads(p.read_text(encoding='utf-8-sig'))
    for i,q in enumerate(d['input']['search_query'],1):
        register.append({'refresh_query_id':'REFRESH_'+d['search_id']+'_Q'+str(i),'platform':'web_index','exact_query':q['q'],'source_manifest':str(p.relative_to(BASE)),'started_utc':d['started_utc'],'ended_utc':d['ended_utc'],'total_hits':None,'counts_and_translation':'TOP_RESULTS; batch-level returned provenance; engine total unavailable'})
for q in read('challengers/Search_Ledger.json')['queries']:
    register.append({'refresh_query_id':'REFRESH_'+q['tool_call_id']+'_Q'+str(q['query_index_in_call']),'platform':'web_index','exact_query':q['exact_query'],'source_manifest':'challengers/Search_Ledger.json','started_utc':q['timestamp_utc'],'total_hits':None,'counts_and_translation':q['count_semantics']})
save('Unified_Search_Register.json',register); csvout('Unified_Search_Register.csv',register)

seeds=read('traceability/Original_Source_Seeds.json')['seeds']
inherited={x['id']:x for x in read('traceability/Inherited_Novelty_Evidence_Status.json')['sources']}
matrix=[]
for x in seeds:
    e=inherited[x['id']]
    matrix.append({'study_id':x['id'],'study':x['title'],'doi':x['doi'],'year':x['year'],'domain':x['directness'],'access_and_read_scope':e['read_scope'],'novelty_assessment':e['novelty_implication'],'limitations':e['limits'],'evidence_origin':'INHERITED_ORIGINAL_SOURCE_AUDIT' if x['id']!='FEADSEQ' else 'METADATA_ONLY_HERE','evidence_files':e['evidence_files'],'global_equivalence_determined':False})
for x in read('challengers/Normalized_Candidates.json')['candidates']:
    existing=next((r for r in matrix if x.get('doi') and str(r.get('doi')).lower()==str(x.get('doi')).lower()),None)
    row={'study_id':x['record_id'],'study':x['title'],'doi':x.get('doi'),'year':x['year'],'domain':x['relevance_class'],'access_and_read_scope':x['access_level'],'novelty_assessment':x['relation_to_specific_novelty_claim'],'limitations':x['reason'],'verified_source_url':x['verified_source_url'],'evidence_origin':'NEW_TARGETED_RETRIEVAL_WITH_EXPLICIT_READ_SCOPE','global_equivalence_determined':False}
    if existing:
        existing['current_refresh_followup']=row
    else: matrix.append(row)
for x in read('root_sources/Root_Source_Assessment.json')['sources']:
    row={'study_id':x['id'],'study':x['title'],'doi':x['doi'],'domain':x['task'],'access_and_read_scope':x['read_scope'],'novelty_assessment':x['novelty_evidence'],'limitations':x.get('qualifications',x.get('comparison_limit')),'verified_source_url':x['url'],'evidence_origin':'NEW_RETRIEVAL_EXPLICIT_READ_SCOPE','global_equivalence_determined':False}
    existing=next((r for r in matrix if str(r.get('doi')).lower()==x['doi'].lower()),None)
    if existing: existing['current_refresh_followup']=row
    else: matrix.append(row)
extra=read('traceability/Additional_Prior_Coverage_Clarifications.json')['IKegwu_2026']
matrix.append({'study_id':'IKEGWU_2026','study':extra['title'],'doi':extra['doi'],'year':2026,'domain':'Transferable IoMT/network security','access_and_read_scope':extra['read_scope'],'novelty_assessment':extra['relevance'],'limitations':extra['limits'],'evidence_origin':'INHERITED_FOCUSED_PRIMARY_HTML_AUDIT','verified_source_url':extra['primary_html'],'evidence_files':[extra['previous_local_review'],extra['previous_machine_receipt']],'global_equivalence_determined':False})
matrix.append({'study_id':'NEURALFORTRESS_XFL_2026','study':'NeuralFortress-XFL','doi':'10.3390/electronics15143124','year':2026,'domain':'Transferable network cyber-threat intelligence','access_and_read_scope':'Inherited original indexed publisher methods/results/table excerpts; complete publisher HTML not read','novelty_assessment':'Prior secure-aggregation removal and cost tables limit any broad assertion that such ablations are absent. Distinct task/mechanism.','limitations':'Published cost endpoints and communication reduction values differ across sections; no reproduction.','evidence_origin':'INHERITED_PRIMARY_INDEXED_EXCERPTS','verified_source_url':'https://www.mdpi.com/2079-9292/15/14/3124','evidence_files':['C:/Users/RNO/Desktop/Coureses/P1/ars_gap_audit_v1_5_2026_10_09/recent_counterevidence_AR.md'],'global_equivalence_determined':False})
transfer=read('public_api/Source_257_258_Assessment.json')['sources']
for x in transfer:
    matrix.append({'study_id':'API_'+str(x['screening_index']),'study':x['title'],'doi':x['doi'],'year':2026,'domain':x['study_type_and_scope']['finding'],'access_and_read_scope':x['scientific_read_scope']+'; exact read/unread sections preserved in public_api/Source_257_258_Assessment.json','novelty_assessment':x['bounded_novelty_implication']['inference'],'limitations':x['results_interpretation_limits'],'evidence_origin':'NEW_PRIMARY_JATS_SECTION_AND_TABLE_TEXT_READING; NOT_COMPLETE_SOURCE_AUDIT','verified_source_url':x['publisher_url'],'evidence_files':['public_api/Source_257_258_Assessment.json',x['raw_response_evidence']['raw_file']],'global_equivalence_determined':False})
save('Literature_Novelty_Evidence_Matrix.json',matrix); csvout('Literature_Novelty_Evidence_Matrix.csv',matrix)

patches=[
 {'id':'ME04-P1','location':'§2.7 after original B0281','action':'INSERT','text':"Maghrabi et al. (2026) describe a federated anomaly-detection system for health information systems using FedAvg and TLS. Their security description places SMPC in both the current design and future work, while the inspected text does not identify a named experimental dataset, sample size or matched plain-versus-secure aggregation arms. The study is therefore relevant prior federated healthcare-security work, but its reported results do not establish an equivalent controlled comparison on staff-access sessions. Capparelli et al. (2026) further show the importance of contextual access governance; their proposed integration and referenced validation do not provide a new FedAvg–SecAgg+ experiment.", 'evidence':['CH-C01: pp.262–267 §§III–VII, TableI','CH-C02: §§2.1–2.4,§3']},
 {'id':'ME04-P2','location':'§2.7 after ME04-P1','action':'INSERT','text':"Transferable studies also constrain the novelty claim. Munusamy and Jothi (2026) combine blockchain, federated learning and secure third-party computation in an EHR-security preprint. Kamatchi and Uma (2025) evaluate an IoT insider-detection design with grouped component ablations, and Abbasi et al. (2025) evaluate FedAvg on CERT user profiles using simulated privacy mechanisms. Tanvir et al. (2026) and Javed et al. (2025) address broader healthcare privacy, security and efficiency. These studies require comparison by the unit of detection, the implemented protection mechanism, the controlled experimental factors and the definition of system cost. Their reported accuracies are not directly comparable across these different tasks and datasets.", 'evidence':['Inherited BFL_STPC/KAMATCHI/ABBASI/TANVIR audits','Root Javed primary methods excerpt; results fulltext unavailable']},
 {'id':'ME04-P3','location':'§2.8 original B0288–B0290','action':'REPLACE_THREE_PARAGRAPHS','text':"Federated EHR access-anomaly detection is already represented by Martínez Llamas et al. (2025). Their Flower/FedAvg LSTM-autoencoder experiment uses real hospital access records but lacks anomaly ground truth and a matched SecAgg+ evaluation. Labelled synthetic EHR detection is also represented by Senturk et al. (2025) and Iqbal et al. (2026), while Sutradhar et al. (2026) places federated learning in future work. Consequently, neither federated detection nor the use of synthetic anomaly labels alone constitutes the contribution of this study.\n\nThe empirical question is how protecting client updates changes detection outputs and recorded workflow cost when the detector, initial states, sampling schedules and evaluation procedures are held constant. The present study compares standard Flower FedAvg with a pooled centralised reference, then compares FedAvg with the implemented SecAgg+ workflow on the same fixed synthetic benchmark. Source-labelled routine and unusual legitimate sessions permit false alerts to be counted under the benchmark's label assumptions. Recorded fit-workflow time and application-message content measure specific operational effects; they do not establish end-to-end network overhead or a formal privacy guarantee.\n\nThe contribution is bounded empirical evidence from this controlled comparison, rather than a new federated-learning algorithm. The targeted literature refresh of 11 October 2026 identified direct and transferable prior work, including additional healthcare-security designs and unresolved full-article candidates. FeadSeq and the regular-versus-secure network-monitoring study remain qualified comparators because their complete articles were not available for examination in this refresh. The search register distinguishes complete public-API retrieval for the executed queries from top-result web discovery. These findings support the stated empirical positioning but do not certify exhaustive coverage, global priority or generalisation beyond the evaluated synthetic benchmark.", 'evidence':['LLAMAS original §§III–VII/TableI','SENTURK/SUTRADHAR inherited fulltexts','IQBAL original JATS Limitations and future work','CH-C03/CH-C04 access limits','Search protocol/register/current study objectives']},
 {'id':'ME05-P1','location':'Appendix A new subsection after B0643','action':'INSERT','text':"Literature refresh of 11 October 2026. A documented targeted narrative update used four query families separately in PubMed E-utilities and Europe PMC, supplemented by web-index discovery and source chaining. Refresh identifiers are distinct from the historical August S1–S4 identifiers. All returned public-API identifiers and bibliographic records were preserved for the exact executed queries, together with request URLs, query translations, warnings, timestamps and raw-response hashes. The query-hit sum was 498; after within-database merging there were 488 database records, corresponding to 281 stable source identifiers before final DOI/title reconciliation. Web responses preserve returned top results and batch provenance; search-engine total hits were not supplied. Eligibility decisions, duplicates, full-text access levels and the closest-study comparison are retained in the 11 October refresh package. This is a narrative update and does not retrospectively authenticate or replace the historical August searches.", 'evidence':['public_api/Search_Result_Manifest.json','public_api/HTTP_Request_Receipts.json','Unified_Search_Register.json']}
]
historical=read('traceability/Proposed_English_Substitutions_NOT_APPLIED.json')['proposals']
for x in historical:
    if x['id'] in ['TR02','TR03','TR07']:
        patches.append({'id':'ME05-'+x['id'],'location':x['location'],'action':x['kind'],'text':x['proposed'],'application_condition':x['condition']})
for platform,items in [('Scopus',[('B0647','S1',64),('B0649','S2',4),('B0651','S3',30),('B0653','S4',117)]),('Web of Science',[('B0656','S1',28),('B0658','S2',1),('B0660','S3',2)]),('IEEE Xplore',[('B0670','S1',17),('B0672','S2',5),('B0674','S3',9)])]:
    for block,family,count in items:
        txt=f'The supplied {platform} {family} export was inspected on 11 October 2026 and contains {count} records, matching the historical entry. This verifies the received file contents, rather than independently authenticating every original query setting, total-hit count or complete database retrieval.'
        if platform=='Scopus' and family=='S2': txt+=' The four-record file is scopus_export_Aug 11-2026_S2.ris. The file named 2026-08-11_scopus_S2.ris.ris is byte-identical to the 117-record S4 export and must not be treated as S2.'
        if platform=='Scopus' and family=='S4': txt+=' Two records share DOI10.1201/9781003393580-102 but have different Scopus identifiers;117 is a raw-record count, not a verified unique-study count.'
        patches.append({'id':'ME05-'+block,'location':'Appendix B '+platform+' '+family+' '+block+' integrity-note cell','action':'REPLACE_INTEGRITY_NOTE_ONLY; PRESERVE_HISTORICAL_QUERY_AND_COUNT','text':txt})
for block,txt in [('B0663','The received PubMed S1 CSV was inspected on 11 October 2026 and contains10 records. The historical15-hit total remains unverified and five records remain unreconciled. They are not screened exclusions, and no missing historical records were reconstructed.'),('B0665','The historical PubMed S2 zero-result entry lacks a contemporaneous preserved response establishing the original query and settings. No export is expected for a genuine zero-result search; a later search cannot independently authenticate this historical zero.'),('B0667','The historical PubMed S3 count of12 results still lacks its retained native export. This evidence gap is not resolved by the11 October2026 refresh.')]:
    patches.append({'id':'ME05-'+block,'location':'Appendix B PubMed '+block+' integrity-note cell','action':'REPLACE_INTEGRITY_NOTE_ONLY','text':txt})
for block,family in [('B0677','S1'),('B0679','S2'),('B0681','S4')]:
    patches.append({'id':'ME05-'+block,'location':'Appendix B ACM '+family+' '+block+' integrity-note cell','action':'REPLACE_INTEGRITY_NOTE_ONLY','text':'The supplied BibTeX export was inspected on11 October2026 and contains20 records. The database total-hit count, export range and complete all-results coverage remain unverified. Proceedings-volume records are not equivalent to individual research papers.'})
for p in patches:
    if p['id']=='ME04-P2':
        p['text']+=' Shamim et al. (2026) compare two encrypted SDN intrusion-detection implementations under matched detector and cryptographic-parameter settings, while Qazi et al. (2026) report private federated ERP anomaly detection with component ablations and utility/cost evaluation. These are substantive transferable precedents. Their different tasks and interventions require qualification: the former changes the cryptographic stack, and the latter\'s headline communication reduction compares different round budgets; Table20 does not isolate secure aggregation alone.'
        p['evidence']+=['Shamim §6.2.5/Table7 and §7.5','Qazi Tables7,15,19,20 and XML Sec33']
    if p['id']=='ME05-TR03':
        p['text']=p['text'].replace('in the current search register','in the current source-evidence matrix and candidate access records')
    for old,new in {'contains10':'contains 10','historical15':'historical 15','recorded12':'recorded 12','with15':'with 15','contains20':'contains 20','of12':'of 12','on11':'on 11','October2026':'October 2026','the11':'the 11','Octob er':'October','Scopus identifiers;117':'Scopus identifiers; 117','DOI10.':'DOI 10.'}.items():
        p['text']=p['text'].replace(old,new)
reference_metadata=read('reference_metadata/Metadata_Verification.json')
save('Exact_Manuscript_Corrections.json',{'status':'CONCRETE_REPLACEMENT_TEXT; NOT_APPLIED_TO_WORD_IN_THIS_SEARCH_TASK','source_docx_sha256':read('traceability/Current_Thesis_Logic_and_Search_Blocks.json')['source_sha256'],'patches':patches,'reference_metadata_file':'reference_metadata/Metadata_Verification.json','reference_metadata_scope':'Ten DOI identities and bibliographic fields verified, not claim support or complete scientific source coverage. Maghrabi online dates conflict across publisher/Crossref; preserve issue year2026. Capparelli dates differ across publisher/Crossref; volume/pages unavailable. Kamatchi online2024 and issue2025 are distinct. BFL-STPC preprint name parsing in Crossref is irregular; original cover controls author rendering.'})
english=['# Exact manuscript corrections for ME-04 and ME-05','', 'These replacement paragraphs are prepared from the dated11 October2026 search. They have not been applied to the Word manuscript. Bnnnn locators identify original direct body blocks in word/document.xml, not page numbers. Historical counts remain historical.','']
for p in patches:
    english += ['## '+p['id']+' '+p['location'],'', '**Action:** '+p['action'],'',p['text'],'']
english += ['## Verified reference metadata','', 'DOI metadata were checked separately from scientific content. Use the exact author and title fields in reference_metadata/Metadata_Verification.json; unavailable fields must not be invented. All ten DOI requests succeeded. Dates and author-format exceptions are listed in Exact_Manuscript_Corrections.json.','']
for r in reference_metadata:
    names='; '.join((a.get('given','')+' '+a.get('family','')).strip() for a in r.get('author',[]))
    english += ['- '+names+'. '+(' / '.join(r.get('title') or []))+'. DOI: https://doi.org/'+r['doi']]
english += ['', 'Two further original-source identities and reading scopes were checked in the retrieved publisher-supplied JATS; these are recorded in public_api/Source_257_258_Assessment.json, separately from the ten Crossref metadata requests.','']
for r in transfer:
    english += ['- '+'; '.join(r['authors'])+'. (2026). '+r['title']+'. https://doi.org/'+r['doi']]
(BASE/'Exact_Manuscript_Corrections_EN.md').write_text('\n'.join(english),encoding='utf-8')

assert len(register)==51,(len(register),'expected8API+43web queries')
assert len({r['refresh_query_id'] for r in register})==len(register)
print(json.dumps({'queries':len(register),'evidence_matrix_entries':len(matrix),'concrete_correction_entries':len(patches),'manuscript_modified':False},ensure_ascii=False))
