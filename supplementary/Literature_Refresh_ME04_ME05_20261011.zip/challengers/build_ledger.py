import csv, hashlib, json, re
from pathlib import Path

root = Path(__file__).resolve().parent
rows, queries, files = [], [], []
for p in sorted((root / 'raw').glob('CH[0-9][0-9].json')):
    d = json.loads(p.read_text(encoding='utf-8-sig'))
    files.append({'path':str(p), 'sha256':hashlib.sha256(p.read_bytes()).hexdigest(), 'search_id':d['search_id']})
    qs = d['tool_input'].get('search_query', [])
    for i, q in enumerate(qs, 1):
        queries.append({'tool_call_id':d['search_id'], 'query_index_in_call':i, 'timestamp_utc':d['timestamp_utc'], 'exact_query':q['q'], 'total_hits':None, 'count_semantics':'top results; total unavailable'})
    raw = d['raw_response']
    for match in re.finditer(r'^([^\n]*) \((https?://[^\n]+)\)\n[^\n]*?\ue202cite\ue202[^\n]*?([a-zA-Z0-9]+search\d+)', raw, re.M):
        title, url, ref = match.groups()
        rows.append({'tool_call_id':d['search_id'], 'web_reference':ref, 'title_as_returned':title, 'url_as_returned':url, 'query_attribution':'tool-call batch only', 'exact_batch_queries':json.dumps(qs, ensure_ascii=False), 'timestamp_utc':d['timestamp_utc']})

# The web citation delimiter can differ. Capture the documented marker exactly as returned.
if not rows:
    for p in sorted((root / 'raw').glob('CH[0-9][0-9].json')):
        d = json.loads(p.read_text(encoding='utf-8-sig'))
        raw = d['raw_response']
        for match in re.finditer(r'^([^\n]*) \((https?://[^\n]+)\)\n[^\n]*?(turn\d+search\d+)', raw, re.M):
            title, url, ref = match.groups()
            rows.append({'tool_call_id':d['search_id'], 'web_reference':ref, 'title_as_returned':title, 'url_as_returned':url, 'query_attribution':'tool-call batch only', 'exact_batch_queries':json.dumps(d['tool_input'].get('search_query', []), ensure_ascii=False), 'timestamp_utc':d['timestamp_utc']})

with (root / 'Returned_Search_Records.csv').open('w', encoding='utf-8-sig', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=['tool_call_id','web_reference','title_as_returned','url_as_returned','query_attribution','exact_batch_queries','timestamp_utc'])
    writer.writeheader(); writer.writerows(rows)

selected = json.loads((root / 'Normalized_Candidates.json').read_text(encoding='utf-8-sig'))
summary = {'raw_tool_calls':len(files), 'exact_web_search_queries':len(queries), 'returned_search_record_occurrences':len(rows), 'unique_returned_urls':len({r['url_as_returned'] for r in rows}), 'selected_normalized_candidate_count':len(selected['candidates']), 'engine_total_hits':None, 'denominator_warning':'Returned occurrences include irrelevant hits and duplicate versions; selected normalized candidate list is a separate, explicitly chosen subset. All returned hits remain preserved; this is not a PRISMA systematic review denominator.', 'queries':queries, 'raw_files':files}
(root / 'Search_Ledger.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k not in ('queries','raw_files')}, ensure_ascii=False, indent=2))
