# فحص جميع نتائج بحث الويب المعادة

فُحصت جميع 202 مرات ظهور للنتائج (86 من بحث المهمة الرئيسية و116 من بحث الأدبيات المنافسة)، وتمثل 182 رابطًا بعد إزالة تكرار الروابط بحذر. عدد الروابط ليس عدد الدراسات المستقلة؛ قد يظهر المصدر نفسه لدى الناشر وPubMed وResearchGate.

أُبقيت جميع النصوص المعادة ومدخلات الاستعلامات والوقت والدفعة والمعرف الخام، بما فيها دفعة CH09 التي لم تُعد نتائج بحث. استُبعدت مقاطع فتح المصادر فقط من عداد نتائج البحث. الأعداد خاصة بالنتائج التي أعادتها الأداة، وليست إجمالي نتائج محرك البحث. لا يمكن توزيع نتيجة دفعة متعددة الاستعلامات على كل استعلام.

## قرارات الفرز

| القرار | مرات الظهور | الروابط الفريدة |
|---|---:|---:|
| RETAIN_DIRECT | 13 | 8 |
| RETAIN_TRANSFERABLE | 59 | 48 |
| BACKGROUND | 49 | 47 |
| EXCLUDE | 60 | 58 |
| UNCERTAIN | 21 | 21 |

القرار مستند إلى قراءة العنوان والمقتطف المعاد لكل رابط، وليس تحققًا من النص الكامل. أُبقيت النتائج غير المحسومة UNCERTAIN ظاهرة، ولم تُعامل بوصفها مستبعدة أو مفحوصة بالكامل. تُراجع الأدلة الأصلية في ملفات تقييم المصادر المنفصلة.

## الأعداد حسب الدفعة

| الدفعة | النتائج المعادة |
|---|---:|
| WEB-001-003 | 18 |
| WEB-004-006 | 18 |
| WEB-007 | 16 |
| WEB-008-010 | 17 |
| WEB-011-013 | 17 |
| CH01 | 17 |
| CH02 | 18 |
| CH05 | 18 |
| CH06 | 14 |
| CH08 | 6 |
| CH09 | 0 |
| CH10 | 15 |
| CH12 | 16 |
| CH14 | 12 |

## الروابط غير المحسومة

| معرف المرشح | العنوان | السبب |
|---|---|---|
| UWEB-009 | Volume 11, Issue 5, May – 2026 | Generic journal-volume PDF header and agent-layer excerpt; paper title, empirical target and contribution cannot be identified reliably from the returned text. |
| UWEB-014 | Received 19 June 2024, accepted 17 August 2024, date of publication 26 August 2024, date of current version 1 October 2024. | Institutional PDF is returned under publication-date header rather than paper title; snippet concerns longitudinal health-data exchange, so exact task remains unresolved. |
| UWEB-015 | Computer Fraud and Security | PDF returned under journal name alone; excerpt proposes secure FL and audit logs without identifiable target, experiment or component isolation. |
| UWEB-016 | Asian Journal of Convergence in Technology | Generic journal heading and reference-heavy snippet; identity and whether any relevant original evaluation exists cannot be determined. |
| UWEB-026 | © March 2026/ IJIRT / Volume 12 Issue 10 / ISSN: 2349-6002 | Generic PDF publication header; snippet discusses ABHA identity and blockchain governance, but paper identity and actual target cannot be resolved. |
| UWEB-030 | DOCTOR OF PHILOSOPHY (PHD) | Repository PhD PDF returned with generic title; privacy/attack material may be background, but title, original contribution and experiments are unresolved. |
| UWEB-043 | biomedicines | PDF titled only biomedicines with encrypted updates and blockchain model auditability; exact article identity, task and intervention require original-source retrieval. |
| UWEB-046 | MediConnect IEEE Paper Final / PDF | Scribd-hosted manuscript with placeholder IEEE ISBN and claimed architecture; publication identity and original experiment unverified, so not accepted as peer-reviewed evidence. |
| UWEB-055 | ech T Press Science Published Online: 30 April 202 | TechScience PDF header truncated, actual paper title unavailable; snippet mentions FedAvg/SecAgg and defenses but target and experiments remain unresolved. |
| UWEB-063 | Journal of Information Systems Engineering and Management | Generic journal-title PDF offers only FedAvg/SecAgg and anomaly terms; insufficient title/snippet evidence to determine original task or relevance. |
| UWEB-064 | Differential Privacy in Secure Federated Averaging Algorithm Thesis | Third-party copy of a DP/SecAgg Flower thesis; implementation might be transferable, but original institutional source, experiment and relation to anomaly detection remain unverified. |
| UWEB-088 | ARTICLE IN PRESS | Result is labelled ARTICLE IN PRESS and discusses Health-FedNet audit/compliance. Exact paper identity, task and implemented evaluation cannot be resolved reliably from this discovery excerpt. |
| UWEB-095 | Page 1 of 13 | Generic Page 1 of 13 PDF header and secure-aggregation/DP excerpt do not identify the paper or show whether EHR access detection or update anomaly monitoring was experimentally evaluated. |
| UWEB-096 | ISSN 2319-5991 www.ijerst.com | Journal ISSN header and encrypted-update/edge excerpt leave title, target data and original experimental contribution unresolved; preserve for follow-up rather than infer relevance. |
| UWEB-117 | MedFed-Secure: A privacy-enhanced and trust-aware federated learning framework for connected healthcare - ScienceDirect | MedFed-Secure is a potentially relevant healthcare privacy/trust FL candidate, but the returned date indicates a November 2026 issue beyond the cutoff. Earlier online version/date and actual target must be verified before eligibility is decided. |
| UWEB-122 | https://doi.org/10.31449/inf.v49i35.11175 | Returned Informatica header is a DOI and related-work table; exact own study, target data and experiments cannot be distinguished reliably from cited methods in the excerpt. |
| UWEB-123 | JETIR Research Journal | JETIR generic journal heading and pipeline references do not reliably identify the original paper, target task or whether secure aggregation/anomaly components were evaluated. |
| UWEB-125 | International Journal of Research and Applied Innovations (IJRAI) | Generic IJRAI PDF heading and architectural privacy/aggregation material leave the paper identity and original experiment unresolved. |
| UWEB-126 | Journal of Information Systems Engineering and Management | Generic JISEM PDF heading claims privacy/anomaly components but does not establish an identifiable task, sample, dataset or isolated intervention in the returned text. |
| UWEB-127 | Tuijin Jishu/Journal of Propulsion Technology | Propulsion Technology excerpt largely describes cited studies, including secure aggregation and edge IDS. The main paper identity and its own experimental contribution are unresolved; cited findings are not attributed to it. |
| UWEB-181 | Cloud assisted blockchain-enabled split federated learning framework for security and privacy-preserving of IoMT in healthcare 5.0 / Scientific Reports | Cloud-assisted blockchain/split-FL IoMT privacy paper may be a transferable security architecture. Returned excerpt mixes recommended model-misconduct content, so its own target/experiment and anomaly intervention remain unresolved. |

أُنجزت مراجعة جميع النتائج المعادة ضمن هذا النطاق وسُجل سبب لكل قرار. لا يثبت هذا اكتمال النصوص الأصلية لجميع المرشحين، ولا يعيد مصادقة الأعداد التاريخية، ولا يثبت أسبقية عالمية. لا تزال حالات عدم الحسم بحاجة إلى تحديد المصدر/تاريخ الإتاحة أو قراءة الأصل وفق أهميتها للادعاء البحثي.

الملفات الأساسية: Unified_Web_Returned_Records.json/.csv (كل مرات الظهور)، Unified_Web_Screened_Union.json (الروابط المرشحة)، Unified_Web_Screening_QA.json (المصالحة والحدود).
