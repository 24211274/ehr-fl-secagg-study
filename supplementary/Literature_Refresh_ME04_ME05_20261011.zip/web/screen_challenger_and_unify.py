from pathlib import Path
import csv, hashlib, json, collections, re
from urllib.parse import urlsplit, unquote

BASE=Path(r'C:/Users/RNO/Desktop/Coureses/P1/ars_literature_refresh_2026_10_11')
OUT=BASE/'web'

def identifiers_from_url(url):
    # Inspect URL structure only, never prose/snippet/reference lists.
    p=urlsplit(url);host=p.netloc.lower().removeprefix('www.')
    path=unquote(unquote(p.path))
    doi=None
    explicit=re.search(r'(10\.\d{4,9}/[^?#\s]+)',path,re.I)
    primary_hosts={'doi.org','dx.doi.org','link.springer.com','onlinelibrary.wiley.com','journals.sagepub.com','spj.science.org','dl.acm.org','ieeexplore.ieee.org'}
    if explicit and host in primary_hosts:
        doi=explicit.group(1).rstrip('/').lower()
        if host in {'doi.org','dx.doi.org'}:doi=path.lstrip('/').rstrip('/').lower()
    public={}
    if host in {'pmc.ncbi.nlm.nih.gov','ncbi.nlm.nih.gov'}:
        m=re.search(r'\b(PMC\d+)\b',path,re.I)
        if m:public['PMCID']=m.group(1).upper()
    if host=='pubmed.ncbi.nlm.nih.gov':
        m=re.fullmatch(r'/(\d+)/?',path)
        if m:public['PMID']=m.group(1)
    if host=='ieeexplore.ieee.org':
        m=re.search(r'/(?:document|abstract/document)/(\d+)',path)
        if m:public['IEEE_DOCUMENT_ID']=m.group(1)
    if host=='openalex.org':
        m=re.fullmatch(r'/(W\d+)/?',path,re.I)
        if m:public['OPENALEX_WORK_ID']=m.group(1).upper()
    return {'verifiedDOI_fromURL':doi,'DOI_verification_scope':'Literal identifier in DOI resolver or primary-publisher URL only; not DOI registration/full-text verification' if doi else 'No literal DOI in an accepted resolver/publisher URL',
            'public_identifiers_fromURL':public}
root=json.loads((OUT/'Web_Returned_Records.json').read_text(encoding='utf-8'))
challenger=json.loads((OUT/'Challenger_Web_Returned_Records.json').read_text(encoding='utf-8'))
groups={}
for r in challenger['records']:
    groups.setdefault(r['canonical_url'], []).append(r)
assert len(groups)==108
# Manual semantic title/snippet screening, indexed by first unique URL appearance.
# These decisions never assert full-text access or infer a paper's own results from cited papers.
D='RETAIN_DIRECT'; T='RETAIN_TRANSFERABLE'; B='BACKGROUND'; X='EXCLUDE'; U='UNCERTAIN'
M={
1:(T,'EnDuSecFed describes healthcare FL with encrypted updates and an anomaly/dual-security component; retain a transferable security comparison. Update-anomaly monitoring is distinct from staff EHR access-session detection.'),
2:(T,'FedShield-IoMT describes collaborative threat learning and network intrusion detection in healthcare IoT. Original conference candidate, transferable task; the discovery excerpt alone does not verify secure-aggregation isolation or EHR staff-access labels.'),
3:(B,'Systematic review of poisoning resilience in IoMT FL, useful for threat models and citation chaining; not an original controlled detector/aggregation experiment.'),
4:(B,'Review of healthcare FL, blockchain and XAI; background/chaining evidence rather than an independent matched secure-aggregation experiment.'),
5:(T,'HEAL-AI excerpt connects hierarchical healthcare learning, encryption/aggregation and anomaly signals such as access frequency/duration/type. Retain a potential transferable challenge; actual access-label evaluation and intervention isolation require the source.'),
6:(B,'Infrastructure paper concerns privacy/security requirements for multicentre healthcare research and governance. No direct staff-access anomaly experiment or matched aggregation comparison is established in the returned excerpt.'),
7:(U,'Result is labelled ARTICLE IN PRESS and discusses Health-FedNet audit/compliance. Exact paper identity, task and implemented evaluation cannot be resolved reliably from this discovery excerpt.'),
8:(B,'Healthcare-security article synthesizes prior literature and proposes integrated FL/privacy architecture. Useful motivation, but the snippet does not establish an original matched access-anomaly experiment.'),
9:(X,'HeartGuard-AI is a demonstration heart-disease prediction repository, outside the empirical security/anomaly comparison task and not an original scholarly study identified here.'),
10:(B,'Microservices/blockchain healthcare analytics architecture targets scalable patient analytics; no staff-access-session detector is established by this returned text.'),
11:(T,'Institutional thesis specifically studies federated log-based anomaly detection. Retain as related grey literature; secure-aggregation intervention, dataset and costs are not verified by the search return.'),
12:(T,'FedSecure-Chain addresses verifiable e-health FL and poisoned model updates. Retain a transferable security/aggregation challenge; its anomaly target is model integrity rather than staff EHR access.'),
13:(B,'Adaptive Access Governance is directly relevant to EHR authorization and monitoring background. Returned text does not establish an independently evaluated federated-learning detector or matched secure-aggregation comparison.'),
14:(T,'Adversarial-resilient IoMT intrusion detection with digital twins and federated ensembles is an original healthcare-network security comparator. Network/device threats differ from staff access-session misuse.'),
15:(U,'Generic Page 1 of 13 PDF header and secure-aggregation/DP excerpt do not identify the paper or show whether EHR access detection or update anomaly monitoring was experimentally evaluated.'),
16:(U,'Journal ISSN header and encrypted-update/edge excerpt leave title, target data and original experimental contribution unresolved; preserve for follow-up rather than infer relevance.'),
17:(B,'Business/economics journal excerpt gives privacy technology governance and deployment recommendations. No original controlled EHR access-detection or aggregation experiment is established.'),
18:(D,'Llamas EHR access-control anomaly-detection paper is a direct candidate already present in the thesis. ResearchGate bibliographic return is discovery evidence, not independent replication or full-text verification.'),
19:(D,'J-GLOBAL index identifies the already-known Llamas EHR access-control anomaly-detection paper. Retain a direct bibliographic lead; the index is not a separate study or a full-source audit.'),
20:(B,'AHIMA cloud/EHR access paper concerns federated identity/authentication. Federation here does not establish federated machine learning or staff-access anomaly evaluation.'),
21:(X,'KU Leuven author profile/publication list is a citation-chaining aid, not a separate original study or a paper-specific full-text source.'),
22:(T,'Kudos individual bibliographic record identifies FeadSeq, a personalized federated discrete-event anomaly framework. Retain transferable method lead; this metadata/reader page does not establish original-source coverage.'),
23:(B,'Health information exchange architecture addresses identity, interoperability and governance rather than federated model training for access-anomaly detection.'),
24:(B,'JMIR PDF concerns real-world federated identity for patient EHR access. Patient single sign-on/authentication is a different meaning of federation from FedAvg or an ML anomaly detector.'),
25:(B,'Pilot evaluates patient portal access using social credentials. Relevant access-governance background, not staff misuse detection or a federated-learning experiment.'),
26:(B,'Institutional EHR connectivity strategy is policy/identity architecture background, not original empirical evidence for an ML detector or an isolated secure-aggregation intervention.'),
27:(B,'University thesis excerpt concerns cryptographic authentication/access control and federated identity. No federated machine-learning access-anomaly experiment is established by the returned text.'),
28:(B,'AHRQ privacy/security solutions describe interoperable health-information exchange and audit/authentication controls, useful governance background but not an ML experiment.'),
29:(T,'Edelson paper studies false-positive tolerant mitigation of FL model misconduct across institutions on EHR data. Retain transferable model-integrity evidence; model tampering is distinct from staff access-session misuse.'),
30:(T,'EPP-BCFL is a healthcare blockchain/edge FL security and efficiency candidate. Retain for broad privacy/cost comparison; direct staff access-anomaly evaluation is not established by discovery text.'),
31:(D,'IJISS paper explicitly claims FL anomaly detection for health-information systems and unauthorized EHR access. Direct candidate; original methods/data and the claimed privacy intervention need separate source assessment.'),
32:(B,'Distributed EHR threat-detection article excerpt presents a thematic synthesis/architecture discussion. It does not establish an original matched detector/secure-aggregation experiment.'),
33:(B,'Multi-hospital FL with blockchain audit trails primarily targets disease prediction. Anomaly detection appears as future work; it cannot be counted as implemented staff-access detection.'),
34:(B,'QUT repository excerpt concerns patient authentication and federated identities, not federated machine-learning access-anomaly detection.'),
35:(T,'FSSL-TCN-Per is a semi-supervised personalized healthcare anomaly-learning candidate with privacy components. Retain transferable wearable/patient anomaly evidence; direct EHR staff access and isolated aggregation costs remain unverified.'),
36:(T,'Conference candidate proposes personalized privacy-preserving IoT healthcare learning with secure aggregation and anomaly adaptation. Transferable comparator; the excerpt does not verify the EHR staff-access task.'),
37:(T,'Adaptive resource-aware federated edge IoMT framework connects anomaly/privacy and resource constraints. Retain broad security/efficiency comparison pending original dataset, intervention and cost verification.'),
38:(T,'Original-publisher EnDuSecFed page describes healthcare FL dual security and anomalous updates. Same study may have a PMC copy, but this URL remains a separate discovery record; task differs from staff access-session detection.'),
39:(T,'LMSA is a lightweight multi-key secure-aggregation protocol for healthcare AIoT, directly relevant to privacy/cost foundations. Anomaly detection is prospective, so no current staff-access detector is inferred.'),
40:(B,'MedShieldFL excerpt evaluates clinical image/patient prediction and mentions anomaly detection as future work. Privacy architecture background, not implemented access-misuse detection.'),
41:(T,'PubMed identifies the already-audited Tanvir multimodal healthcare FL pipeline. Retain transferable cyber/privacy comparison; this indexing record is not a new study or a fresh full-text audit.'),
42:(U,'MedFed-Secure is a potentially relevant healthcare privacy/trust FL candidate, but the returned date indicates a November 2026 issue beyond the cutoff. Earlier online version/date and actual target must be verified before eligibility is decided.'),
43:(B,'Mamba-fusion targets privacy-preserving disease prediction. Relevant clinical FL architecture/cost context, but no staff-access anomaly target is established.'),
44:(T,'Original cross-tier wireless body-area-network anomaly detection addresses healthcare transmission security. Retain transferable network-threat evidence; staff EHR access and secure-aggregation intervention are not verified here.'),
45:(T,'Risk-aware remote-patient-monitoring FL compares privacy/security conditions including anomaly and aggregation components. Retain broad utility/cost challenge; bundled changes and patient-monitoring task limit causal or direct EHR-access comparison.'),
46:(T,'Trustfed proposes robust privacy-preserving federated AI across industrial IoT, healthcare and finance. Retain transferable security/aggregation comparison; exact task and matched intervention require source verification.'),
47:(U,'Returned Informatica header is a DOI and related-work table; exact own study, target data and experiments cannot be distinguished reliably from cited methods in the excerpt.'),
48:(U,'JETIR generic journal heading and pipeline references do not reliably identify the original paper, target task or whether secure aggregation/anomaly components were evaluated.'),
49:(X,'Author CV/publication list is not an individual original paper or verified implementation; exclude from the empirical-study set while preserving the returned record.'),
50:(U,'Generic IJRAI PDF heading and architectural privacy/aggregation material leave the paper identity and original experiment unresolved.'),
51:(U,'Generic JISEM PDF heading claims privacy/anomaly components but does not establish an identifiable task, sample, dataset or isolated intervention in the returned text.'),
52:(U,'Propulsion Technology excerpt largely describes cited studies, including secure aggregation and edge IDS. The main paper identity and its own experimental contribution are unresolved; cited findings are not attributed to it.'),
53:(X,'GitHub topic listing contains many repositories including FeadSeq. It is not a paper-specific original source or verified implementation and cannot count as a separate study.'),
54:(T,'ResearchGate individual FeadSeq bibliographic record is a transferable personalized event-sequence anomaly lead. Original full text is not made verified by this search return.'),
55:(X,'Library author search results are a multi-record catalogue listing, not a separate original study or paper-specific original text.'),
56:(X,'Library author search results list FeadSeq among other works. Exclude the catalogue listing as a study, retaining its discovery provenance.'),
57:(T,'Precise Anomaly Recognition in resource-restricted WSN is a transferable FL security/anomaly study. FeadSeq appears in references, which does not make this record original FeadSeq evidence.'),
58:(X,'Author catalogue search results are an index, not a separate original study or source-level verification of FeadSeq.'),
59:(X,'DBLP Shiyou Qian author bibliography is a chaining/index page, not an individual original experimental source.'),
60:(X,'DBLP alternate author bibliography URL is an index rather than an independent paper. Retain URL provenance without treating the listing as experimental evidence.'),
61:(X,'Baidu scholar author profile combines many works and is not an individual original empirical source.'),
62:(X,'DBLP Wei Guan author bibliography is a publication index, not a separate original study or a full-source audit.'),
63:(T,'Individual bibliographic lead for personalized federated PCA with manifold optimization in IoT anomaly detection. Transferable method; original full text, experiments and secure-aggregation relevance remain unverified.'),
64:(X,'Complete TKDD bibliography contains many papers and DOIs. It is a bibliographic compilation, not a single original experiment; no first DOI is used for identification.'),
65:(X,'University-hosted complete TKDD bibliography is a multi-paper index, not an independent original research study or FeadSeq full text.'),
66:(T,'Wiley abstract URL identifies the same WSN anomaly-recognition candidate as the returned PDF URL. Retain transferable lead; the two URL records do not establish two independent studies.'),
67:(B,'Adaptive model pruning at the edge addresses general personalized FL/resource efficiency. FeadSeq appears in related/recommended content, so its claims cannot be assigned to the main pruning article.'),
68:(B,'Business-process event-log denoising autoencoder paper is anomaly-method background. FeadSeq appears as related content, not this paper’s own original result or identifier.'),
69:(B,'Self-attention business-process anomaly detection provides method background; FeadSeq/other FL text is related content and cannot be attributed to the main article.'),
70:(T,'DOAJ individual record identifies Secure Federated Learning for Multi-Party Network Monitoring. Retain important transferable FedAvg/SMPC network-security comparison; index return is distinct from source verification.'),
71:(X,'DBLP Giang Nguyen author bibliography lists multiple papers/DOIs, not an individual original study. Do not identify a candidate using the first DOI in its snippet.'),
72:(T,'ResearchGate individual page for Secure Federated Learning for Multi-Party Network Monitoring is a transferable aggregation/security comparator. This discovery occurrence does not independently establish full-text coverage.'),
73:(X,'IDSA research-group website is a publication/group listing rather than an individual original study or a paper-specific source audit.'),
74:(T,'Institutional thesis summary describes regular versus SMPC federated network-monitoring experiments. Retain related grey literature; it may report the same authors’ study rather than an independent replication.'),
75:(T,'Individual institutional library record identifies Secure Federated Learning for Multi-Party Network Monitoring. Retain a transferable bibliographic lead, not an independent experiment or original full-text verification.'),
76:(B,'Main article studies membership-inference attacks in FL. The network-monitoring study appears in citing/related content; useful privacy-attack background, not that study’s original results.'),
77:(X,'Institutional library multi-record search results are a catalogue listing, not a separate original empirical study or full-source verification.'),
78:(X,'IDSA group presentation/publication list is not an individual original paper or an independent controlled experiment.'),
79:(X,'CORDIS project-results page lists multiple publications. It is a discovery index and mixed DOI content cannot be treated as the identifier or result of a single paper.'),
80:(X,'Institutional author search result page is a multi-publication catalogue, not an original individual study.'),
81:(X,'CSAuthors author bibliography is an index, not an original paper-specific empirical source.'),
82:(T,'Scribd copy of the institutional network-monitoring thesis summary is a related transferable lead. It is a secondary copy of a possibly identical study, not new independent evidence or verified full text.'),
83:(X,'Researchr author alias/publication index is not a separate original empirical source.'),
84:(X,'Faculty annual report/publication inventory is administrative evidence, not the original individual scientific experiment.'),
85:(X,'Construction-drawing patent is an irrelevant numeric DOI-fragment match; no relation to federated learning or healthcare anomaly detection.'),
86:(X,'Lithuanian business-registry bulletin contains a coincidental numeric match, not a scientific FL/security study.'),
87:(X,'German construction-drawing patent is an irrelevant numeric match, outside the healthcare FL/anomaly research scope.'),
88:(X,'Telecom peering/routing presentation is a coincidental numeric-ID match, not federated ML or healthcare anomaly evidence.'),
89:(X,'Pachinko-machine patent is an unrelated numeric-ID match, outside the research question and original empirical-paper scope.'),
90:(X,'Business-registration filing contains a coincidental numerical identifier; it is not research evidence.'),
91:(X,'Judicial administrative notice is an unrelated numeric match, not an FL/security study.'),
92:(X,'Video-game community page is an unrelated application-number match, not a scientific study.'),
93:(X,'Historical book catalogue on Mongolia is an irrelevant bibliographic-ID match, unrelated to FL/security.'),
94:(X,'GEO RNA-sequencing sample record contains a matching read-count number but is unrelated to the healthcare FL/security comparison.'),
95:(X,'Wikisource historical text is an irrelevant page/revision-number match, not a scientific FL/security source.'),
96:(X,'Japanese pachinko patent is another unrelated numerical match, not an original FL/security study.'),
97:(X,'Retail rug product has a coincident numerical identifier and no scientific relevance.'),
98:(T,'Original-publisher Edelson model-misconduct mitigation paper uses distributed EHR data. Retain transferable false-positive/model-integrity evidence; it does not establish staff access-session misuse detection.'),
99:(T,'PubMed record identifies the same Edelson model-misconduct mitigation study. Retain bibliographic provenance, not another independent study or an original-source audit.'),
100:(T,'ResearchGate page identifies the same model-misconduct mitigation paper. Transferable lead; secondary metadata/discovery is not a fresh full-source verification.'),
101:(X,'Kuo Lab publication list includes multiple works/DOIs. It is an author index rather than an original individual study; first DOI in mixed text is not used for identification.'),
102:(X,'Yale author profile includes multiple publications and identifiers, not an individual original empirical source.'),
103:(T,'OpenAlex individual record identifies the Edelson model-misconduct mitigation work. Retain transferable metadata provenance; original full text is not verified by this record.'),
104:(T,'Mendeley individual catalogue record identifies the same Edelson paper. Transferable metadata lead, not independent experimental evidence or original-source coverage.'),
105:(X,'Main article is interpretable clinical prediction using symbolic regression. Model-misconduct paper appears as related/citing content; main study is outside the security/anomaly task.'),
106:(T,'Chinese PubMed summary/translation concerns the same Edelson paper. Retain bibliographic lead; it cannot substitute for the original source or count as an independent study.'),
107:(U,'Cloud-assisted blockchain/split-FL IoMT privacy paper may be a transferable security architecture. Returned excerpt mixes recommended model-misconduct content, so its own target/experiment and anomaly intervention remain unresolved.'),
108:(X,'Main study concerns early Alzheimer diagnosis. Model-misconduct text is related/recommended content rather than the main paper’s task; exclude from security/anomaly experimental comparison.')}
assert set(M)==set(range(1,109))
expected={1:'CH01-R001',18:'CH02-R001',35:'CH05-R001',53:'CH06-R001',66:'CH08-R003',70:'CH10-R001',85:'CH12-R001',98:'CH14-R002',108:'CH14-R012'}
root_by_url={r['canonical_url']:r for r in root['records']}
shared_decisions=[]
for i,(url,rs) in enumerate(groups.items(),1):
    if i in expected: assert rs[0]['record_id']==expected[i]
    decision,reason=M[i]
    if url in root_by_url:
        prior=root_by_url[url]
        if prior['decision']!=decision:
            shared_decisions.append({'canonical_url':url,'root_decision':prior['decision'],'manual_challenger_decision':decision,'resolution':'Preserved root semantic decision for the same URL; reason also retains challenger context.'})
            reason=f"{reason} Consistent same-URL screening status inherited from root ledger: {prior['decision']}."
            decision=prior['decision']
    for r in rs:
        r['decision']=decision
        r['decision_reason']=reason
        r['screening_scope']='MANUAL_TITLE_AND_RETURNED_SNIPPET_SCREEN; not source-level verification'
        r['screening_unit']='Returned URL candidate; not necessarily an independent study'
        r['full_source_verification_status']='NOT ASSERTED BY THIS DISCOVERY LEDGER; consult separate source assessments'
        r.update(identifiers_from_url(r['url']))

def csv_write(path,records):
    fields=['record_id','agent','batch_id','returned_order_in_batch','title','url','canonical_url','verifiedDOI_fromURL','DOI_verification_scope','public_identifiers_fromURL','web_marker','decision','decision_reason','screening_scope','access_level_for_this_record','raw_file','timestamp_utc','individual_query_attribution','global_engine_hit_count','snippet','exact_batch_input']
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');writer.writeheader()
        for r in records:
            row=dict(r);row['exact_batch_input']=json.dumps(row.get('exact_batch_input'),ensure_ascii=False)
            row['public_identifiers_fromURL']=json.dumps(row.get('public_identifiers_fromURL',{}),ensure_ascii=False)
            writer.writerow(row)

challenger['screening_note']='All 108 unique returned URLs screened manually by title and returned snippet. Repeated occurrences retain all batch provenance. UNCERTAIN is an explicit unresolved triage status, not an exclusion. Original-source coverage is a separate audit.'
challenger['same_url_status_reconciliation']=shared_decisions
(OUT/'Challenger_Web_Returned_Records.json').write_text(json.dumps(challenger,ensure_ascii=False,indent=2),encoding='utf-8')
csv_write(OUT/'Challenger_Web_Returned_Records.csv',challenger['records'])

all_rows=[]
for data,agent in [(root,'root'),(challenger,'refresh_challengers')]:
    for r in data['records']:
        r=dict(r);r.setdefault('agent',agent);r.setdefault('screening_scope','MANUAL_TITLE_AND_RETURNED_SNIPPET_SCREEN; not source-level verification')
        r.update(identifiers_from_url(r['url']))
        r.setdefault('timestamp_utc',r.get('started_utc'))
        all_rows.append(r)
all_groups={}
for r in all_rows:all_groups.setdefault(r['canonical_url'],[]).append(r)
union=[]
conflicts=[]
for i,(url,rs) in enumerate(all_groups.items(),1):
    decisions=sorted(set(r['decision'] for r in rs))
    if len(decisions)>1: conflicts.append({'url':url,'record_ids':[r['record_id'] for r in rs],'decisions':decisions})
    union.append({'candidate_id':f'UWEB-{i:03d}','canonical_url':url,'titles':list(dict.fromkeys(r['title'] for r in rs)),
        'returned_occurrence_count':len(rs),'record_ids':[r['record_id'] for r in rs],
        'agents':sorted(set(r['agent'] for r in rs)),'batch_ids':list(dict.fromkeys(r['batch_id'] for r in rs)),
        'web_markers':[r['web_marker'] for r in rs],'decision':decisions[0] if len(decisions)==1 else 'DECISION_CONFLICT',
        'verifiedDOI_fromURL':list(dict.fromkeys(r['verifiedDOI_fromURL'] for r in rs if r['verifiedDOI_fromURL'])),
        'public_identifiers_fromURL':list({json.dumps(r['public_identifiers_fromURL'],sort_keys=True):r['public_identifiers_fromURL'] for r in rs if r['public_identifiers_fromURL']}.values()),
        'decision_reasons':list(dict.fromkeys(r['decision_reason'] for r in rs)),
        'source_verification':'DISCOVERY_ONLY; see separate original-source assessments',
        'deduplication_rule':'Normalized URL equality only. No first-DOI/body/title-only study merge.'})
all_batches=[]
for data,agent in [(root,'root'),(challenger,'refresh_challengers')]:
    for b in data['batches']:all_batches.append(dict(b,agent=agent))
unified={'schema':'unified-returned-web-search-ledger/1','scope':'All search-type returned result occurrences in five root WEB batches and nine challenger search-containing calls. Retrieval-only READ/CH view segments excluded. Zero-return CH09 retained in batch ledger.',
    'record_unit':'Returned URL appearance in a tool response, not a database hit or an independent study',
    'candidate_unit':'Conservatively normalized unique URL; different URLs of one paper may remain distinct',
    'screening_method':'Manual title/returned-snippet review of every candidate, retaining uncertainty explicitly; no automated keyword-only decision and no first-DOI extraction merge.',
    'count_limits':'Global engine hit counts are unavailable. Multiple-query responses do not permit per-query attribution; report returned records per batch only. This is documented current discovery and does not recreate historical database counts.',
    'full_text_limit':'Search return/snippet screening is not full-text source verification. Candidate selection and any separate original-source assessment have separate evidentiary levels.',
    'batches':all_batches,'records':all_rows}
(OUT/'Unified_Web_Returned_Records.json').write_text(json.dumps(unified,ensure_ascii=False,indent=2),encoding='utf-8')
csv_write(OUT/'Unified_Web_Returned_Records.csv',all_rows)
(OUT/'Unified_Web_Screened_Union.json').write_text(json.dumps({'schema':'unified-screened-url-candidates/1','scope':unified['candidate_unit'],'deduplication_rule':'Normalized URL only; no study-level count claimed.','candidates':union},ensure_ascii=False,indent=2),encoding='utf-8')
rawhash=[]
for b in all_batches:
    p=Path(b['raw_file']);actual=hashlib.sha256(p.read_bytes()).hexdigest();stored=b.get('sha256') or b.get('raw_sha256')
    rawhash.append({'raw_file':str(p),'sha256':actual,'matches_normalization_time_hash':stored==actual if stored else None})
valid={D,T,B,X,U}
qa={'root_returned_occurrences':len(root['records']),'challenger_returned_occurrences':len(challenger['records']),
    'total_returned_occurrences':len(all_rows),'total_normalized_unique_url_candidates':len(union),
    'duplicate_url_appearances_beyond_first':len(all_rows)-len(union),
    'root_unique_urls':len(set(r['canonical_url'] for r in root['records'])),
    'challenger_unique_urls':len(groups),'cross_agent_shared_unique_urls':len(set(r['canonical_url'] for r in root['records'])&set(groups)),
    'batch_counts':{b['batch_id']:b.get('returned_search_record_count',b.get('returned_record_count')) for b in all_batches},
    'decision_counts_occurrences':dict(collections.Counter(r['decision'] for r in all_rows)),
    'decision_counts_unique_url_candidates':dict(collections.Counter(r['decision'] for r in union)),
    'challenger_decision_counts_occurrences':dict(collections.Counter(r['decision'] for r in challenger['records'])),
    'all_rows_decided_with_reason':all(r.get('decision') in valid and r.get('decision_reason') for r in all_rows),
    'all_record_ids_unique':len({r['record_id'] for r in all_rows})==len(all_rows),
    'literal_url_doi_occurrences':sum(bool(r['verifiedDOI_fromURL']) for r in all_rows),
    'literal_url_doi_values':sorted({r['verifiedDOI_fromURL'] for r in all_rows if r['verifiedDOI_fromURL']}),
    'all_raw_search_markers_reconciled':all(b.get('returned_search_record_count',b.get('returned_record_count'))==b.get('returned_search_marker_count',b.get('web_marker_count')) for b in all_batches),
    'challenger_original_csv_reconciliation':{'original':challenger['original_csv_occurrences'],'normalized':challenger['normalised_raw_occurrences'],'missing':challenger['not_in_prior_csv'],'extra':challenger['prior_csv_not_in_raw_normalisation']},
    'no_unparsed_challenger_headers':not challenger['unparsed_headers'],'zero_return_batch_preserved':'CH09' in [b['batch_id'] for b in all_batches],
    'same_url_decision_conflicts':conflicts,'resolved_same_url_status_differences':shared_decisions,
    'raw_files':rawhash,'raw_response_text_immutable':all(h['matches_normalization_time_hash'] is not False for h in rawhash),
    'deduplication':'Normalized URL only; no arbitrary snippet DOI or title-only merge',
    'not_claimed':['Global search-engine total hits','Counts attributable to each query in a mixed-query response','Independent-study count from URL candidate count','Exhaustive novelty proof','Full-text verification of every result','Reconstruction of historical database counts']}
(OUT/'Unified_Web_Screening_QA.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2),encoding='utf-8')
uncertain=[r for r in union if r['decision']==U]
md=['# فحص جميع نتائج بحث الويب المعادة', '',
    f"فُحصت جميع {len(all_rows)} مرات ظهور للنتائج ({len(root['records'])} من بحث المهمة الرئيسية و{len(challenger['records'])} من بحث الأدبيات المنافسة)، وتمثل {len(union)} رابطًا بعد إزالة تكرار الروابط بحذر. عدد الروابط ليس عدد الدراسات المستقلة؛ قد يظهر المصدر نفسه لدى الناشر وPubMed وResearchGate.", '',
    'أُبقيت جميع النصوص المعادة ومدخلات الاستعلامات والوقت والدفعة والمعرف الخام، بما فيها دفعة CH09 التي لم تُعد نتائج بحث. استُبعدت مقاطع فتح المصادر فقط من عداد نتائج البحث. الأعداد خاصة بالنتائج التي أعادتها الأداة، وليست إجمالي نتائج محرك البحث. لا يمكن توزيع نتيجة دفعة متعددة الاستعلامات على كل استعلام.', '',
    '## قرارات الفرز', '', '| القرار | مرات الظهور | الروابط الفريدة |', '|---|---:|---:|']
for status in [D,T,B,X,U]:md.append(f"| {status} | {qa['decision_counts_occurrences'].get(status,0)} | {qa['decision_counts_unique_url_candidates'].get(status,0)} |")
md+=['', 'القرار مستند إلى قراءة العنوان والمقتطف المعاد لكل رابط، وليس تحققًا من النص الكامل. أُبقيت النتائج غير المحسومة UNCERTAIN ظاهرة، ولم تُعامل بوصفها مستبعدة أو مفحوصة بالكامل. تُراجع الأدلة الأصلية في ملفات تقييم المصادر المنفصلة.', '',
     '## الأعداد حسب الدفعة', '', '| الدفعة | النتائج المعادة |', '|---|---:|']
for batch,count in qa['batch_counts'].items():md.append(f'| {batch} | {count} |')
md+=['', '## الروابط غير المحسومة', '', '| معرف المرشح | العنوان | السبب |', '|---|---|---|']
for r in uncertain:
    title=r['titles'][0].replace('|','/');reason=r['decision_reasons'][0].replace('|','/')
    md.append(f"| {r['candidate_id']} | {title} | {reason} |")
md+=['', 'أُنجزت مراجعة جميع النتائج المعادة ضمن هذا النطاق وسُجل سبب لكل قرار. لا يثبت هذا اكتمال النصوص الأصلية لجميع المرشحين، ولا يعيد مصادقة الأعداد التاريخية، ولا يثبت أسبقية عالمية. لا تزال حالات عدم الحسم بحاجة إلى تحديد المصدر/تاريخ الإتاحة أو قراءة الأصل وفق أهميتها للادعاء البحثي.', '',
     'الملفات الأساسية: Unified_Web_Returned_Records.json/.csv (كل مرات الظهور)، Unified_Web_Screened_Union.json (الروابط المرشحة)، Unified_Web_Screening_QA.json (المصالحة والحدود).']
(OUT/'Unified_Web_Screening_AR.md').write_text('\n'.join(md)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in qa.items() if k not in ['raw_files','not_claimed','resolved_same_url_status_differences']},ensure_ascii=False,indent=2))
