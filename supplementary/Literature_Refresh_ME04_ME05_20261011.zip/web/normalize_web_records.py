from pathlib import Path
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode, unquote
import csv, hashlib, json, re

OUT=Path(r'C:/Users/RNO/Desktop/Coureses/P1/ars_literature_refresh_2026_10_11/web')
records=[]
batches=[]
def canonical(url):
    p=urlsplit(url)
    host=p.netloc.lower()
    if host.startswith('www.'):host=host[4:]
    path=unquote(p.path).rstrip('/') or '/'
    query=urlencode([(k,v) for k,v in parse_qsl(p.query,keep_blank_values=True)
                     if not k.lower().startswith('utm_') and k.lower() not in ['fbclid','gclid','ref','source']])
    # HTTP/HTTPS variants and tracking parameters only. Preserve meaningful IDs.
    return urlunsplit(('https',host,path,query,''))

for f in sorted(OUT.glob('WEB*Raw.json')):
    o=json.loads(f.read_text(encoding='utf-8-sig'))
    s=o['response']
    # Tool separators can follow the snippet inline rather than on a new line.
    parts=[x.strip() for x in re.split(r'\s*-{80,}\s*\n',s) if x.strip()]
    marker_count=len(re.findall('\ue200cite\ue202(.*?)\ue201',s))
    batch={'batch_id':o['search_id'],'raw_file':str(f),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),
           'exact_input':o['input'],'started_utc':o.get('started_utc'),'ended_utc':o.get('ended_utc'),
           'returned_record_count':len(parts),'web_marker_count':marker_count,
           'engine_total_hits':None,'engine_total_hits_status':'NOT_REPORTED_BY_TOOL',
           'per_query_counts':'UNATTRIBUTABLE: response combines queries; batch counts only'}
    batches.append(batch)
    for n,part in enumerate(parts,1):
        marker=re.search('\ue200cite\ue202(.*?)\ue201',part)
        header=part[:marker.start()].strip() if marker else part.splitlines()[0]
        m=re.match(r'^(.*?)\s+\((https?://.+)\)\s*$',header,flags=re.S)
        title=' '.join(m.group(1).split()) if m else ' '.join(header.split())
        url=m.group(2) if m else None
        snippet=part[len(header):].strip()
        if marker:snippet=snippet.replace(marker.group(0),'',1).strip()
        records.append({'record_id':f"{o['search_id']}-R{n:03d}",'batch_id':o['search_id'],
                        'returned_order_in_batch':n,'title':title,'url':url,
                        'canonical_url':canonical(url) if url else None,
                        'normalised_title':' '.join(re.sub(r'[^\w\s]',' ',title.lower()).split()),
                        'web_marker':marker.group(1) if marker else None,
                        'snippet':snippet,'raw_result':part,'raw_file':str(f),
                        'exact_batch_input':o['input'],'started_utc':o.get('started_utc'),
                        'ended_utc':o.get('ended_utc'),
                        'access_level_for_this_record':'SEARCH_RETURN_ONLY; not full-text source verification',
                        'global_engine_hit_count':None,
                        'individual_query_attribution':'UNKNOWN_WITHIN_MULTIPLE_QUERY_BATCH' if len(o['input'].get('search_query',[]))>1 else 'SINGLE_QUERY_BATCH'})

(OUT/'Web_Returned_Records.json').write_text(json.dumps({'schema':'web-returned-records/1','search_date_local':'2026-10-11','timezone':'Asia/Singapore','scope':'All preserved WEB search-batch results, excluding READ results. Received raw segments retained in full.','batches':batches,'records':records},ensure_ascii=False,indent=2),encoding='utf-8')
with (OUT/'Web_Returned_Records.csv').open('w',encoding='utf-8-sig',newline='') as f:
    fields=['record_id','batch_id','returned_order_in_batch','title','url','canonical_url','web_marker','snippet','raw_file','started_utc','ended_utc','access_level_for_this_record']
    w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(records)
print(json.dumps({'batch_counts':{b['batch_id']:b['returned_record_count'] for b in batches},'total':len(records),'marker_reconciliation':all(b['returned_record_count']==b['web_marker_count'] for b in batches)},ensure_ascii=False))
