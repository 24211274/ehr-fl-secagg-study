from pathlib import Path
from urllib.parse import urlsplit,urlunsplit,parse_qsl,urlencode,unquote
import csv,hashlib,json,re,collections
BASE=Path(r'C:/Users/RNO/Desktop/Coureses/P1/ars_literature_refresh_2026_10_11')
OUT=BASE/'web'
def canonical(url):
 p=urlsplit(url);host=p.netloc.lower()
 if host.startswith('www.'):host=host[4:]
 return urlunsplit(('https',host,unquote(p.path).rstrip('/') or '/',urlencode([(k,v) for k,v in parse_qsl(p.query,keep_blank_values=True) if not k.lower().startswith('utm_') and k.lower() not in ['fbclid','gclid','ref','source']]),''))
rows=[];batches=[];unparsed=[]
for f in sorted((BASE/'challengers/raw').glob('CH[0-9][0-9].json')):
 d=json.loads(f.read_text(encoding='utf-8-sig'))
 if not d['tool_input'].get('search_query'):continue
 raw=d['raw_response'];parts=[x.strip() for x in re.split(r'\s*-{80,}\s*\n',raw) if x.strip()]
 search_markers=re.findall(r'\ue200cite\ue202(turn\d+(?:search|academia)\d+)\ue201',raw)
 n=0
 for segment_no,part in enumerate(parts,1):
  marker=re.search(r'\ue200cite\ue202([^\ue201]+)\ue201',part)
  if not marker or not re.fullmatch(r'turn\d+(?:search|academia)\d+',marker.group(1)):continue
  header=part[:marker.start()].strip();m=re.match(r'^(.*?)\s+\((https?://.+)\)\s*$',header,re.S)
  if not m:unparsed.append({'file':str(f),'marker':marker.group(1),'header':header});continue
  n+=1;title=' '.join(m.group(1).split());url=m.group(2)
  rows.append({'record_id':f"{d['search_id']}-R{n:03d}",'batch_id':d['search_id'],'agent':'refresh_challengers',
   'returned_order_in_batch':n,'raw_segment_order':segment_no,'title':title,'url':url,'canonical_url':canonical(url),
   'normalised_title':' '.join(re.sub(r'[^\w\s]',' ',title.lower()).split()),'web_marker':marker.group(1),
   'snippet':part[marker.end():].strip(),'raw_result':part,'raw_file':str(f),'timestamp_utc':d['timestamp_utc'],
   'exact_batch_input':d['tool_input'],'individual_query_attribution':'BATCH_ONLY; mixed-query result attribution unavailable',
   'access_level_for_this_record':'SEARCH_RETURN_ONLY; not full-text source verification','global_engine_hit_count':None})
 batches.append({'batch_id':d['search_id'],'raw_file':str(f),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),
  'exact_input':d['tool_input'],'timestamp_utc':d['timestamp_utc'],'returned_search_record_count':n,
  'returned_search_marker_count':len(search_markers),'query_count':len(d['tool_input']['search_query']),
  'engine_total_hits':None,'per_query_counts':'UNATTRIBUTABLE_WITHIN_BATCH',
  'zero_result_preserved':n==0 and 'No results were found' in raw,
  'retrieval_segments_excluded_from_search_counts':True})
with (BASE/'challengers/Returned_Search_Records.csv').open(encoding='utf-8-sig',newline='') as f:old=list(csv.DictReader(f))
oldkeys={(r['tool_call_id'],r['web_reference']) for r in old};newkeys={(r['batch_id'],r['web_marker']) for r in rows}
result={'schema':'challenger-web-return-records/1','scope':'All search-type markers in CH search-containing raw responses. Retrieval-only view segments excluded. Original challenger CSV is retained unchanged.','batches':batches,'records':rows,
 'original_csv_occurrences':len(old),'normalised_raw_occurrences':len(rows),'not_in_prior_csv':sorted(newkeys-oldkeys),'prior_csv_not_in_raw_normalisation':sorted(oldkeys-newkeys),'unparsed_headers':unparsed}
(OUT/'Challenger_Web_Returned_Records.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
groups={}
for r in rows:groups.setdefault(r['canonical_url'],[]).append(r)
print(json.dumps({'occurrences':len(rows),'unique_urls':len(groups),'csv_missing':len(newkeys-oldkeys),'csv_extra':len(oldkeys-newkeys),'unparsed':len(unparsed),'batch_counts':{b['batch_id']:b['returned_search_record_count'] for b in batches}},ensure_ascii=False))
