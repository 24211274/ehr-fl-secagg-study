from pathlib import Path
import csv,json,collections

OUT=Path(r'C:/Users/RNO/Desktop/Coureses/P1/ars_literature_refresh_2026_10_11/web')
DATA=json.loads((OUT/'Web_Returned_Records.json').read_text(encoding='utf-8'))
# These are per-record semantic title/snippet decisions made after review.
# No automatic inclusion/exclusion keywords or first-DOI-in-snippet matching.
M={
 'WEB-001-003':[
 ('RETAIN_DIRECT','Synthetic EHR staff-access anomaly detection with VAE; already-covered Iqbal source. Retain for current gap comparison; FL future-work excerpt is discovery, not a new full-source audit.'),
 ('RETAIN_TRANSFERABLE','Original blockchain/healthcare federated distillation, DP and threshold-encryption aggregation system; potential broad privacy/cost overlap. Direct staff-access task not established by discovery excerpt.'),
 ('RETAIN_TRANSFERABLE','Healthcare EMR/blockchain FL paper reports a secure data aggregation algorithm and performance evaluation; retain transferable challenge pending actual task/intervention verification.'),
 ('BACKGROUND','Multi-institutional clinical study execution and imputation via secure virtual pooling, not staff-access anomaly detection; background only for distributed-data analysis.'),
 ('RETAIN_DIRECT','Conference candidate explicitly describes CNN-LSTM detection on a synthetic EHR access dataset; secondary index only, so numerical/method claims require original source.'),
 ('BACKGROUND','Tutorial about FL/blockchain architectures and compliance, including brain-tumor segmentation; citation-chaining background rather than an original matched access-detection experiment.'),
 ('EXCLUDE','Commercial glossary definition/examples, not an original academic study or empirical comparator.'),
 ('BACKGROUND','Remote healthcare service framework with integration/access-control claims; snippet does not establish staff-access detection or a matched secure-aggregation intervention.'),
 ('UNCERTAIN','Generic journal-volume PDF header and agent-layer excerpt; paper title, empirical target and contribution cannot be identified reliably from the returned text.'),
 ('BACKGROUND','Decentralized healthcare analytics framework on medical sources/IoMT; secure aggregation appears as architectural option, without direct audit-session detection evidence in discovery text.'),
 ('EXCLUDE','Vendor webinar registration about EHR access risk scores; no original peer-reviewed experiment.'),
 ('BACKGROUND','Microservices/blockchain/FL clinical analytics architecture; previously checked work concerns patient prediction, not staff access-session anomaly detection.'),
 ('EXCLUDE','Patent application, outside the protocol original empirical-paper comparator class; no reported scientific experiment established.'),
 ('UNCERTAIN','Institutional PDF is returned under publication-date header rather than paper title; snippet concerns longitudinal health-data exchange, so exact task remains unresolved.'),
 ('UNCERTAIN','PDF returned under journal name alone; excerpt proposes secure FL and audit logs without identifiable target, experiment or component isolation.'),
 ('UNCERTAIN','Generic journal heading and reference-heavy snippet; identity and whether any relevant original evaluation exists cannot be determined.'),
 ('EXCLUDE','Title explicitly targets clinical emergency-triage decision support using LLMs; audit logs are system administration, not the anomaly-detection outcome.'),
 ('BACKGROUND','Architectural overview of smart-healthcare FL; background only, not an original matched detector/aggregation experiment.')],
 'WEB-004-006':[
 ('BACKGROUND','EHR access via federated authentication/identity trust rather than federated machine learning or anomaly detection; access-governance background only.'),
 ('BACKGROUND','PMC copy of cloud-based federated identity/authentication paper; not a machine-learning detection comparison.'),
 ('BACKGROUND','AHIMA PDF copy of cloud-based EHR identity/authentication paper; federation is identity trust, not FedAvg.'),
 ('BACKGROUND','Accountability-oriented poisoning survey; useful for threat-model/citation chaining, not original EHR-access experimental evidence.'),
 ('EXCLUDE','Unpublished demonstration GitHub repository and evaluation guidance; no original scholarly empirical comparator established.'),
 ('EXCLUDE','Patent application for generic audit generation/attestation; outside original empirical-paper scope and direct EHR session task.'),
 ('BACKGROUND','IETF Internet-Draft on multi-tenant agent FL privacy; threat-model background, not an EHR detector experiment or finalized standard.'),
 ('UNCERTAIN','Generic PDF publication header; snippet discusses ABHA identity and blockchain governance, but paper identity and actual target cannot be resolved.'),
 ('EXCLUDE','Commercial governance/control guide rather than original academic experimental evidence.'),
 ('EXCLUDE','Commercial/generated-style enterprise finance web article without verified original scholarly source; not usable as empirical novelty evidence.'),
 ('RETAIN_TRANSFERABLE','Original-publisher IIoT intrusion-detection candidate explicitly claims private model aggregation; retain transferable security/cost challenge pending exact source identity and method review.'),
 ('UNCERTAIN','Repository PhD PDF returned with generic title; privacy/attack material may be background, but title, original contribution and experiments are unresolved.'),
 ('BACKGROUND','EHR identity-based federation, authorization and audit governance; no machine-learning access-anomaly evaluation established in the snippet.'),
 ('RETAIN_DIRECT','Explicit FL anomaly detection for health-information systems including unauthorized EHR access; potentially close original candidate, requiring dataset and method inspection.'),
 ('EXCLUDE','Commercial protocol tutorial with hypothetical MedSecure deployment and future attack scenarios; no verified original experimental paper.'),
 ('BACKGROUND','Secondary paper summary about blockchain/IPFS EHR access control and sharing; snippet explicitly says FL not incorporated.'),
 ('BACKGROUND','Blockchain federation for EHR sharing and smart-contract access governance; federation refers blockchain entities, not a trained access-anomaly detector.'),
 ('EXCLUDE','Cloud-provider audit guidelines, outside original study comparator scope; no access-anomaly FL experiment.')],
 'WEB-007':[
 ('RETAIN_DIRECT','Discovery record for already-audited Martinez Llamas direct EHR-access LSTM-AE/Flower/FedAvg study; ResearchGate access status is not current overall source availability.'),
 ('RETAIN_DIRECT','J-GLOBAL metadata record of same-titled Martinez Llamas direct EHR access FL work; metadata only and not independent experimental replication.'),
 ('RETAIN_TRANSFERABLE','EPP-BCFL healthcare/edge privacy architecture reports anomaly/secure-analytics components; retain broad overlap while distinguishing staff-session task and actual aggregation comparator.'),
 ('RETAIN_TRANSFERABLE','Already-audited BFL-STPC preprint combines EHR security, FL and protected updates; task and grouped ablation limits retained, not dismissed because numerical contradictions exist.'),
 ('RETAIN_DIRECT','Duplicate returned URL for already-covered Iqbal VAE EHR-access study; preserve occurrence and merge only in unique-URL layer.'),
 ('RETAIN_TRANSFERABLE','FedSecure-Chain detects malicious model-training/poisoning contributions in e-health; relevant robustness/aggregation challenge, not patient-record misuse ground truth.'),
 ('BACKGROUND','Healthcare CNN-LSTM/graph/FL candidate emphasizes sensor and multimodal medical samples; no direct EHR staff-access task established by the returned abstract.'),
 ('UNCERTAIN','PDF titled only biomedicines with encrypted updates and blockchain model auditability; exact article identity, task and intervention require original-source retrieval.'),
 ('RETAIN_DIRECT','MedSecAI candidate explicitly combines sequential threat detection, XGBoost and private FL on EHR-related benchmark; retain direct candidate while verifying dataset, target and venue independently.'),
 ('BACKGROUND','Multimodal diagnostic FL survey covering imaging, wearables and heart disease; review background, not original staff-access security experiment.'),
 ('UNCERTAIN','Scribd-hosted manuscript with placeholder IEEE ISBN and claimed architecture; publication identity and original experiment unverified, so not accepted as peer-reviewed evidence.'),
 ('BACKGROUND','Conference-style survey/comparison of healthcare FL anomaly methods; background/citation chaining, no specific original staff-access intervention established.'),
 ('RETAIN_TRANSFERABLE','Healthcare wearable/malicious-node FL detection with reported baselines and PhysioNet results; transferable cybersecurity candidate, not direct staff-access logs.'),
 ('RETAIN_TRANSFERABLE','Edge patient-monitoring anomaly framework includes FL, encrypted updates and system-cost endpoints; retain for broad privacy/cost overlap, task differs from EHR staff sessions.'),
 ('RETAIN_DIRECT','Repeated IJISS direct FL-health-information-system anomaly candidate; preserve distinct discovery occurrence and inspect original source.'),
 ('BACKGROUND','Privacy-adaptive personalized clinical-healthcare intelligence framework; quoted unauthorized access motivates privacy but does not establish staff-access anomaly task.')],
 'WEB-008-010':[
 ('RETAIN_TRANSFERABLE','Repeated original-publisher Maghrabi blockchain/FL/threshold-privacy framework; preserve provenance, source assessment handled separately.'),
 ('EXCLUDE','Commercial FL-security tutorial with code and framework links; not original scholarly comparative evidence.'),
 ('RETAIN_DIRECT','Already-covered AIBA-EHR original synthetic access detector and blockchain-cost study; inspect actual methods before interpreting narrative references to FL as an implemented comparison.'),
 ('BACKGROUND','TMLR paper on evolving features/tasks/models/aggregators; general FL methodological framework, not direct EHR access or a matched secure-anomaly cost comparison in the discovery excerpt.'),
 ('BACKGROUND','Systematic review of healthcare FL/blockchain/XAI; background and chaining, not an original empirical comparator.'),
 ('UNCERTAIN','TechScience PDF header truncated, actual paper title unavailable; snippet mentions FedAvg/SecAgg and defenses but target and experiments remain unresolved.'),
 ('EXCLUDE','Commercial comparison blog about industrial fleets; no verified original academic experiment, source cannot substantiate novelty claims.'),
 ('RETAIN_TRANSFERABLE','FedSOC multi-client log-anomaly thesis explicitly lists FedAvg and SecAgg+ sections; potentially close transferable comparison. Full text, language, publication date and matched-cost setup require checking.'),
 ('BACKGROUND','AI/blockchain secure interoperable EMR data exchange architecture; excerpt identifies clinical exchange/NLP/FHIR rather than audit-session anomaly detection.'),
 ('RETAIN_TRANSFERABLE','Journal PDF snippet explicitly contrasts FedAvg with privacy and DP-SecAgg under label-flipping; retain candidate for component/cost challenge despite unresolved article identity.'),
 ('BACKGROUND','Systematic blockchain-healthcare security/interoperability review; not original matched experimental evidence.'),
 ('EXCLUDE','Returned main title concerns porous-carbon structure/function modelling; healthcare FL phrases occur in references, not a relevant study target.'),
 ('EXCLUDE','Chinese data-disaster-recovery patent, outside original-paper and EHR staff-access scope.'),
 ('UNCERTAIN','Generic journal-title PDF offers only FedAvg/SecAgg and anomaly terms; insufficient title/snippet evidence to determine original task or relevance.'),
 ('UNCERTAIN','Third-party copy of a DP/SecAgg Flower thesis; implementation might be transferable, but original institutional source, experiment and relation to anomaly detection remain unverified.'),
 ('RETAIN_TRANSFERABLE','Candidate secure additive-sharing aggregation scheme; snippet mixes survey text and may be bibliographically contaminated. Keep as unverified protocol challenge, requiring original source identity.'),
 ('RETAIN_TRANSFERABLE','Network-monitoring paper explicitly compares regular FedAvg and SecAgg+; potentially close transferable intervention; original source and matched setup need verification.')],
 'WEB-011-013':[
 ('RETAIN_TRANSFERABLE','Already-audited Panth/Nigam verifiable secure aggregation for financial fraud; strong broad aggregation/integrity/cost overlap, task is not EHR access.'),
 ('RETAIN_DIRECT','Institutional thesis on Italian EHR ATNA audit-log multimodal anomaly detection; direct-task grey-literature challenge, not counted as peer-reviewed original paper without status verification.'),
 ('EXCLUDE','Related Abbasi masters thesis explicitly excluded by user; retain raw discovery record but do not request it, treat it as read, or count it as an independent replication.'),
 ('BACKGROUND','Original device-model identification under label-flipping; relevant FL robustness context but predictive target is device identity rather than anomaly/access detection.'),
 ('BACKGROUND','Review of FL insider-threat architectures in SQL environments; citation-chaining background, not independent original comparison.'),
 ('RETAIN_TRANSFERABLE','Secondary discovery record for already-fulltext-audited Abbasi CERT conference paper; use original six-page audit for scientific conclusions, not index marketing text.'),
 ('BACKGROUND','Comprehensive IoT/IIoT FL/TinyML/XAI intrusion survey; background and chaining, not original EHR-access evaluation.'),
 ('EXCLUDE','Author publication list with submitted/preparation items; no individual original-paper source or verified experiment returned.'),
 ('EXCLUDE','University syllabus listing FL/security topics, not a research study.'),
 ('RETAIN_TRANSFERABLE','Repeated original edge healthcare-monitoring paper reports FL, encryption and communication/latency measures; retain transferable challenge, distinguish sensor-patient task.'),
 ('RETAIN_TRANSFERABLE','Already-fulltext-audited NeuralFortress CTI work includes secure aggregation, component ablation and costs; relevant counterexample to broad absence claims, not direct EHR access sessions.'),
 ('RETAIN_TRANSFERABLE','TrustFed-CTI original-publisher candidate reports encrypted Paillier aggregation and threat-intelligence evaluation; retain broad protocol/cost challenge pending source-level verification.'),
 ('EXCLUDE','Non-primary banking web article with unverified empirical architecture; not accepted as academic original evidence.'),
 ('BACKGROUND','ResearchGate copy of SQL insider-threat architecture review; review/chaining only, no new independent empirical study.'),
 ('RETAIN_TRANSFERABLE','Previously examined Ikegwu healthcare IoMT/FL privacy study; retain explicit broad overlap and unresolved CO/CL cost-definition issues. This is not Tanvir.'),
 ('EXCLUDE','Commercial EHR vendor security/compliance claims, not original academic research.'),
 ('RETAIN_TRANSFERABLE','Original FORT-IDS IIoT intrusion candidate with federated attention, DP and latency/energy claims; transferable detection/cost context, not direct staff EHR sessions.')]
}

for r in DATA['records']:
    d,reason=M[r['batch_id']][r['returned_order_in_batch']-1]
    r.update({'decision':d,'decision_reason':reason,'screening_level':'Manual semantic title and returned discovery-snippet triage; no source full-text verification inferred',
              'screening_date_local':'2026-10-11','eligible_fulltext_status':'NOT_ESTABLISHED_BY_THIS_RETURN_RECORD'})
for b in DATA['batches']:
    rows=[r for r in DATA['records'] if r['batch_id']==b['batch_id']]
    assert len(M[b['batch_id']])==len(rows)
    b['decision_counts']=dict(collections.Counter(r['decision'] for r in rows))
DATA['screening_rule']='All returned records individually assigned a semantic title/snippet decision; candidate retention is not source correctness or eligibility confirmation. UNCERTAIN records remain visible.'
(OUT/'Web_Returned_Records.json').write_text(json.dumps(DATA,ensure_ascii=False,indent=2),encoding='utf-8')
fields=['record_id','batch_id','returned_order_in_batch','title','url','canonical_url','web_marker','decision','decision_reason','screening_level','snippet','raw_file','started_utc','ended_utc','access_level_for_this_record']
with (OUT/'Web_Returned_Records.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(DATA['records'])
groups={}
for r in DATA['records']:groups.setdefault(r['canonical_url'] or r['record_id'],[]).append(r)
union=[]
for n,(url,rs) in enumerate(groups.items(),1):
    decisions={r['decision'] for r in rs}
    assert len(decisions)==1,(url,decisions)
    union.append({'candidate_id':f'ROOT-WEB-URL-{n:03d}','canonical_url':url,'title':rs[0]['title'],
                  'normalised_title':rs[0]['normalised_title'],'decision':rs[0]['decision'],
                  'reasons':list(dict.fromkeys(r['decision_reason'] for r in rs)),
                  'returned_occurrences':[r['record_id'] for r in rs],
                  'search_batches':list(dict.fromkeys(r['batch_id'] for r in rs)),
                  'dedup_rule':'Exact normalized URL only; no title-only or arbitrary snippet-DOI merge',
                  'evidence_level':'Discovery candidate, not automatically a distinct paper or full-text verified source'})
(OUT/'Web_Screened_Union.json').write_text(json.dumps({'scope':'Root search returned unique URLs; URL candidates are not a count of distinct scientific studies. Alternative index/repository URLs may describe the same work and remain visible unless exact identifier mapping is verified.','records':union},ensure_ascii=False,indent=2),encoding='utf-8')
qa={'returned_records':len(DATA['records']),'unique_url_candidates':len(union),
    'duplicate_url_occurrences':len(DATA['records'])-len(union),
    'decision_counts_occurrences':dict(collections.Counter(r['decision'] for r in DATA['records'])),
    'decision_counts_unique_urls':dict(collections.Counter(r['decision'] for r in union)),
    'all_records_screened':all(r.get('decision') and r.get('decision_reason') for r in DATA['records']),
    'all_titles_urls_and_markers_parsed':all(r['title'] and r['url'] and r['web_marker'] for r in DATA['records']),
    'marker_counts_reconciled':all(b['returned_record_count']==b['web_marker_count'] for b in DATA['batches']),
    'per_batch_returned_counts':{b['batch_id']:b['returned_record_count'] for b in DATA['batches']},
    'per_query_counts':'Not attributable within multiquery batches','global_engine_total_hits':'UNAVAILABLE',
    'retrieval_only_READ_files_excluded':True,'no_first_doi_snippet_merging':True,
    'manuscript_modified':False}
(OUT/'Web_Screening_QA.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(qa,ensure_ascii=False))
