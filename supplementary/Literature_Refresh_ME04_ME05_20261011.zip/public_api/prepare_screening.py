import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
rows=json.loads((ROOT/'Normalized_Records.json').read_text(encoding='utf-8'))
union={}
for r in rows:union.setdefault(r['source']+':'+r['source_id'],[]).append(r)
out=[]
for i,(key,rr) in enumerate(union.items(),1):
    b=dict(max(rr,key=lambda r:len(r.get('abstract') or '')))
    b['stable_source_id']=key;b['screening_index']=i
    b['database_provenance']=[{'database':r['database'],'record_id':r['record_id'],'search_ids':r['search_ids'],'source_url':r['source_url']} for r in rr]
    b['all_search_ids']=sorted({sid for r in rr for sid in r['search_ids']})
    out.append(b)
(ROOT/'Canonical_Union_To_Screen.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(len(out),sum(len(r.get('abstract') or '') for r in out),sum(len((r.get('abstract') or '').split()) for r in out))
