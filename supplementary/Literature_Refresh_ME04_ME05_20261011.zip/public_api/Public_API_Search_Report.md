# New public-API literature searches — 11 October 2026

Purpose: dated targeted narrative update for ME-04 and ME-05. These are newly executed searches, not validation of historical August counts.

| Database | Search | Total hits | Preserved unique IDs/records | Completeness |
|---|---|---:|---:|---|
| pubmed | S1 | 118 | 118 | COMPLETE_FOR_EXACT_EXECUTED_QUERY |
| pubmed | S2 | 4 | 4 | COMPLETE_FOR_EXACT_EXECUTED_QUERY |
| pubmed | S3 | 137 | 137 | COMPLETE_FOR_EXACT_EXECUTED_QUERY |
| pubmed | S4 | 10 | 10 | COMPLETE_FOR_EXACT_EXECUTED_QUERY |
| europe_pmc | S1 | 85 | 85 | COMPLETE_FOR_EXACT_EXECUTED_QUERY |
| europe_pmc | S2 | 3 | 3 | COMPLETE_FOR_EXACT_EXECUTED_QUERY |
| europe_pmc | S3 | 131 | 131 | COMPLETE_FOR_EXACT_EXECUTED_QUERY |
| europe_pmc | S4 | 10 | 10 | COMPLETE_FOR_EXACT_EXECUTED_QUERY |

Raw query-hit sum: 498; within-database union: PubMed 264, Europe PMC 224; 488 database records before cross-database deduplication. Stable source-ID union: 281; this is a descriptive identity count, not final included-study count.

No abstracts supplied by API for {'pubmed': 2, 'europe_pmc': 0}. Abstract absence is an access/metadata limitation, not an exclusion decision.

## Preserved evidence

- Exact query strings, scopes, date/language restrictions: Frozen_API_Query_Definitions.json.
- URLs, HTTP status/headers, UTC and Asia/Singapore timestamps, byte counts and SHA-256: HTTP_Request_Receipts.json.
- Unmodified response bytes: raw/ (8 search JSON responses and 4 PubMed bibliographic XML responses).
- Returned IDs, hit counts, warnings, translated PubMed terms, pagination and completeness: Search_Result_Manifest.json.
- Bibliographic metadata and available abstracts for every returned ID: Normalized_Records.json and .csv.
- Independent local reconciliation of IDs, records, responses and hashes: Delivery_QA.json.

## Search-language warnings and interpretation

PubMed S1/S2 returned a warning that the quoted phrase "access anomaly" was not found. The translated query omits this OR term; other access/audit/insider/anomaly synonyms remain. The original request, warning, and executed translation are all preserved. No silent query replacement occurred.

PubMed S1/S2 include the EHR MeSH term in addition to title/abstract terms; Europe PMC uses title/abstract only. Their counts should not be expected to match. PubMed publication-date and Europe PMC first-publication-date restrictions are documented as distinct fields.

S3 deliberately retrieves privacy-preserving federated healthcare records for screening; generic disease prediction may still match abstract words such as security. These must be excluded or classed as background/indirect during screening, not treated as direct EHR access-log competitors.

## Limits

- Completeness applies to IDs/metadata returned by each exact executed query; it does not certify exhaustive topic coverage.
- Every query has English and publication-cutoff restrictions. S1 begins in 2000; S2–S4 in 2016; all end on 2026-10-11.
- No HTTP errors or rate-limit responses occurred in the 12 API requests. Requests to NCBI were serial with at least 0.5-second spacing; no credentials or third-party installations were used.
- Bibliographic metadata and abstracts were collected. No paper full text, numerical experiment results, or scientific claims were source-verified in this API task.
- A low/zero direct federated query count is not evidence that prior direct work does not exist. Web discovery and citation chaining are necessary supplements.
- Cross-database DOI/title deduplication, relevance screening and bounded novelty synthesis are downstream stages.

## AI assistance

Codex assisted in formulating, executing and documenting the searches and in normalizing API bibliographic data. Automated retrieval is not human full-text reading or independent scientific validation.
