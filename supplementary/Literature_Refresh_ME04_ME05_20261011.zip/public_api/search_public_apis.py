"""Dated, fully preserved PubMed and Europe PMC searches; stdlib only.

This script does not validate historical search counts, paper results, or full texts.
It preserves search metadata and bibliographic/abstract records for screening.
"""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import json, urllib.request, urllib.parse, urllib.error, time, hashlib, csv
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
RAW = ROOT / 'raw'
RAW.mkdir(parents=True, exist_ok=True)
TZ = timezone(timedelta(hours=8), name='Asia/Singapore')
REQUESTS, QUERIES, RECORDS, ERRORS = [], [], {}, []
LAST_NCBI = 0.0

def stamp():
    now = datetime.now(timezone.utc)
    return {'utc':now.isoformat(), 'asia_singapore':now.astimezone(TZ).isoformat()}

def save(name, obj):
    (ROOT / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')

def plan(progress, active=0):
    labels=['Freeze exact query definitions and provenance rules', 'Execute public API searches and preserve all responses', 'Reconcile counts, normalize metadata, and hand off screening corpus']
    save('Progress_Plan.json', {'native_plan_tool_available':False,'updated':stamp(),'steps':[
        {'step':f'[{100 if i<active else progress if i==active else 0}%] {v}', 'status':'completed' if i<active else 'in_progress' if i==active else 'pending'}
        for i,v in enumerate(labels)]})

def request(url, label, accept='application/json'):
    global LAST_NCBI
    for attempt in (1,2):
        if 'ncbi.nlm.nih.gov' in url:
            wait=max(0, 0.5-(time.monotonic()-LAST_NCBI))
            if wait: time.sleep(wait)
        ts=stamp(); status=None; headers={}; data=b''; error=None
        try:
            req=urllib.request.Request(url, headers={'User-Agent':'Codex-Literature-Audit/1.0 (research metadata; no credentials)','Accept':accept})
            with urllib.request.urlopen(req, timeout=60) as response:
                status=response.status; headers=dict(response.headers.items()); data=response.read()
        except urllib.error.HTTPError as exc:
            status=exc.code; headers=dict(exc.headers.items()); data=exc.read(); error=str(exc)
        except Exception as exc:
            error=f'{type(exc).__name__}: {exc}'
        finally:
            if 'ncbi.nlm.nih.gov' in url: LAST_NCBI=time.monotonic()
        stem=f'{len(REQUESTS)+1:03d}_{label}_attempt{attempt}'
        suffix='.xml' if accept=='application/xml' else '.json'
        rawpath=RAW/(stem+suffix); rawpath.write_bytes(data)
        receipt={'request_id':stem,'request_url':url,'method':'GET','started':ts,'finished':stamp(),'http_status':status,'headers':headers,'response_raw_file':str(rawpath),'response_bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'attempt':attempt,'error':error}
        REQUESTS.append(receipt)
        save('HTTP_Request_Receipts.json', REQUESTS)
        if error is None and status==200: return data, receipt
        ERRORS.append(receipt)
        if attempt==1: time.sleep(4)
    raise RuntimeError(f'{label}: both attempts failed; see receipts')

EHR=['electronic health record','electronic health records','electronic medical record','electronic medical records','EHR','EMR']
LOG=['access log','access logs','audit log','audit logs','audit trail','audit trails','user activity','access pattern','access patterns','access anomaly','record access']
THREAT=['anomal*','misuse','insider*','unauthori*','snoop*','detect*']
INSIDER=['insider threat','insider threats','inappropriate access','unauthorized access','unauthorised access','access monitoring','privacy breach','privacy breaches']
FED=['federated learning','federated','decentralized learning','decentralised learning']
SEC=['secure aggregation','SecAgg','SecAgg+','secure multiparty computation','secure multi-party computation','privacy preserving','privacy-preserving']
HEALTH=['healthcare','health care','hospital','hospitals','medical']+EHR
SECURITY=['security','intrusion','insider*','audit log','audit logs','access log','access logs','anomal*','misuse']

def group(terms, db):
    def one(t):
        if db=='pubmed': return f'"{t}"[Title/Abstract]' if ' ' in t or '+' in t else f'{t}[Title/Abstract]'
        return f'TITLE_ABS:"{t}"' if ' ' in t or '+' in t else f'TITLE_ABS:{t}'
    return '('+' OR '.join(one(t) for t in terms)+')'

def queries(db):
    ehr=group(EHR,db)
    if db=='pubmed': ehr='('+ehr+' OR "Electronic Health Records"[MeSH Terms])'
    log, threat, insider, fed, sec, health, security=[group(t,db) for t in (LOG,THREAT,INSIDER,FED,SEC,HEALTH,SECURITY)]
    bases={
      'S1':f'{ehr} AND (({log} AND {threat}) OR {insider})',
      'S2':f'{ehr} AND ({log} OR {insider}) AND {fed}',
      'S3':f'{health} AND {security} AND {fed} AND {sec}',
      'S4':f'{group(["secure aggregation","SecAgg","SecAgg+","secure multiparty computation","secure multi-party computation"],db)} AND {fed} AND {group(["anomal*","insider*","intrusion"],db)}',
    }
    out=[]
    for sid, base in bases.items():
        year='2000' if sid=='S1' else '2016'
        filters=f' AND english[Language] AND ("{year}/01/01"[Date - Publication] : "2026/10/11"[Date - Publication])' if db=='pubmed' else f' AND LANG:eng AND FIRST_PDATE:[{year}-01-01 TO 2026-10-11]'
        out.append({'database':db,'search_id':sid,'query_string':base+filters,'from_year':int(year),'cutoff':'2026-10-11','language':'English','query_scope':'title/abstract (plus EHR MeSH in PubMed only)'})
    return out

def add_record(record, db, sid):
    key=f'{db}:{record["source"]}:{record["source_id"]}'
    if key not in RECORDS: RECORDS[key]=dict(record, record_id=key, database=db, search_ids=[], access_level='BIBLIOGRAPHIC_METADATA_AND_ABSTRACT_ONLY', full_text_examined=False)
    if sid not in RECORDS[key]['search_ids']: RECORDS[key]['search_ids'].append(sid)

def text(node): return ''.join(node.itertext()).strip() if node is not None else ''

def parse_pubmed(data):
    root=ET.fromstring(data); out=[]
    for pa in root.findall('.//PubmedArticle'):
        mc=pa.find('MedlineCitation'); a=mc.find('Article'); pmid=text(mc.find('PMID'))
        ids={n.get('IdType'):text(n) for n in pa.findall('./PubmedData/ArticleIdList/ArticleId')}
        abstracts=[{'label':n.get('Label'),'text':text(n)} for n in a.findall('./Abstract/AbstractText')]
        pd=a.find('./Journal/JournalIssue/PubDate')
        authors=[]
        for au in a.findall('./AuthorList/Author'):
            authors.append(text(au.find('CollectiveName')) or ' '.join(filter(None,[text(au.find('ForeName')),text(au.find('LastName'))])))
        out.append({'source':'MED','source_id':pmid,'pmid':pmid,'pmcid':ids.get('pmc'),'doi':ids.get('doi'),'title':text(a.find('ArticleTitle')),'authors':authors,'journal':text(a.find('./Journal/Title')),'publication_date':text(pd),'publication_year':text(pd.find('Year')) if pd is not None else None,'article_dates':[{'type':n.get('DateType'),'date':text(n)} for n in a.findall('ArticleDate')],'languages':[text(n) for n in a.findall('Language')],'publication_types':[text(n) for n in a.findall('./PublicationTypeList/PublicationType')],'abstract_sections':abstracts,'abstract':'\n'.join((n['label']+': ' if n['label'] else '')+n['text'] for n in abstracts),'source_url':f'https://pubmed.ncbi.nlm.nih.gov/{pmid}/'})
    for pba in root.findall('.//PubmedBookArticle'):
        pmid=text(pba.find('./BookDocument/PMID'))
        out.append({'source':'MED','source_id':pmid,'pmid':pmid,'doi':None,'title':text(pba.find('./BookDocument/ArticleTitle')),'abstract':text(pba.find('./BookDocument/Abstract')),'source_url':f'https://pubmed.ncbi.nlm.nih.gov/{pmid}/','record_type':'PubmedBookArticle'})
    return out

def run_pubmed(query):
    params={'db':'pubmed','term':query['query_string'],'retmode':'json','retmax':9999,'sort':'pub_date','tool':'CodexLiteratureAudit'}
    url='https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?'+urllib.parse.urlencode(params)
    data,receipt=request(url,f'pubmed_{query["search_id"]}_esearch')
    obj=json.loads(data); result=obj.get('esearchresult',{}); count=int(result.get('count',0)); ids=result.get('idlist',[])
    query.update({'search_url':url,'platform_total_hits':count,'retrieved_id_count':len(ids),'unique_id_count':len(set(ids)),'retrieved_ids':ids,'query_translation':result.get('querytranslation'),'warning_list':result.get('warninglist'),'error_list':result.get('errorlist'),'raw_search_response':receipt['response_raw_file'],'search_response_sha256':receipt['sha256'],'request_started':receipt['started'],'search_id_retrieval_complete':len(set(ids))==count,'pagination':'retmax=9999; expected small domain corpus; >9999 flagged incomplete rather than silently truncated'})
    if count>9999: query['incomplete_reason']='PubMed ESearch limit; further partitioned retrieval required'
    allrecords=[]; fetchfiles=[]
    for start in range(0,len(ids),200):
        batch=ids[start:start+200]
        fetchurl='https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?'+urllib.parse.urlencode({'db':'pubmed','id':','.join(batch),'retmode':'xml','tool':'CodexLiteratureAudit'})
        data,receipt=request(fetchurl,f'pubmed_{query["search_id"]}_efetch_{start:05d}',accept='application/xml')
        fetchfiles.append(receipt['response_raw_file']); records=parse_pubmed(data); allrecords+=records
        for r in records: add_record(r,'pubmed',query['search_id'])
    received={r['source_id'] for r in allrecords}
    query.update({'metadata_response_files':fetchfiles,'metadata_record_count':len(allrecords),'metadata_unique_id_count':len(received),'missing_metadata_ids':sorted(set(ids)-received),'metadata_retrieval_complete':received==set(ids),'completeness':'COMPLETE_FOR_EXACT_EXECUTED_QUERY' if len(set(ids))==count and received==set(ids) else 'INCOMPLETE'})
    return query

def run_epmc(query):
    cursor='*'; results=[]; files=[]; total=None; cursorseen=set(); page=0
    while cursor and cursor not in cursorseen:
        cursorseen.add(cursor); page+=1
        params={'query':query['query_string'],'format':'json','resultType':'core','pageSize':1000,'cursorMark':cursor}
        url='https://www.ebi.ac.uk/europepmc/webservices/rest/search?'+urllib.parse.urlencode(params)
        data,receipt=request(url,f'epmc_{query["search_id"]}_page{page:03d}')
        obj=json.loads(data); batch=obj.get('resultList',{}).get('result',[]); total=int(obj.get('hitCount',0)) if total is None else total
        files.append(receipt['response_raw_file']); results+=batch
        if page==1: query.update({'search_url':url,'request_started':receipt['started'],'query_string_returned':obj.get('request',{}).get('queryString')})
        if len(results)>=total or not batch: break
        cursor=obj.get('nextCursorMark')
    keys=[]
    for r in results:
        source=r.get('source','UNKNOWN'); rid=str(r.get('id','')); keys.append(source+':'+rid)
        authors=r.get('authorList',{}).get('author',[])
        record={'source':source,'source_id':rid,'pmid':r.get('pmid'),'pmcid':r.get('pmcid'),'doi':r.get('doi'),'title':r.get('title'),'authors':[a.get('fullName') or a.get('lastName') or a.get('collectiveName') for a in authors],'journal':r.get('journalInfo',{}).get('journal',{}).get('title'),'publication_date':r.get('firstPublicationDate'),'publication_year':r.get('pubYear'),'languages':[r.get('language')] if r.get('language') else [],'publication_types':r.get('pubTypeList',{}).get('pubType',[]),'abstract':r.get('abstractText'),'is_open_access':r.get('isOpenAccess'),'full_text_url_list':r.get('fullTextUrlList'),'source_url':f'https://europepmc.org/article/{source}/{rid}'}
        add_record(record,'europe_pmc',query['search_id'])
    query.update({'platform_total_hits':total,'returned_record_count':len(results),'unique_id_count':len(set(keys)),'retrieved_ids':keys,'raw_response_files':files,'pages_retrieved':page,'pagination':'cursorMark, pageSize=1000, resultType=core (metadata plus abstracts where supplied)','metadata_retrieval_complete':len(set(keys))==total,'completeness':'COMPLETE_FOR_EXACT_EXECUTED_QUERY' if len(set(keys))==total else 'INCOMPLETE','duplicate_records_within_query':len(results)-len(set(keys))})
    return query

def main():
    plan(100,0)
    definitions=queries('pubmed')+queries('europe_pmc')
    save('Frozen_API_Query_Definitions.json',{'created':stamp(),'parent_protocol':str(ROOT.parent/'Search_Protocol.json'),'queries':definitions,'scope_note':'New searches only; no authentication of August historical searches; no global-first certification. EPMC core abstracts are metadata, not source-level full-text verification.'})
    plan(1,1)
    for i,q in enumerate(definitions):
        try:
            result=run_pubmed(q) if q['database']=='pubmed' else run_epmc(q)
            print(f'{q["database"]} {q["search_id"]}: hits={result.get("platform_total_hits")} metadata={result.get("metadata_record_count",result.get("returned_record_count"))} {result.get("completeness")}',flush=True)
        except Exception as exc:
            result=dict(q,error=f'{type(exc).__name__}: {exc}',completeness='FAILED_OR_INCOMPLETE')
            print(f'{q["database"]} {q["search_id"]}: {result["error"]}',flush=True)
        QUERIES.append(result)
        save('Search_Result_Manifest.json', {'updated':stamp(),'queries':QUERIES,'errors':ERRORS,'historical_counts_authenticated':False,'full_text_verified':False})
        save('Normalized_Records.json',list(RECORDS.values()))
        plan(min(99,int((i+1)/len(definitions)*100)),1)
    plan(10,2)
    fields=['record_id','database','source','source_id','pmid','pmcid','doi','title','publication_year','publication_date','journal','authors','search_ids','abstract','source_url','access_level','full_text_examined']
    with (ROOT/'Normalized_Records.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader()
        for record in RECORDS.values():
            row=dict(record)
            for k,v in row.items():
                if isinstance(v,list):row[k]=' | '.join(str(x) for x in v)
            w.writerow(row)
    final={'finished':stamp(),'unique_database_records':len(RECORDS),'database_counts':{db:sum(r['database']==db for r in RECORDS.values()) for db in ['pubmed','europe_pmc']},'raw_http_requests':len(REQUESTS),'http_errors_logged':len(ERRORS),'queries_complete':sum(q.get('completeness')=='COMPLETE_FOR_EXACT_EXECUTED_QUERY' for q in QUERIES),'queries_failed_or_incomplete':sum(q.get('completeness')!='COMPLETE_FOR_EXACT_EXECUTED_QUERY' for q in QUERIES),'all_ids_have_bibliographic_records':all(q.get('completeness')=='COMPLETE_FOR_EXACT_EXECUTED_QUERY' for q in QUERIES),'cross_database_deduplication_performed':False,'screening_performed':False,'historical_counts_authenticated':False,'full_text_verified':False,'limitations':['Newly returned public-API counts differ in surface, date and syntax from August institutional searches.','The defined query scope may miss records with relevant concepts absent from indexed title/abstract; web and citation chaining supplement it.','Search-hit completeness means all records of the exact executed query were preserved, not that the topic literature is exhaustive.']}
    save('API_Execution_QA.json',final)
    plan(100,3)
    print(json.dumps(final,ensure_ascii=False),flush=True)

if __name__=='__main__': main()
