"""Join record-by-record reviewer decisions; no automatic relevance classification."""
from pathlib import Path
import json,csv,collections,hashlib
from datetime import datetime,timezone,timedelta
ROOT=Path(__file__).resolve().parent
canonical=json.loads((ROOT/'Canonical_Union_To_Screen.json').read_text(encoding='utf-8'))
byindex={r['screening_index']:r for r in canonical}
with (ROOT/'Screening_Part_1_141.tsv').open(encoding='utf-8',newline='') as f: part1=list(csv.DictReader(f,delimiter='\t'))
classes={'RETAIN_DIRECT':'Direct EHR staff-access/audit anomaly or inappropriate-access detection','RETAIN_TRANSFERABLE':'Transferable original federated cybersecurity/privacy evaluation','BACKGROUND':'Contextual, methodological or secondary background','EXCLUDE':'Outside the protocol research/evaluation scope','UNCERTAIN':'Potential direct challenge unresolved by title/available abstract'}
relations={'RETAIN_DIRECT':'Addresses the direct EHR-access problem; the reviewed abstract does not establish equivalence to the specific matched Flower FedAvg/SecAgg+ detection-and-cost experiment. Full-text comparison remains necessary.','RETAIN_TRANSFERABLE':'Potentially challenges broad novelty claims about protected/private federated security learning; task/mechanism and matched utility-cost comparability require full-text assessment. Not direct EHR staff-access validation.','BACKGROUND':'Context, validity, implementation or privacy-cost background only; not treated as an independently equivalent experiment.','EXCLUDE':'Not a candidate equivalent to the protocol contribution for the specific reason recorded. Exclusion does not assert that the publication is scientifically invalid.','UNCERTAIN':'Plausible access/security candidate; absence of resolving details is not evidence of irrelevance or absence of equivalent work.'}
normalized1=[]
for x in part1:
    r=byindex[int(x['screening_index'])]; hasabstract=bool(r.get('abstract'))
    normalized1.append({'screening_index':r['screening_index'],'stable_source_id':r['stable_source_id'],'record_id':r['record_id'],'title':r['title'],'decision':x['decision'],'reason':x['reason'],'relevance_class':classes[x['decision']],'relation_to_specific_novelty_claim':relations[x['decision']],'title_abstract_inspected':True,'title_inspected':True,'available_abstract_inspected':hasabstract,'read_scope':'TITLE_AND_AVAILABLE_ABSTRACT' if hasabstract else 'TITLE_ONLY_NO_ABSTRACT_SUPPLIED','fulltext_read':False,'full_text_examined':False,'screening_reviewer':'Codex /root/refresh_pubmed_epmc','screening_method':'Record-by-record title and complete available abstract reading; not keyword-only final classification.'})
(ROOT/'Screening_Part_1_141.json').write_text(json.dumps(normalized1,ensure_ascii=False,indent=2),encoding='utf-8')
other=ROOT/'Screening_Part_142_281.json'
if not other.exists():
    print(json.dumps({'status':'PART1_READY_WAITING_PART2','part1_records':len(normalized1),'part1_decisions':dict(collections.Counter(r['decision'] for r in normalized1))}));raise SystemExit(0)
part2=json.loads(other.read_text(encoding='utf-8'))
if isinstance(part2,dict):part2=part2.get('records') or part2.get('screening_records') or part2.get('decisions') or part2.get('candidates')
allparts=normalized1+part2
screened={}
for decision in allparts:
    decision=dict(decision)
    if decision['decision'] in ['TRANSFERABLE','DIRECT']:
        decision['decision_as_supplied']=decision['decision']
        decision['decision']='RETAIN_'+decision['decision']
    idx=int(decision['screening_index']);r=dict(byindex[idx]);r.update(decision)
    r['screening_index']=idx;r['stable_source_id']=byindex[idx]['stable_source_id']
    r['source']=byindex[idx]['source'];r['source_id']=byindex[idx]['source_id'];r['record_id']=byindex[idx]['record_id']
    r['decision']=decision['decision'];r['reason']=decision['reason']
    r.setdefault('relevance_class',classes[r['decision']]);r.setdefault('relation_to_specific_novelty_claim',relations[r['decision']])
    r.setdefault('title_abstract_inspected',True);r.setdefault('title_inspected',True);r.setdefault('available_abstract_inspected',bool(r.get('abstract')))
    r.setdefault('read_scope','TITLE_AND_AVAILABLE_ABSTRACT' if r.get('abstract') else 'TITLE_ONLY_NO_ABSTRACT_SUPPLIED')
    r['fulltext_read']=False;r['full_text_examined']=False
    if idx in screened:raise ValueError(f'duplicate decision index {idx}')
    screened[idx]=r
out=[screened[idx] for idx in sorted(screened)]
counts=dict(collections.Counter(r['decision'] for r in out))
checks=[{'check':'expected281','pass':len(out)==281,'actual':len(out)}, {'check':'exact_index_set','pass':set(screened)==set(range(1,282))}, {'check':'exact_stable_source_ids','pass':{r['stable_source_id'] for r in out}=={r['stable_source_id'] for r in canonical}}, {'check':'all_decisions_in_allowed_set','pass':all(r['decision'] in classes for r in out)}, {'check':'every_record_specific_reason','pass':all(len(r['reason'])>30 for r in out)}, {'check':'all_provenance_preserved','pass':all(r.get('database_provenance')==byindex[r['screening_index']]['database_provenance'] for r in out)}, {'check':'all_available_abstracts_attested','pass':all(r.get('title_abstract_inspected') and r.get('available_abstract_inspected') for r in out if r.get('abstract'))}, {'check':'no_fulltext_inflation','pass':all(r['fulltext_read'] is False and r['full_text_examined'] is False for r in out)}, {'check':'decision_sum_reconciles','pass':sum(counts.values())==281}, {'check':'record_to_source_id_match','pass':all(r['stable_source_id']==byindex[r['screening_index']]['stable_source_id'] for r in out)}]
qa={'status':'PASS' if all(c['pass'] for c in checks) else 'FAIL','updated':datetime.now(timezone.utc).astimezone(timezone(timedelta(hours=8))).isoformat(),'checks':checks,'canonical_source_ids':len(canonical),'screened_source_ids':len(out),'decision_counts':counts,'missing_indices':sorted(set(range(1,282))-set(screened)),'abstract_unavailable_indices':[r['screening_index'] for r in out if not r.get('abstract')],'fulltexts_read_in_this_screening':0,'dual_independent_screening_performed':False,'screening_scope':'AI-assisted record-by-record title/available-abstract screening, split into disjoint candidate ranges; not human dual screening or paper full-text verification.','coverage_boundary':'All281 stable-source-ID API candidates screened. DOI/title publication-version deduplication is a further step; stable-source-ID union is not final unique-study count.'}
(ROOT/'Screening_Union.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
(ROOT/'Screening_Count_Reconciliation_QA.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2),encoding='utf-8')
fields=['screening_index','stable_source_id','record_id','title','doi','publication_year','publication_date','all_search_ids','database_provenance','decision','reason','relevance_class','relation_to_specific_novelty_claim','read_scope','title_abstract_inspected','available_abstract_inspected','fulltext_read','source_url']
with (ROOT/'Screening_Union.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader()
    for r in out:
        row={k:(json.dumps(r.get(k),ensure_ascii=False) if isinstance(r.get(k),(list,dict)) else r.get(k)) for k in fields};w.writerow(row)
lines=['# Public API candidate title/abstract screening','', 'All281 stable-source-ID candidates were inspected record by record against the frozen protocol. Decisions use titles and complete abstracts available in the preserved APIs; all fulltext_read values remain false for this screening. This is AI-assisted screening by Codex, not two independent human reviewers or source-level scientific verification.','', '| Decision | Count |','|---|---:|']
for k in classes:lines.append(f'| {k} | {counts.get(k,0)} |')
lines += ['',f'Count-reconciliation QA: **{qa["status"]}**. All IDs/decisions and database/query provenance are in Screening_Union.json/.csv. Candidates64 and96 have no available abstract and are labelled title-only. Candidate265 has an explicitly provider-truncated abstract; only the available text was inspected.', '', 'BACKGROUND retains contextual, secondary or methodological sources separately from original comparable experiments. RETAIN_DIRECT and RETAIN_TRANSFERABLE mean proceed to full-text/cross-study comparison; they do not mean the abstract proves the thesis contribution has already been duplicated. UNCERTAIN means plausible relevance unresolved; source unavailability is not used to establish novelty.','', '## Direct, transferable and uncertain candidates','', '| Index | Decision | Study | DOI / source | Reason |','|---|---|---|---|---|']
for r in out:
    if r['decision'] in ['RETAIN_DIRECT','RETAIN_TRANSFERABLE','UNCERTAIN']:
        lines.append(f'| {r["screening_index"]} | {r["decision"]} | {r["title"].replace("|","/")} | {r.get("doi") or r["source_url"]} | {r["reason"].replace("|","/")} |')
lines += ['', '## Deduplication and inherited coverage limits','', '- Source-ID canonicalisation merges identical MED IDs across PubMed and Europe PMC while retaining all database/query provenance. Separate source IDs sharing DOI/title still require duplicate/version review before reporting included studies.', '- Candidates28/38 have the same clinical-decision-support title/abstract and are both out of scope; candidate105/107 are related SNAD publications and104/111 related CADS publications. Do not count related publications as independent experimental replications without checking versions.', '- Iqbal VAE (candidate5) is already represented in the thesis. RETAIN_DIRECT does not describe it as a newly discovered omission.', '- The single ETH dissertation is Ng2019; it does not reintroduce the user-excluded Abbasi master thesis.', '- New-search screening does not reconstruct August screening decisions, missing exports, or historical counts.', '- Manuscript unchanged; no source numerical claim was verified from full text by this screening alone.','']
(ROOT/'Screening_Union_Report.md').write_text('\n'.join(lines),encoding='utf-8')
plan={'native_plan_tool_available':False,'steps':[{'step':'[100%] Build canonical union with preserved database and query provenance','status':'completed'},{'step':'[100%] Manually inspect titles and all available abstracts for assigned candidates 1–141','status':'completed'},{'step':'[100%] Merge all281 decisions and reconcile screening counts','status':'completed'}]}
(ROOT/'Screening_Progress_Plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'status':qa['status'],'records':len(out),'decision_counts':counts,'abstract_unavailable_indices':qa['abstract_unavailable_indices']},ensure_ascii=False))
