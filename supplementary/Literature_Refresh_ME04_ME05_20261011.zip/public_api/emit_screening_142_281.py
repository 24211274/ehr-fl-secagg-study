import json
import hashlib
from collections import Counter
from pathlib import Path

base = Path(__file__).resolve().parent
canonical_path = base / 'Canonical_Union_To_Screen.json'
decision_path = base / 'Manual_Decisions_142_281.json'
canonical = json.loads(canonical_path.read_text(encoding='utf-8-sig'))
manual = json.loads(decision_path.read_text(encoding='utf-8-sig'))
assert set(map(int, manual)) == set(range(142, 282))
relations = {
    'TRANSFERABLE': 'Retained as original indirect anomaly/security evidence that may challenge broad novelty; it does not establish equivalence to the bounded EHR staff-session FedAvg versus SecAgg+ utility/cost study. Exact cryptographic implementation and controlled arms require full-text verification.',
    'BACKGROUND': 'Retained for context, mechanisms, evaluation design or threats. Title and abstract do not establish an equivalent bounded staff-access FedAvg versus SecAgg+ experiment; no absence of such experiments is inferred for the unread full text.',
    'EXCLUDE': 'Excluded from the bounded access-anomaly/aggregation comparison evidence set for the specific scope reason given. This is an abstract-level relevance decision, not a judgment of quality or proof of full-text absence.',
    'UNCERTAIN': 'Retained pending full-text screening because the abstract cannot resolve the detection target, cryptographic aggregation semantics, executed experiments or comparable controls. It must not be counted as proof of either novelty or equivalence.'
}
records = []
for original in canonical:
    index = original['screening_index']
    if not 142 <= index <= 281:
        continue
    decision, relevance, reason = manual[str(index)]
    abstract = original.get('abstract') or ''
    item = {
        'screening_index': index,
        'record_id': original['record_id'],
        'stable_source_id': original['stable_source_id'],
        'source_id': original['stable_source_id'],
        'title': original['title'],
        'doi': original.get('doi'),
        'source_url': original.get('source_url'),
        'decision': decision,
        'reason': reason,
        'relevance_class': relevance,
        'relation_to_specific_novelty_claim': relations[decision],
        'title_abstract_inspected': True,
        'read_scope': 'TITLE_AND_COMPLETE_AVAILABLE_ABSTRACT' if abstract.strip() else 'TITLE_ONLY_NO_ABSTRACT_AVAILABLE',
        'fulltext_read': False,
        'screening_basis': 'AI-assisted per-record title/abstract assessment; each complete available abstract inspected and decisions authored individually in Manual_Decisions_142_281.json. Codex agents are not independent human reviewers.',
        'abstract_completeness_note': 'Available abstract is explicitly truncated at source; only available text inspected.' if index == 265 else 'Complete available API abstract inspected; full source not read.',
        'abstract_sha256': hashlib.sha256(abstract.encode('utf-8')).hexdigest(),
        'screened_date_local': '2026-10-11',
        'screener': 'refresh_challengers'
    }
    if index == 252:
        item['possible_version_duplicate_of_screening_index'] = 251
        item['duplicate_adjudication_note'] = 'Same study numbers and abstract; stable IDs retained for root/API agent identity verification before study-level counting.'
    records.append(item)
counts = dict(Counter(r['decision'] for r in records))
output = {
    'screening_range': [142, 281],
    'record_count': len(records),
    'screening_unit': 'canonical bibliographic record, not necessarily unique underlying study',
    'read_scope': 'Titles and complete available abstracts only; none of these 140 records was newly full-text verified in this screening pass.',
    'date_local': '2026-10-11',
    'timezone': 'Asia/Singapore',
    'manual_decisions_source': 'Manual_Decisions_142_281.json',
    'counts': counts,
    'records': records
}
(base / 'Screening_Part_142_281.json').write_text(json.dumps(output, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
checks = {
    'count_140': len(records) == 140,
    'exact_index_range_no_holes': [r['screening_index'] for r in records] == list(range(142, 282)),
    'unique_record_ids': len({r['record_id'] for r in records}) == 140,
    'all_individual_decisions_have_reason': all(r['reason'].strip() for r in records),
    'all_available_abstracts_inspected': all(r['title_abstract_inspected'] for r in records),
    'no_false_fulltext_claim': all(not r['fulltext_read'] for r in records),
    'allowed_decisions_only': set(counts).issubset(relations),
    'canonical_record_id_alignment': all(r['record_id'] == canonical[r['screening_index'] - 1]['record_id'] for r in records)
}
assert all(checks.values()), checks
qa = {
    'status': 'PASS',
    'checks': checks,
    'counts': counts,
    'limitations': ['Not a full-source audit.', 'Positive abstract claims are author-reported and not independently replicated.', 'Index 265 available source abstract is truncated.', 'Indices 251/252 require study/version duplicate adjudication.'],
    'canonical_file_sha256': hashlib.sha256(canonical_path.read_bytes()).hexdigest(),
    'manual_decision_file_sha256': hashlib.sha256(decision_path.read_bytes()).hexdigest()
}
(base / 'Screening_Part_142_281_QA.json').write_text(json.dumps(qa, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'status': qa['status'], 'record_count': len(records), 'counts': counts}))
