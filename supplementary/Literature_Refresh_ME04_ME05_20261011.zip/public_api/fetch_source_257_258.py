from pathlib import Path
from datetime import datetime,timezone,timedelta
import urllib.request,urllib.error,json,hashlib,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parent/'source_assessments';ROOT.mkdir(exist_ok=True)
receipts=[]
for pmcid in ['PMC13568194','PMC13493948']:
    url=f'https://www.ebi.ac.uk/europepmc/webservices/rest/{pmcid}/fullTextXML'
    now=datetime.now(timezone.utc);status=None;data=b'';err=None;headers={}
    try:
        with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Codex-Literature-Audit/1.0','Accept':'application/xml'}),timeout=60) as r:
            status=r.status;headers=dict(r.headers.items());data=r.read()
    except urllib.error.HTTPError as e:status=e.code;data=e.read();err=str(e)
    except Exception as e:err=f'{type(e).__name__}: {e}'
    path=ROOT/(pmcid+'_fullText.xml');path.write_bytes(data)
    receipts.append({'pmcid':pmcid,'url':url,'started_utc':now.isoformat(),'started_asia_singapore':now.astimezone(timezone(timedelta(hours=8))).isoformat(),'http_status':status,'headers':headers,'error':err,'response_bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'raw_file':str(path)})
    if err is None and status==200:
        x=ET.fromstring(data)
        def txt(n):return ' '.join(''.join(n.itertext()).split()) if n is not None else ''
        secs=[]
        for i,s in enumerate(x.findall('./body/sec'),1):secs.append({'top_section_index':i,'id':s.get('id'),'title':txt(s.find('title')),'text':txt(s)})
        tables=[{'id':t.get('id'),'label':txt(t.find('label')),'caption':txt(t.find('caption')),'text':txt(t)} for t in x.findall('.//table-wrap')]
        figs=[{'id':t.get('id'),'label':txt(t.find('label')),'caption':txt(t.find('caption'))} for t in x.findall('.//fig')]
        obj={'pmcid':pmcid,'title':txt(x.find('./front/article-meta/title-group/article-title')),'sections':secs,'tables':tables,'figures_captions_only':figs,'metadata_front':txt(x.find('./front')),'back_matter':txt(x.find('./back')),'extract_scope':'XML extraction, top-level section text + all table text and figure captions; no graphical figure pixels inspected.'}
        (ROOT/(pmcid+'_sections.json')).write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
        print(json.dumps({'pmcid':pmcid,'http':status,'bytes':len(data),'sections':[{'index':s['top_section_index'],'title':s['title'],'words':len(s['text'].split())} for s in secs],'tables':len(tables),'figures':len(figs)},ensure_ascii=False))
    else:print(json.dumps(receipts[-1],ensure_ascii=False))
(ROOT/'FullText_HTTP_Receipts.json').write_text(json.dumps(receipts,ensure_ascii=False,indent=2),encoding='utf-8')
