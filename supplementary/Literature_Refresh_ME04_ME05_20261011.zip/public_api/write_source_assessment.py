"""Assemble explicitly bounded, source-text-supported assessments of candidates 257/258.

The judgments below were made by reading the available XML narrative and table text,
not by executing a keyword classifier. This script packages those judgments and checks
selected transcribed cells plus the integrity of the preserved raw responses.
"""
import datetime
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

BASE = Path(__file__).resolve().parent
SRC = BASE / "source_assessments"
receipts = json.loads((SRC / "FullText_HTTP_Receipts.json").read_text(encoding="utf-8"))
receipt = {r["pmcid"]: r for r in receipts}
now = datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat()

def evidence(pmcid):
    r = receipt[pmcid]
    return {k: r[k] for k in ["url", "started_utc", "started_asia_singapore", "http_status", "response_bytes", "sha256", "raw_file"]}

def finding(locator, finding, epistemic_status="SOURCE_REPORTED; NOT INDEPENDENTLY REPRODUCED"):
    return {"locator": locator, "finding": finding, "epistemic_status": epistemic_status}

assessment = {
    "updated_asia_singapore": now,
    "purpose": "Bounded follow-up to ME-04/ME-05: examine two strong transferable novelty challengers beyond their abstracts.",
    "cutoff_date": "2026-10-11",
    "assessment_method": "AI-assisted reading and appraisal of specified original full-text XML narrative sections and table text by a Codex agent. This is not independent human dual screening, experimental replication, a formal cryptographic proof audit, or an exhaustive source-coverage audit.",
    "screening_stage_flags": "The 281-record title/abstract Screening_Union remains fulltext_read=false. This separate artifact records subsequent PARTIAL_SOURCE_TEXT reading for these two records only; do not describe either source as fully audited.",
    "global_limits": [
        "Raw complete publisher-supplied XML was obtained, but only the listed scientific sections/table text were examined. Availability of full XML is not equivalent to a complete-source audit.",
        "No figure pixel values, rendered plots, supplementary datasets, implementation code, model checkpoints, or reproduced experiments were examined.",
        "Inline formulas and some numerical table cells use image/alternative markup that is lost in flattened XML text. No formal differential-privacy proof, RDP-accounting calculation, CKKS security/noise bound, or complete equation transcription was validated.",
        "Statements about experiments/results below are source-reported observations. The reviewer's judgments about relevance, comparability, and novelty are explicitly inferences.",
        "Neither source directly studies staff EHR access-session anomalies on the thesis benchmark. Neither justifies claiming the EHR study is globally first or that all possible challengers have been excluded."
    ],
    "sources": []
}

assessment["sources"].append({
    "screening_index": 257,
    "pmcid": "PMC13568194",
    "pmid": "42739958",
    "title": "An Explainable Federated Intrusion Detection Framework for SDN Using Distributed Key Generation and Threshold Homomorphic Encryption",
    "authors": ["S M Shamim", "Yuta Kodera", "Md Arshad Ali", "Yasuyuki Nogami"],
    "doi": "10.3390/s26175337",
    "publication_date_in_source_front": "2026-08-23",
    "reader_url": "https://europepmc.org/articles/PMC13568194",
    "publisher_url": "https://www.mdpi.com/1424-8220/26/17/5337",
    "raw_response_evidence": evidence("PMC13568194"),
    "source_availability": "FULL_TEXT_XML_AVAILABLE",
    "scientific_read_scope": "PARTIAL_SOURCE_TEXT",
    "read_sections": [
        "Section 3, System Architecture and Threat Model, including 3.3.4",
        "Section 4, Proposed Methodology, all subsections 4.1-4.5",
        "Section 5, Experimental Setup, all subsections 5.1-5.6",
        "Section 6.1.1, Quantitative Detection Performance",
        "Section 6.2, Cryptographic Performance Analysis, all subsections 6.2.1-6.2.5",
        "Section 6.5, Detection-Performance Comparison with Existing Federated SDN-IDS Frameworks",
        "Section 7, Discussion, including 7.5 Limitations",
        "Section 8, Conclusion",
        "All source Table 1-11 textual cells and the abbreviations array",
        "Reference 13 bibliographic entry only; the cited original study was not itself read"
    ],
    "not_examined": ["Entire introduction and related work", "Section 6.1.2-6.1.3 as complete sections", "Section 6.3 SHAP and Section 6.4 deployment results as complete sections", "Figure pixels", "Author implementation and supplementary files", "Original full text of reference 13"],
    "study_type_and_scope": finding("Sections 3-5", "Experimental federated SDN network-flow binary intrusion detection with GRU and threshold homomorphic encryption; transferable cybersecurity methodology, not direct staff EHR access-session detection."),
    "dataset_and_implementation": [
        finding("Sections 5.1-5.3; Tables 3-5", "InSDN, CICDDoS2017, CICDDoS2019 (names as printed in the source); 70/30 train/test split; configurations of 4, 8 and 12 clients; GRU hidden layers 256/128/64, Adam, binary cross-entropy, learning rate 0.0001, dropout 0.3, 15 FL rounds, 5 local epochs."),
        finding("Sections 4.1-4.4, 5.3; Table 5", "OpenFHE CKKS with ring dimension 8192, batch packing 4096, depth 2, scaling precision 40 bits, author-claimed 128-bit security. Native initialization requires all n clients; custom Shamir-share/C++/Pybind collaborative decryption enables (t,n)=(3,4),(5,8),(7,12). This implementation/security claim was not verified by code."),
        finding("Section 5.1", "Source environment: Intel i9, RTX-series GPU, 32 GB RAM, Ubuntu 22.04, Python 3.10.12, TensorFlow/Keras 2.13/2.13.1.")
    ],
    "comparison_design": [
        finding("Section 6.2.5; Table 7 (sensors-26-05337-t007)", "Controlled comparison between TWO ENCRYPTED implementations: previous TenSEAL single-key/centralized-dealer framework and proposed OpenFHE dealerless DKG/custom threshold framework. The source states the same GRU/model-update dimensions, ring 8192, packing 4096, effective depth/scaling precision, client configuration, rounds and hardware were used."),
        finding("Sections 5.2, 6.2.5", "The compared cryptographic libraries, key-custody/decryption models, ciphertext handling and serialization differ. OpenFHE per-chunk/per-client serialization and collaborative decryption contribute overhead; changes cannot be attributed exclusively to one security component.", "REVIEWER INFERENCE FROM THE SOURCE'S DESIGN AND EXPLANATION"),
        finding("Section 6.5; Table 11", "Literature performance values were taken from prior publications rather than a controlled head-to-head rerun. The source explicitly notes differing datasets, tasks, preprocessing, models, clients and hardware."),
        finding("Sections reviewed above", "An isolated plaintext FedAvg versus SecAgg+ arm is not established in these reviewed sections. This is an absence within the declared read scope, not an exhaustive proof that no such artifact exists elsewhere.", "BOUNDED SOURCE-TEXT OBSERVATION")
    ],
    "key_results": [
        {"locator": "Section 6.2.5; Table 7", "configuration": "12-client InSDN", "unit": "seconds", "metric": "Encryption latency", "previous_TenSEAL": 170.16, "proposed_OpenFHE": 56.88},
        {"locator": "Section 6.2.5; Table 7", "configuration": "12-client InSDN", "unit": "seconds", "metric": "Aggregation latency", "previous_TenSEAL": 25.07, "proposed_OpenFHE": 97.71},
        {"locator": "Section 6.2.5; Table 7", "configuration": "12-client InSDN", "unit": "seconds", "metric": "Decryption latency", "previous_TenSEAL": 3.11, "proposed_OpenFHE": 88.99},
        {"locator": "Section 6.2.5; Table 7", "configuration": "12-client InSDN", "unit": "MB", "metric": "Communication overhead", "previous_TenSEAL": 9615.67, "proposed_OpenFHE": 14093.67},
        {"locator": "Section 6.1.1; Table 6", "metric_unit": "percent", "dataset": "InSDN", "accuracy": 99.95, "precision": 99.92, "recall": 99.98, "F1": 99.95},
        {"locator": "Section 6.1.1; Table 6", "metric_unit": "percent", "dataset": "CICDDoS2017", "accuracy": 99.03, "precision": 99.00, "recall": 99.07, "F1": 99.03},
        {"locator": "Section 6.1.1; Table 6", "metric_unit": "percent", "dataset": "CICDDoS2019", "accuracy": 99.65, "precision": 99.47, "recall": 99.91, "F1": 99.69}
    ],
    "results_interpretation_limits": [
        "Encryption is faster in the proposed framework, while aggregation, decryption and communication are worse in the reported Table 7 configuration. Do not report only the favorable latency.",
        "The study reports one run per configuration (Section 7.5); the reported point estimates do not provide multi-seed uncertainty.",
        "The reviewed comparison does not establish exact compatibility of Table 7's cost normalization with thesis whole-workflow/application-message-content costs. Do not compare raw MB/seconds across the two studies without definitions and normalization.",
        "High detection metrics in Table 6 do not by themselves quantify a paired privacy-on versus privacy-off utility difference."
    ],
    "privacy_and_other_limitations": [
        finding("Sections 3.3.4, 4.4, 7.5", "Clients are assumed to perform collaborative decryption only for authorized aggregate ciphertexts. Arbitrary/repeated malicious-coordinator decryption requests and decryption-oracle misuse are not prevented by the implemented request-authorization mechanism; the authors acknowledge authorization/validation is future work."),
        finding("Section 7.5", "Trusted SDN controller; static participation; binary task; up to 12 clients; single run per configuration; no comprehensive adaptive poisoning/malicious-client study; no formal CKKS noise/convergence analysis; no analyst user study. Dynamic participation, highly non-IID/multiclass evaluation and multi-seed assessment remain limitations/future work.")
    ],
    "bounded_novelty_implication": {
        "classification": "RETAIN_TRANSFERABLE; STRONG CHALLENGER TO BROAD NOVELTY",
        "inference": "This source demonstrates prior secure federated intrusion detection with explicitly controlled cryptographic implementation comparison and utility/latency/communication reporting. A broad claim that no previous private FL anomaly/intrusion work measures these trade-offs is untenable. Its SDN GRU/threshold-HE setting and two-encrypted-arm comparison do not reproduce the thesis matched EHR-session LSTM-AE Flower FedAvg versus SecAgg+ five-seed experiment.",
        "required_manuscript_action": "Add this 2026 source to the transferable evidence matrix and narrow the contribution to the explicitly controlled EHR-session benchmark and implemented SecAgg+ protocol/cost definitions. State differences in task, dataset, protection, arm design and repetition. Avoid generic first/novel private-FL-with-cost language."
    },
    "citation_chain_candidate_not_yet_read": {"reference": "13", "title": "A Secure and Privacy-Preserving Federated Learning-Based Intrusion Detection System for SDN Networks Using Homomorphic Encryption", "doi": "10.1109/access.2026.3691160", "reported_bibliographic_details": "IEEE Access 2026;14:69548-69577", "status": "BIBLIOGRAPHIC_ENTRY_ONLY; ORIGINAL_FULL_TEXT_NOT_EXAMINED"}
})

assessment["sources"].append({
    "screening_index": 258,
    "pmcid": "PMC13493948",
    "pmid": "42624916",
    "title": "APEW-Fed: adaptive privacy-aware ensemble weighting for federated anomaly detection in enterprise resource planning systems",
    "authors": ["Adiah Qazi", "Ammad Ali Khan Jadoon", "Sadiqa Arshad"],
    "doi": "10.1038/s41598-026-60574-y",
    "publication_date_in_source_front": "2026-08-20",
    "reader_url": "https://europepmc.org/articles/PMC13493948",
    "publisher_url": "https://www.nature.com/articles/s41598-026-60574-y",
    "raw_response_evidence": evidence("PMC13493948"),
    "source_availability": "FULL_TEXT_XML_AVAILABLE",
    "scientific_read_scope": "PARTIAL_SOURCE_TEXT_WITH_FORMULA_EXTRACTION_LIMITS",
    "read_sections": [
        "System architecture and methodology, XML Sec12 (subsections Sec13-Sec29), available narrative including separately reread Remark 4 and Remark 5",
        "Privacy analysis, XML Sec30-Sec33, including secure aggregation Sec33",
        "Experimental setup, XML Sec34-Sec37",
        "Results and analysis, XML Sec38-Sec58",
        "Discussion, XML Sec59-Sec63, including limitations Sec62",
        "Conclusion, XML Sec64",
        "Table text within these sections, with explicitly inspected rows for Tables 6,7,15,16,17,18,19,20,21,22"
    ],
    "not_examined": ["Complete introduction/related work and cited original papers", "Rendered formulas and mathematical proofs", "Figure pixels", "Numeric cells represented only by embedded math images", "Author code, supplementary raw data and reproduced experiments"],
    "study_type_and_scope": finding("System architecture/methodology, XML Sec12; Dataset, Sec35", "Privacy-aware federated ensemble anomaly detection of ERP transactions across enterprise units, not hospital staff EHR access-session detection. Access violations are one annotated ERP anomaly subtype, which does not make this an EHR access study."),
    "data_and_labels": [
        finding("Dataset, XML Sec35", "243531 original transactions with 281 attributes, January 2023-December 2024; 47 features after preprocessing; 50000-record subsample with 80/20 train/test split."),
        finding("Dataset, XML Sec35; Tables 8-9 for sampling/subtype evaluation", "5000 expert-annotated records: 612 anomalies and 4388 normal; two experts (kappa 0.87), third adjudicator. Sampling combines 2500 uniform records and 2500 records enriched above the 80th percentile of an ensemble score. IPW correction and uniform-only analyses are reported; this is not a simple uniformly sampled ground-truth benchmark."),
        finding("Dataset, XML Sec35", "Anomaly subtypes: financial irregularity 218, access violation 187, behavioral anomaly 142, policy violation 65 (sum 612).")
    ],
    "method_and_implementation": [
        finding("System architecture/methodology, Sec12-Sec29", "Four detectors: local isolation forest, local DBSCAN, local gradient boosting using isolation-forest pseudo-labels, and a federated autoencoder. Only the autoencoder is trained by federated DP-SGD; the whole four-detector ensemble is not federated as four trainable networks."),
        finding("Methodology and Privacy analysis, Sec12-Sec33", "Source-reported layers include feature-sensitive clustered DP, k=5 anonymization/hashing, private federated score calibration using 7 quantiles per detector (28 scalars), adaptive ensemble weighting and RDP accounting. Formal privacy claims were not independently verified; flattened XML loses formulas."),
        finding("Secure aggregation, XML Sec33", "Authors describe Bonawitz-style pairwise random masking for both model updates and quantile vectors under an honest-but-curious server. This is a source-reported protocol description, not evidence that Flower SecAgg+ was used or code/security was independently audited."),
        finding("Experimental setup, XML Sec34-Sec37", "Default 3 clients, 3 communication rounds and 5 local epochs; 10 random seeds; the authors state mean/95% CI reporting. V100 GPU, Python 3.9, TensorFlow 2.15, scikit-learn 1.4 and TensorFlow Privacy moments accountant. Do not infer unprinted CI endpoints from the seed count."),
        finding("Baselines, Sec36", "CE, DP-MCDBSCAN, LocalDP, FedAvg autoencoder, SGBoost+, ROBY, FLAME, FedIsolation and DP-OCSVM. Source states aligned splits/client settings/privacy budgets, while model architectures and training-round budgets vary in cost comparisons.")
    ],
    "comparison_design": [
        finding("Table 20 (Tab20)", "Ablations include w/o DP, w/o federation, w/o adaptive weights, w/o feature-sensitive DP, w/o score calibration and individual detector removals. No standalone w/o secure aggregation row is present in this table; removing DP is not a secure-aggregation ablation."),
        finding("Table 19 (Tab19)", "Privacy-attack comparisons include no privacy, local DP, k-anonymity only, DP only and full APEW-Fed. These configurations change multiple privacy layers and do not isolate secure aggregation alone."),
        finding("Table 15 (Tab15); Remark 11", "Headline 94% communication reduction compares 3-round APEW-Fed to 50-round FedAvg with different architectures. Remark 11 attributes most communication savings to federating only the autoencoder and early stopping. Equal-3-round FedAvg is also reported. The reduction must not be attributed causally to secure aggregation.", "SOURCE-REPORTED DESIGN; CAUSAL-LIMIT INFERENCE")
    ],
    "key_results": [
        {"locator": "Tables 6-7 (Tab6,Tab7)", "evaluation": "Enriched expert-annotated sample", "metric_unit": "0-1", "APEW_F1": 0.935, "APEW_AUC": 0.971, "CE_F1": 0.962, "CE_AUC": 0.984},
        {"locator": "Table 7", "evaluation": "IPW-corrected estimated", "metric_unit": "0-1", "APEW_F1": 0.918, "APEW_AUC": 0.968},
        {"locator": "Table 7", "evaluation": "Uniform-only", "metric_unit": "0-1", "APEW_F1": 0.921, "APEW_AUC": 0.964},
        {"locator": "Table 20", "metric_unit": "0-1 F1", "full_APEW": 0.935, "without_DP": 0.953, "without_federation": 0.962, "without_adaptive_weights": 0.924, "without_feature_sensitive_DP": 0.920, "without_score_calibration": 0.928},
        {"locator": "Table 15", "method": "FedAvg", "rounds": 50, "MB_per_round": 2.1, "total_MB": 105.0, "time_seconds": 847, "F1": 0.838},
        {"locator": "Table 15", "method": "FedAvg equal-3-round budget", "rounds": 3, "MB_per_round": 2.1, "total_MB": 6.3, "time_seconds": 189, "F1": 0.791},
        {"locator": "Table 15", "method": "APEW-Fed", "rounds": 3, "MB_per_round": 2.2, "total_MB": 6.6, "time_seconds": 293, "F1": 0.935},
        {"locator": "Table 18 (Tab18)", "metric": "Inference time", "total_CPU_ms": 75.5, "total_GPU_ms": 2.3, "note": "Source table's GPU-supported versus CPU execution definitions were not independently tested."},
        {"locator": "Table 19", "configuration": "No privacy", "metric_unit": "percent attack accuracy", "shadow_MIA": 73.2, "LiRA_MIA": 81.4, "attribute_inference": 68.9},
        {"locator": "Table 19", "configuration": "Full APEW-Fed", "metric_unit": "percent attack accuracy", "shadow_MIA": 51.2, "LiRA_MIA": 53.8, "attribute_inference": 47.8},
        {"locator": "Table 21 (Tab21)", "dataset": "IEEE-CIS", "metric_unit": "0-1 F1", "APEW": 0.914, "CE": 0.940},
        {"locator": "Table 22 (Tab22)", "dataset": "NSL-KDD", "metric_unit": "0-1 F1", "APEW": 0.923, "CE": 0.947}
    ],
    "results_interpretation_limits": [
        "The 0.935 enriched-sample F1 must be accompanied by the IPW-corrected 0.918 and uniform-only 0.921 results and the sampling explanation; otherwise the best headline hides a relevant evaluation qualification.",
        "Full APEW-Fed has lower F1 than w/o DP and w/o federation; these negative trade-offs are relevant evidence and should not be omitted.",
        "The secure-aggregation effect on utility or cost cannot be separately estimated from Table 20, because no isolated masking-off arm is reported there.",
        "APEW-Fed total communication 6.6 MB is slightly higher than equal-round FedAvg 6.3 MB; the 94% headline arises against 50-round FedAvg 105 MB. Different architecture, calibration and stopping contribute; cost definitions must be harmonized before thesis comparisons.",
        "The attack metrics are empirical estimates under tested attacks and configurations; they are not proof of complete privacy or clinical regulatory compliance.",
        "Some table/math-image values were unavailable in flattened text; only values present in readable rows/narrative are transcribed. No rendered plot or formal proof audit is claimed."
    ],
    "source_limitations": finding("Discussion limitations, XML Sec62", "Annotation/enrichment bias remains a limitation despite correction; scaling substantially beyond 20 clients, concept drift, manual privacy-tier assignment, advanced model inversion/property inference/backdoors, extreme non-IID behavior, very low privacy budgets and analyst explainability require further work."),
    "source_text_issue_not_adjudicated": finding("Figure 3 caption versus Table 11 (Tab11)", "The available caption reports 1686 ensemble flags whereas Table 11 reports 5446 in the related detection-output context. Figure pixels were not examined and definitions were not reconciled, so do not treat this as a conclusively established data error; retain as an unresolved source-text consistency question.", "UNRESOLVED TEXT/CAPTION COMPARISON; NO PIXEL AUDIT"),
    "bounded_novelty_implication": {
        "classification": "RETAIN_TRANSFERABLE; STRONG CHALLENGER TO BROAD NOVELTY",
        "inference": "This source provides original private federated anomaly detection with masking-based secure aggregation described for model/calibration messages, privacy-on/off and component ablations, utility qualifications, attack tests, communication/time reporting and cross-domain tests. It directly undermines a broad claim that private FL anomaly detection has not been evaluated across utility/privacy/cost. ERP transactions and a DP ensemble differ from the thesis staff-EHR LSTM-AE matched FedAvg/SecAgg+ experiment; no isolated SecAgg-off arm is established in the reviewed tables.",
        "required_manuscript_action": "Include it as transferable 2026 evidence, with the enriched/uniform/IPW results and architecture/round-budget caveats. Explain the thesis contribution as a controlled evaluation in the specified EHR-session setting and protocol, rather than a generic first privacy-aware federated anomaly detector or first utility-cost assessment."
    }
})

assessment["combined_recommendation"] = {
    "ME04": "Update the targeted literature synthesis and narrow the novelty claim. These two sources are positive evidence against broad absence claims, but are not direct replications of the bounded EHR experiment. Remaining plausible uncertain candidates and the citation-chain source should remain disclosed; this artifact does not independently close every novelty question.",
    "ME05": "Preserve this new dated query/retrieval/screening and partial-source-reading trail. It substantiates new documented work; it does not retrospectively authenticate historical search counts or imply a systematic-review protocol.",
    "safe_contribution_wording": "This study evaluates the detection-utility and measured workflow/application-message-content costs of Flower FedAvg and the implemented SecAgg+ configuration under matched LSTM-autoencoder, synthetic EHR staff-session, client, sampling and five-seed conditions. Its contribution is the bounded empirical comparison in this setting; broader secure federated anomaly/intrusion detection and utility-cost studies already exist."
}

out = BASE / "Source_257_258_Assessment.json"
out.write_text(json.dumps(assessment, ensure_ascii=False, indent=2), encoding="utf-8")

checks = []
for r in receipts:
    raw = Path(r["raw_file"]).read_bytes()
    checks.append({"check": r["pmcid"] + "_response_integrity", "pass": len(raw) == r["response_bytes"] and hashlib.sha256(raw).hexdigest() == r["sha256"] and r["http_status"] == 200})
for pmcid, table_id, expected in [
    ("PMC13568194", "sensors-26-05337-t007", ["170.16", "56.88", "25.07", "97.71", "3.11", "88.99", "9615.67", "14,093.67"]),
    ("PMC13493948", "Tab15", ["105.0", "847", "0.838", "6.3", "189", "0.791", "6.6", "293", "0.935"]),
    ("PMC13493948", "Tab20", ["w/o DP", "0.953", "w/o federation", "0.962", "0.935"]),
    ("PMC13493948", "Tab7", ["0.935", "0.971", "0.918", "0.968", "0.921", "0.964"]),
]:
    root = ET.parse(SRC / (pmcid + "_fullText.xml")).getroot()
    node = root.find(".//*[@id='" + table_id + "']")
    text = "".join(node.itertext())
    checks.append({"check": pmcid + "_" + table_id + "_selected_transcribed_cells_present", "pass": all(v in text for v in expected), "expected": expected, "scope": "String-presence transcription check, not independent metric recalculation."})
checks.append({"check": "sources_before_cutoff", "pass": all(s["publication_date_in_source_front"] <= assessment["cutoff_date"] for s in assessment["sources"])})
checks.append({"check": "partial_scope_explicit_for_both", "pass": all(s["scientific_read_scope"].startswith("PARTIAL_") and s["not_examined"] for s in assessment["sources"])})
qa = {"status": "PASS" if all(c["pass"] for c in checks) else "FAIL", "updated_asia_singapore": now, "checks": checks, "limits": "QA confirms response integrity and selected transcription only. Scientific validity, reproducibility, formulas and figure pixels have not been independently established."}
(BASE / "Source_257_258_QA.json").write_text(json.dumps(qa, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps({"assessment": str(out), "qa": qa["status"], "checks": len(checks), "source_count": len(assessment["sources"])}))
