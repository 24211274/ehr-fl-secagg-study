# Exact manuscript corrections for ME-04 and ME-05

These replacement paragraphs are prepared from the dated11 October2026 search. They have not been applied to the Word manuscript. Bnnnn locators identify original direct body blocks in word/document.xml, not page numbers. Historical counts remain historical.

## ME04-P1 §2.7 after original B0281

**Action:** INSERT

Maghrabi et al. (2026) describe a federated anomaly-detection system for health information systems using FedAvg and TLS. Their security description places SMPC in both the current design and future work, while the inspected text does not identify a named experimental dataset, sample size or matched plain-versus-secure aggregation arms. The study is therefore relevant prior federated healthcare-security work, but its reported results do not establish an equivalent controlled comparison on staff-access sessions. Capparelli et al. (2026) further show the importance of contextual access governance; their proposed integration and referenced validation do not provide a new FedAvg–SecAgg+ experiment.

## ME04-P2 §2.7 after ME04-P1

**Action:** INSERT

Transferable studies also constrain the novelty claim. Munusamy and Jothi (2026) combine blockchain, federated learning and secure third-party computation in an EHR-security preprint. Kamatchi and Uma (2025) evaluate an IoT insider-detection design with grouped component ablations, and Abbasi et al. (2025) evaluate FedAvg on CERT user profiles using simulated privacy mechanisms. Tanvir et al. (2026) and Javed et al. (2025) address broader healthcare privacy, security and efficiency. These studies require comparison by the unit of detection, the implemented protection mechanism, the controlled experimental factors and the definition of system cost. Their reported accuracies are not directly comparable across these different tasks and datasets. Shamim et al. (2026) compare two encrypted SDN intrusion-detection implementations under matched detector and cryptographic-parameter settings, while Qazi et al. (2026) report private federated ERP anomaly detection with component ablations and utility/cost evaluation. These are substantive transferable precedents. Their different tasks and interventions require qualification: the former changes the cryptographic stack, and the latter's headline communication reduction compares different round budgets; Table20 does not isolate secure aggregation alone.

## ME04-P3 §2.8 original B0288–B0290

**Action:** REPLACE_THREE_PARAGRAPHS

Federated EHR access-anomaly detection is already represented by Martínez Llamas et al. (2025). Their Flower/FedAvg LSTM-autoencoder experiment uses real hospital access records but lacks anomaly ground truth and a matched SecAgg+ evaluation. Labelled synthetic EHR detection is also represented by Senturk et al. (2025) and Iqbal et al. (2026), while Sutradhar et al. (2026) places federated learning in future work. Consequently, neither federated detection nor the use of synthetic anomaly labels alone constitutes the contribution of this study.

The empirical question is how protecting client updates changes detection outputs and recorded workflow cost when the detector, initial states, sampling schedules and evaluation procedures are held constant. The present study compares standard Flower FedAvg with a pooled centralised reference, then compares FedAvg with the implemented SecAgg+ workflow on the same fixed synthetic benchmark. Source-labelled routine and unusual legitimate sessions permit false alerts to be counted under the benchmark's label assumptions. Recorded fit-workflow time and application-message content measure specific operational effects; they do not establish end-to-end network overhead or a formal privacy guarantee.

The contribution is bounded empirical evidence from this controlled comparison, rather than a new federated-learning algorithm. The targeted literature refresh of 11 October 2026 identified direct and transferable prior work, including additional healthcare-security designs and unresolved full-article candidates. FeadSeq and the regular-versus-secure network-monitoring study remain qualified comparators because their complete articles were not available for examination in this refresh. The search register distinguishes complete public-API retrieval for the executed queries from top-result web discovery. These findings support the stated empirical positioning but do not certify exhaustive coverage, global priority or generalisation beyond the evaluated synthetic benchmark.

## ME05-P1 Appendix A new subsection after B0643

**Action:** INSERT

Literature refresh of 11 October 2026. A documented targeted narrative update used four query families separately in PubMed E-utilities and Europe PMC, supplemented by web-index discovery and source chaining. Refresh identifiers are distinct from the historical August S1–S4 identifiers. All returned public-API identifiers and bibliographic records were preserved for the exact executed queries, together with request URLs, query translations, warnings, timestamps and raw-response hashes. The query-hit sum was 498; after within-database merging there were 488 database records, corresponding to 281 stable source identifiers before final DOI/title reconciliation. Web responses preserve returned top results and batch provenance; search-engine total hits were not supplied. Eligibility decisions, duplicates, full-text access levels and the closest-study comparison are retained in the 11 October refresh package. This is a narrative update and does not retrospectively authenticate or replace the historical August searches.

## ME05-TR02 Appendix A opening B0633

**Action:** replace first two sentences; preserve later September sentence

The literature review preserves the historical searches in Appendix B and reports later verification and searching separately. On 11 October 2026, the supplied native-export files were structurally inspected and their record counts reconciled against the historical entries where possible. This verified the contents of the received files, but did not independently authenticate every original query execution, filter setting, total-hit count or screening decision. PubMed export gaps and ACM all-results coverage remain explicitly unresolved.

## ME05-TR03 Appendix A.2 B0643 final two sentences

**Action:** replace stale candidate-status ending, preserving three-source follow-up history

Subsequent source follow-ups checked the full texts of the retained BFL-STPC and Kamatchi papers, including all their figures and tables, and the six-page Abbasi conference paper. Their unresolved numerical and methodological qualifications remain recorded; source availability does not establish correctness or independent replication. The related Abbasi master's thesis was excluded from the requested review scope. Other candidate access levels are reported individually in the current source-evidence matrix and candidate access records. These targeted checks do not constitute a complete Source Coverage Audit of the bibliography.

## ME05-TR07 Appendix C opening B0684

**Action:** replace complete paragraph

The supplied PubMed S1 CSV was inspected on 11 October 2026 and contains 10 records, compared with 15 hits in the historical search record. Five records remain unreconciled, and PubMed S3 still lacks its recorded 12-result export. These are evidence gaps, not screened exclusions. The three supplied ACM BibTeX exports each contain20 records, but their database total hits and complete coverage remain unverified. Other supplied platform exports were reconciled at the file-content level as documented in the 11 Octoberverification record. Later search results are reported as a new dated search and are not substituted for the historical values.

## ME05-B0647 Appendix B Scopus S1 B0647 integrity-note cell

**Action:** REPLACE_INTEGRITY_NOTE_ONLY; PRESERVE_HISTORICAL_QUERY_AND_COUNT

The supplied Scopus S1 export was inspected on 11 October 2026 and contains 64 records, matching the historical entry. This verifies the received file contents, rather than independently authenticating every original query setting, total-hit count or complete database retrieval.

## ME05-B0649 Appendix B Scopus S2 B0649 integrity-note cell

**Action:** REPLACE_INTEGRITY_NOTE_ONLY; PRESERVE_HISTORICAL_QUERY_AND_COUNT

The supplied Scopus S2 export was inspected on 11 October 2026 and contains 4 records, matching the historical entry. This verifies the received file contents, rather than independently authenticating every original query setting, total-hit count or complete database retrieval. The four-record file is scopus_export_Aug 11-2026_S2.ris. The file named 2026-08-11_scopus_S2.ris.ris is byte-identical to the 117-record S4 export and must not be treated as S2.

## ME05-B0651 Appendix B Scopus S3 B0651 integrity-note cell

**Action:** REPLACE_INTEGRITY_NOTE_ONLY; PRESERVE_HISTORICAL_QUERY_AND_COUNT

The supplied Scopus S3 export was inspected on 11 October 2026 and contains 30 records, matching the historical entry. This verifies the received file contents, rather than independently authenticating every original query setting, total-hit count or complete database retrieval.

## ME05-B0653 Appendix B Scopus S4 B0653 integrity-note cell

**Action:** REPLACE_INTEGRITY_NOTE_ONLY; PRESERVE_HISTORICAL_QUERY_AND_COUNT

The supplied Scopus S4 export was inspected on 11 October 2026 and contains 117 records, matching the historical entry. This verifies the received file contents, rather than independently authenticating every original query setting, total-hit count or complete database retrieval. Two records share DOI 10.1201/9781003393580-102 but have different Scopus identifiers; 117 is a raw-record count, not a verified unique-study count.

## ME05-B0656 Appendix B Web of Science S1 B0656 integrity-note cell

**Action:** REPLACE_INTEGRITY_NOTE_ONLY; PRESERVE_HISTORICAL_QUERY_AND_COUNT

The supplied Web of Science S1 export was inspected on 11 October 2026 and contains 28 records, matching the historical entry. This verifies the received file contents, rather than independently authenticating every original query setting, total-hit count or complete database retrieval.

## ME05-B0658 Appendix B Web of Science S2 B0658 integrity-note cell

**Action:** REPLACE_INTEGRITY_NOTE_ONLY; PRESERVE_HISTORICAL_QUERY_AND_COUNT

The supplied Web of Science S2 export was inspected on 11 October 2026 and contains 1 records, matching the historical entry. This verifies the received file contents, rather than independently authenticating every original query setting, total-hit count or complete database retrieval.

## ME05-B0660 Appendix B Web of Science S3 B0660 integrity-note cell

**Action:** REPLACE_INTEGRITY_NOTE_ONLY; PRESERVE_HISTORICAL_QUERY_AND_COUNT

The supplied Web of Science S3 export was inspected on 11 October 2026 and contains 2 records, matching the historical entry. This verifies the received file contents, rather than independently authenticating every original query setting, total-hit count or complete database retrieval.

## ME05-B0670 Appendix B IEEE Xplore S1 B0670 integrity-note cell

**Action:** REPLACE_INTEGRITY_NOTE_ONLY; PRESERVE_HISTORICAL_QUERY_AND_COUNT

The supplied IEEE Xplore S1 export was inspected on 11 October 2026 and contains 17 records, matching the historical entry. This verifies the received file contents, rather than independently authenticating every original query setting, total-hit count or complete database retrieval.

## ME05-B0672 Appendix B IEEE Xplore S2 B0672 integrity-note cell

**Action:** REPLACE_INTEGRITY_NOTE_ONLY; PRESERVE_HISTORICAL_QUERY_AND_COUNT

The supplied IEEE Xplore S2 export was inspected on 11 October 2026 and contains 5 records, matching the historical entry. This verifies the received file contents, rather than independently authenticating every original query setting, total-hit count or complete database retrieval.

## ME05-B0674 Appendix B IEEE Xplore S3 B0674 integrity-note cell

**Action:** REPLACE_INTEGRITY_NOTE_ONLY; PRESERVE_HISTORICAL_QUERY_AND_COUNT

The supplied IEEE Xplore S3 export was inspected on 11 October 2026 and contains 9 records, matching the historical entry. This verifies the received file contents, rather than independently authenticating every original query setting, total-hit count or complete database retrieval.

## ME05-B0663 Appendix B PubMed B0663 integrity-note cell

**Action:** REPLACE_INTEGRITY_NOTE_ONLY

The received PubMed S1 CSV was inspected on 11 October 2026 and contains 10 records. The historical 15-hit total remains unverified and five records remain unreconciled. They are not screened exclusions, and no missing historical records were reconstructed.

## ME05-B0665 Appendix B PubMed B0665 integrity-note cell

**Action:** REPLACE_INTEGRITY_NOTE_ONLY

The historical PubMed S2 zero-result entry lacks a contemporaneous preserved response establishing the original query and settings. No export is expected for a genuine zero-result search; a later search cannot independently authenticate this historical zero.

## ME05-B0667 Appendix B PubMed B0667 integrity-note cell

**Action:** REPLACE_INTEGRITY_NOTE_ONLY

The historical PubMed S3 count of 12 results still lacks its retained native export. This evidence gap is not resolved by the 11 October 2026 refresh.

## ME05-B0677 Appendix B ACM S1 B0677 integrity-note cell

**Action:** REPLACE_INTEGRITY_NOTE_ONLY

The supplied BibTeX export was inspected on 11 October 2026 and contains 20 records. The database total-hit count, export range and complete all-results coverage remain unverified. Proceedings-volume records are not equivalent to individual research papers.

## ME05-B0679 Appendix B ACM S2 B0679 integrity-note cell

**Action:** REPLACE_INTEGRITY_NOTE_ONLY

The supplied BibTeX export was inspected on 11 October 2026 and contains 20 records. The database total-hit count, export range and complete all-results coverage remain unverified. Proceedings-volume records are not equivalent to individual research papers.

## ME05-B0681 Appendix B ACM S4 B0681 integrity-note cell

**Action:** REPLACE_INTEGRITY_NOTE_ONLY

The supplied BibTeX export was inspected on 11 October 2026 and contains 20 records. The database total-hit count, export range and complete all-results coverage remain unverified. Proceedings-volume records are not equivalent to individual research papers.

## Verified reference metadata

DOI metadata were checked separately from scientific content. Use the exact author and title fields in reference_metadata/Metadata_Verification.json; unavailable fields must not be invented. All ten DOI requests succeeded. Dates and author-format exceptions are listed in Exact_Manuscript_Corrections.json.

- Louai A. Maghrabi; Amjed Abbas Ahmed; Saed Adnan Mustafa; Abdelrahman H. Hussein; Musab A. M. Al-Tarawni. Federated Learning-Based Anomaly Detection Algorithm for Privacy-Preserving Health Information Systems. DOI: https://doi.org/10.51983/ijiss-2026.16.1.27
- Francesco Capparelli; Maria Rosaria de Ligio; Giulia Finocchiaro. Adaptive Access Governance in Healthcare. DOI: https://doi.org/10.3233/SHTI260582
- Muhammad Saeed Javed; Ali Hennache; Muhammad Imran; Muhammad Kamran Khan. AI-Driven Blockchain and Federated Learning for Secure Electronic Health Records Sharing. DOI: https://doi.org/10.3390/electronics14234774
- Munusamy S; Jothi K R. A Blockchain-Based Federated Learning Approach with Secure Third-Party Computation System for Securing Electronic Health Records. DOI: https://doi.org/10.21203/rs.3.rs-8351477/v1
- K. Kamatchi; E. Uma. Securing the edge: privacy-preserving federated learning for insider threats in IoT networks. DOI: https://doi.org/10.1007/s11227-024-06752-z
- Nimra Abbasi; Mohammed Al-Mhiqani; Hussain Al-Aqrabil; Samer Aoudi. A Privacy-Aware Federated Learning Approach for Insider Threat Detection. DOI: https://doi.org/10.1109/ITT69610.2025.11352913
- Wei Guan; Jian Cao; Haiyan Zhao; Yang Gu; Shiyou Qian. FeadSeq: A Personalized Federated Anomaly Detection Framework for Discrete Event Sequences. DOI: https://doi.org/10.1145/3742896
- Oleksandr Lytvyn; Giang Nguyen. Secure Federated Learning for Multi-Party Network Monitoring. DOI: https://doi.org/10.1109/ACCESS.2024.3486810
- Anayo Chukwu Ikegwu; Uzoma Rita Alo; Henry Friday Nweke; Deborah Uzoamaka Ebem. Advancing Federated Learning Frameworks for Privacy-preserving Cyber Threat Detection in Healthcare Systems. DOI: https://doi.org/10.1007/s44196-026-01274-3
- Adel Binbusayyis. NeuralFortress-XFL: Privacy-Preserving Federated Explainable Learning for Cyber Threat Intelligence. DOI: https://doi.org/10.3390/electronics15143124

Two further original-source identities and reading scopes were checked in the retrieved publisher-supplied JATS; these are recorded in public_api/Source_257_258_Assessment.json, separately from the ten Crossref metadata requests.

- S M Shamim; Yuta Kodera; Md Arshad Ali; Yasuyuki Nogami. (2026). An Explainable Federated Intrusion Detection Framework for SDN Using Distributed Key Generation and Threshold Homomorphic Encryption. https://doi.org/10.3390/s26175337
- Adiah Qazi; Ammad Ali Khan Jadoon; Sadiqa Arshad. (2026). APEW-Fed: adaptive privacy-aware ensemble weighting for federated anomaly detection in enterprise resource planning systems. https://doi.org/10.1038/s41598-026-60574-y