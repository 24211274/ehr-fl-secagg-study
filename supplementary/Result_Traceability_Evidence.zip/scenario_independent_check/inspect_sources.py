from pathlib import Path
import json, zipfile, hashlib

root=Path('C:/Users/RNO/Downloads/review_FL')
out=Path(__file__).resolve().parent
inventory={}
for name in ('01_Saved_Score_Audit_Inputs_Original.zip','Final_Score_Audit_Evidence_20260909T142009Z_2ad79bf6.zip','02_Final_Evaluation_Original.zip','04_EHR_FL_Benchmark_Release_Candidate_v1_0.zip','ehr-fl-secagg-study-main.zip'):
    path=root/name
    with zipfile.ZipFile(path) as z:
        inventory[name]={'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'members':[{'path':i.filename,'size':i.file_size} for i in z.infolist()]}
(out/'independent_source_inventory.json').write_text(json.dumps(inventory,indent=2),encoding='utf-8')
with zipfile.ZipFile(root/'01_Saved_Score_Audit_Inputs_Original.zip') as z:
    for n in ('calibrations/A_reference_11.json','stage_status.json'):
        print(n); print(z.read(n).decode())
    n='scores/A_reference_11_test_known_scores.csv'
    print(n); print('\n'.join(z.read(n).decode().splitlines()[:4]))
    print('manifest keys',list(json.loads(z.read('audit_export_manifest.json'))))
with zipfile.ZipFile(root/'02_Final_Evaluation_Original.zip') as z:
    cell=json.loads(z.read('cells/A_reference_11_test_known.json'))
    print('cell keys',list(cell))
    print('cell metrics keys',list(cell['metrics']))
    print('cell q99 keys',list(cell['metrics']['quantiles']['0.99']))
    (out/'sample_final_evaluation_cell.json').write_text(json.dumps(cell,indent=2),encoding='utf-8')
with zipfile.ZipFile(root/'ehr-fl-secagg-study-main.zip') as z:
    selected=[n for n in z.namelist() if n.endswith('.py') and any(x in n for x in ('evaluation','metrics','calibration','audit_scores','main_evaluation'))]
    print('likely code:',json.dumps(selected,indent=2))
    for n in selected:
        p=out/'code_reference'/Path(n)
        p.parent.mkdir(parents=True,exist_ok=True)
        p.write_bytes(z.read(n))
