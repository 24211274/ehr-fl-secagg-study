from pathlib import Path
import csv, hashlib, json

out=Path(__file__).resolve().parent
selected=[]
with (out/'per_seed_descriptive_groups_q099.csv').open(encoding='utf-8',newline='') as f:
    for row in csv.DictReader(f):
        if row['configuration']=='C' and row['group_field']=='primary_class' and row['group']!='threat':
            selected.append({k:row[k] for k in ('configuration','condition','seed','test','group','sessions','FP','TN','FPR')})
assert len(selected)==30
with (out/'Figure_4_5_independent_seed_values.csv').open('w',encoding='utf-8',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(selected[0]));writer.writeheader();writer.writerows(selected)
page=Path('C:/Users/RNO/Desktop/Coureses/P1/final_content_review_2026_10_12/qa/render_clean_delivery/page-64.png')
review={
    'figure':'Figure 4.5', 'table':'Table 4.10', 'printed_page':53, 'pdf_page':64,
    'page_image':str(page),'page_image_sha256':hashlib.sha256(page.read_bytes()).hexdigest(),
    'original_resolution_visual_review':True,'status':'PASS',
    'numerical_checks':'All six mean/sample-SD values and three sessions-per-model denominators independently recomputed and matched exactly at displayed precision.',
    'visual_checks':[
        'Figure has five separate seed symbols (11,29,47,71,97) and horizontal mean marks; not confidence intervals.',
        'Y axis is False-positive rate (%) from 0 to 100; all three groups are negative-only legitimate subgroups.',
        'Denominators n=1,986, n=189 and n=267 match the fixed sessions per model, not counts pooled across seeds.',
        'Six means are consistent with the plotted clusters; no clipping, missing legend symbols or text overlap was observed.',
    ],
    'limit':'Marker locations checked visually; this is not exact vector-coordinate recovery. Exact expected five-seed values are supplied in Figure_4_5_independent_seed_values.csv.',
}
(out/'Figure_4_5_Independent_Check.json').write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'figure_review':'PASS','seed_values_rows':len(selected)}))
