"""Cross-check parent output against independently reconstructed scenario records.

Canonical input is read-only. Extra within-client descriptive groups are
aggregated from this reviewer's original per-client scenario counts and the
original-label lookup, never from canonical counts.
"""
from pathlib import Path
import collections, csv, hashlib, json, math

HERE=Path(__file__).resolve().parent
CANONICAL=HERE.parent/'outputs/scenario_error_by_seed_reconstructed.csv'
KEY=('configuration','condition','seed','test','scope','group_field','group')
COUNTS=('sessions','positives','negatives','TP','TN','FP','FN','alerts')
RATES=('alert_rate','FPR','recall','FNR')

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def read_csv(path):
    with path.open(encoding='utf-8-sig',newline='') as f:
        return list(csv.DictReader(f))
def key(row): return tuple(str(row[k]) for k in KEY)
def nullable(value): return None if value in ('',None) else float(value)
def add_rates(row):
    p=row['positives'];n=row['negatives'];total=row['sessions']
    row['alert_rate']=row['alerts']/total
    row['FPR']=row['FP']/n if n else None
    row['recall']=row['TP']/p if p else None
    row['FNR']=row['FN']/p if p else None
    return row

def main():
    canonical_before=sha(CANONICAL)
    paths={
        'client_scenario':HERE/'per_seed_client_scenario_confusion_q099.csv',
        'global_scenario':HERE/'per_seed_global_scenario_confusion_q099.csv',
        'global_descriptive_groups':HERE/'per_seed_descriptive_groups_q099.csv',
        'source_label_lookup':HERE/'scenario_label_lookup.csv',
    }
    own_hashes={name:sha(path) for name,path in paths.items()}
    client_rows=read_csv(paths['client_scenario'])
    global_rows=read_csv(paths['global_scenario'])
    descriptive_rows=read_csv(paths['global_descriptive_groups'])
    label_rows=read_csv(paths['source_label_lookup'])
    lookup={(r['test'],r['scenario_id']):r for r in label_rows}
    assert len(lookup)==len(label_rows)
    expected={};metadata={}
    for row in client_rows+global_rows:
        converted={k:row[k] for k in ('configuration','condition','seed','test')}
        converted.update(scope='all_clients' if row['client']=='ALL' else row['client'],
                         group_field='scenario',group=row['scenario_id'])
        converted.update({c:int(row[c]) for c in COUNTS})
        converted.update({r:nullable(row[r]) for r in RATES})
        k=key(converted);assert k not in expected;expected[k]=converted
    for row in descriptive_rows:
        converted={k:row[k] for k in ('configuration','condition','seed','test','group_field','group')}
        converted['scope']='all_clients'
        converted.update({c:int(row[c]) for c in COUNTS})
        converted.update({r:nullable(row[r]) for r in RATES})
        k=key(converted);assert k not in expected;expected[k]=converted
    aggregated=collections.defaultdict(lambda:collections.Counter())
    threshold_values=collections.defaultdict(set)
    for row in client_rows:
        lab=lookup[(row['test'],row['scenario_id'])]
        assert row['primary_class']==lab['primary_class']
        base={k:row[k] for k in ('configuration','condition','seed','test')}
        for field in ('primary_class','legitimate_subtype','threat_family'):
            if not lab[field]: continue
            group={**base,'scope':row['client'],'group_field':field,'group':lab[field]}
            k=key(group)
            aggregated[k].update({c:int(row[c]) for c in COUNTS})
        # Threshold min/max for every canonical scope and group.
        for scope in (row['client'],'all_clients'):
            for field,value in [('scenario',row['scenario_id'])]+[(field,lab[field]) for field in ('primary_class','legitimate_subtype','threat_family') if lab[field]]:
                k=key({**base,'scope':scope,'group_field':field,'group':value})
                threshold_values[k].add(float(row['raw_loss_threshold']))
    for k,counts in aggregated.items():
        assert k not in expected
        expected[k]=add_rates({**dict(zip(KEY,k)),**dict(counts)})
    assert len(expected)==44220
    canonical=read_csv(CANONICAL)
    actual={key(r):r for r in canonical}
    assert len(actual)==len(canonical)==44220
    missing=sorted(set(expected)-set(actual));extra=sorted(set(actual)-set(expected))
    failures=[];max_rate_difference=0.0;max_threshold_difference=0.0
    rate_values_checked=0;null_values_checked=0;counts_checked=0;role_checks=0
    coverage=collections.Counter()
    for k in sorted(set(expected)&set(actual)):
        e,a=expected[k],actual[k]
        coverage[(a['scope'],a['group_field'])]+=1
        for col in COUNTS:
            counts_checked+=1
            if int(a[col])!=e[col]:failures.append({'key':k,'field':col,'expected':e[col],'actual':a[col]})
        for col in RATES:
            av=nullable(a[col]);ev=e[col]
            if ev is None:
                null_values_checked+=1
                if av is not None:failures.append({'key':k,'field':col,'expected':None,'actual':av})
            elif av is None or not math.isfinite(av):
                failures.append({'key':k,'field':col,'expected':ev,'actual':av})
            else:
                rate_values_checked+=1;delta=abs(ev-av);max_rate_difference=max(delta,max_rate_difference)
                if delta>1e-12:failures.append({'key':k,'field':col,'expected':ev,'actual':av,'delta':delta})
        role='recall' if e['positives']==e['sessions'] else 'FPR' if e['negatives']==e['sessions'] else 'alert_rate'
        role_checks+=1
        if a['rate_role']!=role:failures.append({'key':k,'field':'rate_role','expected':role,'actual':a['rate_role']})
        if a['ranking_metrics_computed']!='False':failures.append({'key':k,'field':'ranking_metrics_computed','expected':'False','actual':a['ranking_metrics_computed']})
        if a['alert_operator']!='>' or float(a['quantile'])!=0.99 or a['decision_score_representation']!='raw_loss_vs_client_validation_threshold':
            failures.append({'key':k,'field':'decision_semantics','actual':[a['alert_operator'],a['quantile'],a['decision_score_representation']]})
        tv=threshold_values[k]
        for name,expected_threshold in [('threshold_min',min(tv)),('threshold_max',max(tv))]:
            delta=abs(float(a[name])-expected_threshold);max_threshold_difference=max(delta,max_threshold_difference)
            if delta>1e-12:failures.append({'key':k,'field':name,'expected':expected_threshold,'actual':a[name]})
    assert sha(CANONICAL)==canonical_before
    assert {name:sha(path) for name,path in paths.items()}==own_hashes
    report={
        'status':'PASS' if not failures and not missing and not extra else 'MISMATCH',
        'canonical_file':str(CANONICAL),'canonical_sha256':canonical_before,
        'canonical_rows':len(canonical),'independent_expected_rows':len(expected),
        'method':'Independent source-score count outputs plus aggregation of own client-scenario counts into client descriptive groups; no canonical helper imported',
        'comparison_key':list(KEY),
        'independent_inputs':{name:{'path':str(path),'sha256':own_hashes[name]} for name,path in paths.items()},
        'coverage':[{'scope':scope,'group_field':field,'rows':n} for (scope,field),n in sorted(coverage.items())],
        'checks':{
            'integer_count_comparisons':counts_checked,'defined_rate_comparisons':rate_values_checked,
            'undefined_rate_null_checks':null_values_checked,'rate_role_checks':role_checks,
            'threshold_min_max_comparisons':2*len(actual),
            'no_scenario_ranking_metrics_and_original_operator_checks':len(actual),
        },
        'maximum_absolute_defined_rate_difference':max_rate_difference,
        'maximum_absolute_threshold_difference':max_threshold_difference,
        'missing_keys':missing,'extra_keys':extra,'failures':failures,'failure_count':len(failures),
        'read_only_canonical_file_unchanged_after_comparison':True,
        'independent_inputs_unchanged_after_comparison':True,
        'undefined_rate_conclusion':'All absent-class Recall/FNR or FPR values remain empty/null, not numeric zero. Positive-only alert rates are recall; negative-only rates are FPR.',
        'limits':'Verifies reconstruction and arithmetic against preserved scores; no recovery/authentication of historical missing file, new training or external label validation.',
    }
    (HERE/'Cross_Check_Canonical_Scenarios.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:report[k] for k in ('status','canonical_rows','independent_expected_rows','checks','maximum_absolute_defined_rate_difference','maximum_absolute_threshold_difference','failure_count')},indent=2))

if __name__=='__main__':main()
