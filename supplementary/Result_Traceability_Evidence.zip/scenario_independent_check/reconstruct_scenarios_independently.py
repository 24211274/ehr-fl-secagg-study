"""Independent arithmetic from frozen score CSVs; standard library only.

Does not import the study or its previous audit helpers, load weights, score,
train, negate scores, refit thresholds or write any source file.
"""
from pathlib import Path
import ast, collections, csv, hashlib, io, json, math, statistics, sys, zipfile

ROOT = Path('C:/Users/RNO/Downloads/review_FL')
OUT = Path(__file__).resolve().parent
SOURCE = Path('C:/Users/RNO/Downloads/تجارب المشروع/EHR_FL_Main_Experiments_Package_v1_0_3.zip')
INPUTS = {
    'score_export': ROOT/'01_Saved_Score_Audit_Inputs_Original.zip',
    'duplicate_score_export': ROOT/'Final_Score_Audit_Evidence_20260909T142009Z_2ad79bf6.zip',
    'final_evaluation': ROOT/'02_Final_Evaluation_Original.zip',
    'benchmark': ROOT/'04_EHR_FL_Benchmark_Release_Candidate_v1_0.zip',
    'github_snapshot': ROOT/'ehr-fl-secagg-study-main.zip',
    'frozen_source': SOURCE,
}
SEEDS = (11, 29, 47, 71, 97)
CLIENTS = ('C1', 'C2', 'C3')
TESTS = ('test_held_out', 'test_known')
CONDITIONS = ('reference', 'noniid')
QUANTILE = '0.99'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def read_json(raw):
    def unique(items):
        result={}
        for key, value in items:
            assert key not in result, ('duplicate_json_key', key)
            result[key]=value
        return result
    return json.loads(raw.decode('utf-8-sig'), object_pairs_hook=unique)

def read_csv(raw):
    reader=csv.DictReader(io.StringIO(raw.decode('utf-8-sig'), newline=''))
    assert len(reader.fieldnames)==len(set(reader.fieldnames))
    rows=list(reader)
    assert all(None not in r and all(v is not None for v in r.values()) for r in rows)
    return rows

def member_ending(z, suffix):
    names=[n for n in z.namelist() if n.endswith(suffix)]
    assert len(names)==1, names
    return names[0]

def verify_zip_manifest(z, member):
    manifest=read_json(z.read(member))
    expected={r['path'] for r in manifest['files']}
    assert len(expected)==len(manifest['files'])
    actual={n for n in z.namelist() if not n.endswith('/')}
    assert actual==expected|{member}
    for row in manifest['files']:
        raw=z.read(row['path'])
        assert len(raw)==row['bytes'] and sha(raw)==row['sha256'], row['path']
    return len(expected)

def write_csv(name, rows):
    assert rows
    with (OUT/name).open('w', newline='', encoding='utf-8') as f:
        writer=csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)

def count_group(records):
    # Four disjoint categories counted directly; no shared study/audit helper.
    tp=sum(r['label']==1 and r['alert'] for r in records)
    fn=sum(r['label']==1 and not r['alert'] for r in records)
    fp=sum(r['label']==0 and r['alert'] for r in records)
    tn=sum(r['label']==0 and not r['alert'] for r in records)
    n=len(records); positives=tp+fn; negatives=fp+tn; alerts=tp+fp
    assert tp+fn+fp+tn==n
    class_scope='positive_only' if positives==n else 'negative_only' if negatives==n else 'mixed'
    rate_kind='Recall' if class_scope=='positive_only' else 'FPR' if class_scope=='negative_only' else 'alert_rate'
    return {
        'sessions':n, 'positives':positives, 'negatives':negatives,
        'TP':tp, 'FN':fn, 'FP':fp, 'TN':tn, 'alerts':alerts,
        'recall':tp/positives if positives else None,
        'FPR':fp/negatives if negatives else None,
        'FNR':fn/positives if positives else None,
        'alert_rate':alerts/n, 'alert_rate_kind':rate_kind, 'class_scope':class_scope,
        'recall_status':'DEFINED' if positives else 'N/A — NO POSITIVES',
        'FPR_status':'DEFINED' if negatives else 'N/A — NO NEGATIVES',
        'AP':None, 'AUROC':None,
        'ranking_status':'NOT CALCULATED — ONE-CLASS SUBGROUP' if class_scope!='mixed' else 'NOT CALCULATED — COUNT RECONSTRUCTION SCOPE',
    }

def identity(config, condition, seed, test):
    return {'configuration':config, 'condition':condition, 'seed':seed,
            'test':test, 'quantile':0.99, 'alert_operator':'>'}

def summarize(rows, keyfields):
    groups=collections.defaultdict(list)
    for row in rows:
        groups[tuple(row[k] for k in keyfields)].append(row)
    output=[]
    for key, group in sorted(groups.items()):
        assert len(group)==5 and {r['seed'] for r in group}==set(SEEDS)
        assert len({r['sessions'] for r in group})==1
        result=dict(zip(keyfields,key))
        result.update(n_seeds=5, sessions_per_model=group[0]['sessions'],
                      positives_per_model=group[0]['positives'], negatives_per_model=group[0]['negatives'],
                      class_scope=group[0]['class_scope'], alert_rate_kind=group[0]['alert_rate_kind'])
        for column in ('TP','FN','FP','TN','alerts','recall','FPR','FNR','alert_rate'):
            vals=[r[column] for r in group]
            if all(v is None for v in vals):
                result[column+'_mean']=None; result[column+'_sample_sd']=None
            else:
                assert all(v is not None for v in vals)
                result[column+'_mean']=statistics.mean(vals)
                result[column+'_sample_sd']=statistics.stdev(vals)
        result['uncertainty_scope']='sample SD of five training seeds on the same fixed sessions; not CI'
        output.append(result)
    return output

def main():
    before={key:sha(path.read_bytes()) for key,path in INPUTS.items()}
    assert before['score_export']==before['duplicate_score_export'], 'Score export copies differ'
    sources={key:zipfile.ZipFile(path) for key,path in INPUTS.items()}
    scores=sources['score_export']; final=sources['final_evaluation']; bench=sources['benchmark']
    github=sources['github_snapshot']; code=sources['frozen_source']
    integrity={
        'score_export_manifest_payloads_verified':verify_zip_manifest(scores,'audit_export_manifest.json'),
        'evaluation_report_manifest_payloads_verified':verify_zip_manifest(final,'report_files.json'),
    }
    assert scores.read('reviewed_final_report_manifest.json')==final.read('report_files.json')
    assert scores.read('stage_status.json')==final.read('stage_status.json')
    assert scores.read('source_integrity.json')==final.read('source_integrity.json')
    export_manifest=read_json(scores.read('audit_export_manifest.json'))
    selection=read_json(scores.read('selected_models_manifest.json'))
    assert sha(scores.read('selected_models_manifest.json'))==export_manifest['source_selected_models_manifest_sha256']
    assert sha(final.read('report_files.json'))==export_manifest['source_final_report_manifest_sha256']
    models={(r['configuration'],r['condition'],r['seed']):r for r in selection['models']}
    assert len(selection['models'])==len(models)==30
    assert set(models)=={(c,co,s) for c in 'ABC' for co in CONDITIONS for s in SEEDS}
    code_prefix=member_ending(code,'/PACKAGE_SHA256SUMS.txt').removesuffix('PACKAGE_SHA256SUMS.txt')
    source_manifest=code.read(code_prefix+'PACKAGE_SHA256SUMS.txt')
    assert sha(source_manifest)==selection['package_manifest_sha256']
    for line in source_manifest.decode().splitlines():
        digest,name=line.split('  ',1)
        assert sha(code.read(code_prefix+name))==digest, name
    evaluation_member=code_prefix+'main_study/evaluation.py'
    evaluation_raw=code.read(evaluation_member)
    git_evaluation=member_ending(github,'/main_study/evaluation.py')
    assert github.read(git_evaluation)==evaluation_raw
    (OUT/'frozen_evaluation_source.py').write_bytes(evaluation_raw)
    pipeline=code.read(code_prefix+'app/ehr_preprocessing/pipeline.py')
    client_map=None
    for node in ast.parse(pipeline.decode()).body:
        if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CLIENTS' for t in node.targets):
            client_map=ast.literal_eval(node.value)
    assert client_map is not None and set(client_map)==set(CLIENTS)
    hospital_to_client={v:k for k,v in client_map.items()}
    labels_member=member_ending(bench,'/data/labels.csv')
    label_raw=bench.read(labels_member)
    for entry in read_json(scores.read('source_integrity.json'))['files']:
        if entry['file']=='labels.csv':
            assert sha(label_raw)==entry['sha256'] and len(label_raw)==entry['bytes']
    label_rows=read_csv(label_raw)
    label_by_id={r['session_id']:r for r in label_rows}
    assert len(label_rows)==len(label_by_id)==17464
    ids_by_test={test:{r['session_id'] for r in label_rows if r['partition']==test} for test in TESTS}
    assert len(ids_by_test['test_held_out'])==2364 and len(ids_by_test['test_known'])==645
    assert not ids_by_test['test_held_out'] & ids_by_test['test_known']
    client_scenarios=[]; global_scenarios=[]; descriptive_groups=[]
    scenario_cells_checked=0; confusion_scopes_checked=0; exact_threshold_ties=0
    transformed_decision_disagreements=0; total_score_rows=0
    source_records=[]; scenario_lookup={}
    for (config,condition,seed),model in sorted(models.items()):
        stem=f'{config}_{condition}_{seed}'
        calibration_member=f'calibrations/{stem}.json'
        calibration_raw=scores.read(calibration_member)
        assert sha(calibration_raw)==model['calibration_sha256']
        calibration=read_json(calibration_raw)
        assert calibration['fit_partition']=='validation' and calibration['test_data_used'] is False
        assert calibration['selected_checkpoint_sha256']==model['selected_checkpoint_sha256']
        assert (calibration['configuration'],calibration['condition'],calibration['training_seed'])==(config,condition,seed)
        for client,parameters in calibration['clients'].items():
            assert parameters['alert_operator']=='>' and parameters['fit_partition']=='validation'
            assert parameters['scale']>0 and math.isfinite(parameters['scale'])
            assert abs((parameters['thresholds'][QUANTILE]-parameters['median'])/parameters['scale']-parameters['calibrated_thresholds'][QUANTILE])<1e-12
        for test in TESTS:
            score_member=f'scores/{stem}_{test}_scores.csv'
            stored=read_csv(scores.read(score_member)); observed_ids=[r['session_id'] for r in stored]
            assert len(observed_ids)==len(set(observed_ids)) and set(observed_ids)==ids_by_test[test]
            original=read_json(final.read(f'cells/{stem}_{test}.json'))
            assert original['checkpoint_sha256']==model['selected_checkpoint_sha256']
            assert original['calibration_sha256']==model['calibration_sha256']
            assert (original['configuration'],original['condition'],original['seed'],original['test'])==(config,condition,seed,test)
            records=[]
            for row in stored:
                source=label_by_id[row['session_id']]
                expected=(hospital_to_client[source['hospital_id']],test,
                          '1' if source['binary_label']=='TRUE' else '0',source['scenario_id'],source['primary_class'])
                assert tuple(row[k] for k in ('client','partition','label','scenario','primary_class'))==expected
                assert source['binary_label'] in ('TRUE','FALSE')
                assert (row['label']=='1')==(row['primary_class']=='threat')
                loss=float(row['loss']); assert math.isfinite(loss) and loss>=0
                parameters=calibration['clients'][row['client']]
                threshold=parameters['thresholds'][QUANTILE]
                exact_threshold_ties+=loss==threshold
                alert=loss>threshold
                calibrated=(loss-parameters['median'])/parameters['scale']
                transformed_decision_disagreements+=alert!=(calibrated>parameters['calibrated_thresholds'][QUANTILE])
                records.append({**row, 'label':int(row['label']), 'loss':loss, 'threshold':threshold,
                                'alert':alert, 'calibrated_score':calibrated,
                                'legitimate_subtype':source['legitimate_subtype'], 'threat_family':source['threat_family']})
                lookup=(test,row['scenario'],source['primary_class'],source['legitimate_subtype'],source['threat_family'])
                scenario_lookup[lookup]=True
            total_score_rows+=len(records)
            base=identity(config,condition,seed,test)
            groups=collections.defaultdict(list)
            for row in records: groups[row['scenario']].append(row)
            recorded_scenarios={r['scenario']:r for r in original['metrics']['quantiles'][QUANTILE]['scenario_counts']}
            assert set(groups)==set(recorded_scenarios)
            for scenario,group in sorted(groups.items()):
                stats=count_group(group)
                first=group[0]
                metadata={'scenario_id':scenario, 'scenario_name':first['threat_family'] or first['legitimate_subtype'] or 'routine_legitimate',
                          'primary_class':first['primary_class']}
                assert len({(r['primary_class'],r['threat_family'],r['legitimate_subtype']) for r in group})==1
                global_scenarios.append({**base,'client':'ALL',**metadata,**stats})
                expected=recorded_scenarios[scenario]
                for field in ('sessions','positives','TP','FN','FP','TN'):
                    assert stats[field]==expected[field], (stem,test,scenario,field)
                scenario_cells_checked+=1
                for client in CLIENTS:
                    subset=[r for r in group if r['client']==client]
                    if not subset: continue
                    p=calibration['clients'][client]
                    client_scenarios.append({**base,'client':client,**metadata,
                        'raw_loss_threshold':p['thresholds'][QUANTILE],
                        'calibrated_threshold':p['calibrated_thresholds'][QUANTILE],**count_group(subset)})
            for client in ('ALL',)+CLIENTS:
                subset=records if client=='ALL' else [r for r in records if r['client']==client]
                stats=count_group(subset)
                original_scope=original['metrics']['quantiles'][QUANTILE]['global'] if client=='ALL' else original['metrics']['quantiles'][QUANTILE]['per_client'][client]
                for field in ('sessions','positives','negatives','TP','FN','FP','TN'):
                    assert stats[field]==original_scope[field], (stem,test,client,field)
                confusion_scopes_checked+=1
            for field in ('primary_class','legitimate_subtype','threat_family'):
                group_map=collections.defaultdict(list)
                for row in records:
                    if row[field]:group_map[row[field]].append(row)
                for value,group in sorted(group_map.items()):
                    descriptive_groups.append({**base, 'group_field':field, 'group':value,**count_group(group),
                        'raw_median':statistics.median(r['loss'] for r in group),
                        'calibrated_median':statistics.median(r['calibrated_score'] for r in group)})
            source_records.append({'configuration':config,'condition':condition,'seed':seed,'test':test,
                                   'score_member':score_member,'score_sha256':sha(scores.read(score_member)),
                                   'calibration_member':calibration_member,'calibration_sha256':sha(calibration_raw),
                                   'checkpoint_sha256':model['selected_checkpoint_sha256'], 'score_rows':len(stored)})
    assert total_score_rows==90270 and transformed_decision_disagreements==0
    # Prove that scenario-by-client records are an exhaustive partition of each global scenario.
    rolled=collections.defaultdict(lambda:collections.Counter())
    keyfields=['configuration','condition','seed','test','scenario_id']
    for row in client_scenarios:
        key=tuple(row[k] for k in keyfields)
        rolled[key].update({k:row[k] for k in ('sessions','positives','negatives','TP','FN','FP','TN')})
    for row in global_scenarios:
        assert dict(rolled[tuple(row[k] for k in keyfields)])=={k:row[k] for k in ('sessions','positives','negatives','TP','FN','FP','TN')}
    write_csv('per_seed_client_scenario_confusion_q099.csv',client_scenarios)
    write_csv('per_seed_global_scenario_confusion_q099.csv',global_scenarios)
    write_csv('per_seed_descriptive_groups_q099.csv',descriptive_groups)
    scenario_summary=summarize(global_scenarios,['configuration','condition','test','scenario_id','scenario_name','primary_class'])
    class_summary=summarize(descriptive_groups,['configuration','condition','test','group_field','group'])
    write_csv('global_scenario_seed_summary_q099.csv',scenario_summary)
    write_csv('descriptive_group_seed_summary_q099.csv',class_summary)
    lookup_rows=[dict(zip(['test','scenario_id','primary_class','legitimate_subtype','threat_family'],k)) for k in sorted(scenario_lookup)]
    write_csv('scenario_label_lookup.csv',lookup_rows)
    write_csv('source_cell_lineage.csv',source_records)
    # Compare with two old CSV copies: byte-identical copies are one source, not independent validation.
    git_a='ehr-fl-secagg-study-main/analysis/final_score_audit/descriptive_class_error_summary.csv'
    git_b='ehr-fl-secagg-study-main/results/tables/descriptive_class_error_summary.csv'
    assert github.read(git_a)==github.read(git_b)
    old_summary=read_csv(github.read(git_a))
    derived={tuple(row[k] for k in ['test','condition','configuration','group_field','group']):row for row in class_summary}
    old_keys={tuple(row[k] for k in ['test','condition','configuration','group_field','group']) for row in old_summary}
    assert len(old_summary)==len(old_keys) and set(derived)==old_keys
    max_delta=0.0; comparisons=0
    for old in old_summary:
        key=tuple(old[k] for k in ['test','condition','configuration','group_field','group'])
        new=derived[key]
        assert new['n_seeds']==int(old['n_seeds']) and new['sessions_per_model']==int(old['sessions_per_model'])
        for value in ('TP','FN','FP','TN','mean_alert_rate','raw_median','calibrated_median'):
            field='alert_rate' if value=='mean_alert_rate' else value
            per_seed=[r for r in descriptive_groups if tuple(r[k] for k in ['test','condition','configuration','group_field','group'])==key]
            values=[r[field] for r in per_seed]
            for label,actual in [('mean',statistics.mean(values)),('sd',statistics.stdev(values))]:
                expected=float(old[f'{value}_{label}_across_seeds'])
                delta=abs(actual-expected); max_delta=max(delta,max_delta); comparisons+=1
                assert delta<=1e-12,(key,value,label,actual,expected)
    # Table 4.10 printed means/SDs from the reviewed v1.13 text, percentage units.
    expected_table={
        ('test_held_out','routine_legitimate'):{'reference':(1986,'1.26','0.18'),'noniid':(1986,'1.36','0.17')},
        ('test_held_out','unusual_legitimate'):{'reference':(189,'87.30','14.90'),'noniid':(189,'68.15','3.07')},
        ('test_known','unusual_legitimate'):{'reference':(267,'98.58','1.17'),'noniid':(267,'96.40','2.97')},
    }
    table_checks=[]
    for (test,group),conditions in expected_table.items():
        for condition,(n,mean,sd) in conditions.items():
            row=derived[(test,condition,'C','primary_class',group)]
            actual_mean=f"{100*row['FPR_mean']:.2f}"; actual_sd=f"{100*row['FPR_sample_sd']:.2f}"
            assert row['sessions_per_model']==n and actual_mean==mean and actual_sd==sd
            table_checks.append({'test':test,'condition':condition,'group':group,'sessions_per_model':n,
                'FPR_percent_mean':actual_mean,'FPR_percent_sample_sd':actual_sd,
                'matches_Table_4_10':True,'Figure_4_5_input_summary_matches':True})
    after={key:sha(path.read_bytes()) for key,path in INPUTS.items()}
    assert after==before
    result={
        'status':'PASS — INDEPENDENT STORED-SCORE SCENARIO RECONSTRUCTION',
        'method':'Standard-library direct counting; no imported study or previous audit helpers',
        'input_archives':{key:{'path':str(path),'sha256':before[key]} for key,path in INPUTS.items()},
        'input_archives_unchanged_after_execution':True,'integrity':integrity,
        'source_labels':{'member':labels_member,'sha256':sha(label_raw),'rows':len(label_rows),'exact_score_label_membership_checks':total_score_rows},
        'duplicate_score_exports_byte_identical':True,
        'frozen_package_manifest_sha256':sha(source_manifest),'frozen_evaluation_source_sha256':sha(evaluation_raw),
        'frozen_and_github_evaluation_source_byte_identical':True,
        'original_summary_copies':{'members':[git_a,git_b],'byte_identical':True,'independent_evidence_sources':1,'sha256':sha(github.read(git_a))},
        'counts':{'models':30,'score_files':60,'score_rows':total_score_rows,'distinct_test_sessions':3009,
            'test_held_out_sessions_per_model':2364,'test_known_sessions_per_model':645,
            'client_scenario_seed_rows':len(client_scenarios),'global_scenario_seed_rows':len(global_scenarios),
            'descriptive_group_seed_rows':len(descriptive_groups),'scenario_summary_rows':len(scenario_summary),
            'descriptive_summary_rows':len(class_summary),'original_scenario_cells_exactly_matched':scenario_cells_checked,
            'original_global_and_client_confusion_scopes_exactly_matched':confusion_scopes_checked,
            'old_summary_numeric_mean_sd_comparisons':comparisons,
            'exact_loss_threshold_ties':exact_threshold_ties,'raw_vs_calibrated_threshold_decision_disagreements':transformed_decision_disagreements},
        'old_summary_max_absolute_difference':max_delta,
        'Table_4_10_and_Figure_4_5_summary_checks':table_checks,
        'semantics':{
            'decision':'raw loss > validation-derived client threshold at q=0.99; equality does not alert',
            'calibration':'z=(loss-client validation median)/client validation scale; threshold transform gives identical decisions for all preserved rows',
            'ranking':'Global primary AP/AUROC uses client-calibrated scores; per-client AP/AUROC uses raw loss. No rankings calculated for one-class scenario subsets.',
            'positive_only':'alert_rate = TP/(TP+FN) = Recall; FPR unavailable because no negatives',
            'negative_only':'alert_rate = FP/(FP+TN) = FPR; Recall unavailable because no positives',
            'denominators':'sessions_per_model is fixed session membership per model, not the sum across five seeds or thirty models',
            'uncertainty':'Five-seed sample SD conditional on the same fixed benchmark; not an independent-sample CI',
        },
        'not_performed':['training','model inference','score reversal','threshold fitting or tuning','label reassignment','session resampling','original file mutation'],
        'limits':[
            'This reconstructs a new derivative from preserved score and calibration evidence; it does not recover or authenticate the missing historical per-seed file.',
            'Arithmetic and source-label alignment are verified; label realism, original data generation, data rights and generalisation are not established.',
            'Original validation score arrays were not available in this score export; quantile estimates, medians and scales were not independently refitted.',
            'Figure comparison here covers its numerical input summary; visual inspection of the figure is recorded separately.',
        ],
    }
    (OUT/'Independent_Scenario_Verification.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8')
    print(json.dumps({'status':result['status'],'counts':result['counts'],'old_summary_max_absolute_difference':max_delta,'table_checks':table_checks},indent=2))
    for z in sources.values():z.close()

if __name__=='__main__':
    main()
