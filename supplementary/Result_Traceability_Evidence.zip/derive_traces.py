"""Reconstruct result trace records from frozen scores. No training or inference."""
from pathlib import Path
from zipfile import ZipFile
from collections import defaultdict
import argparse,csv,hashlib,io,json,sys,platform
from datetime import datetime,timezone
import numpy as np
import pandas as pd

P=argparse.ArgumentParser();P.add_argument('--input-dir',type=Path,default=Path(__file__).parent/'inputs');P.add_argument('--output-dir',type=Path,default=Path(__file__).parent/'outputs');A=P.parse_args()
I=A.input_dir;O=A.output_dir;O.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
S=I/'01_Saved_Score_Audit_Inputs_Original.zip';F=I/'02_Final_Evaluation_Original.zip'
def readcsv(b):return pd.read_csv(io.BytesIO(b),keep_default_na=False,float_precision='round_trip')
labels=readcsv((I/'labels.csv').read_bytes());assert labels.session_id.is_unique
labels=labels.set_index('session_id',drop=False)
def ap(y,s):
    y=np.asarray(y,dtype=np.int64);s=np.asarray(s,dtype=np.float64)
    if not (np.any(y==1) and np.any(y==0)):return None
    order=np.argsort(-s,kind='stable');yy=y[order];ss=s[order]
    end=np.r_[np.flatnonzero(np.diff(ss)),len(ss)-1]
    tp=np.cumsum(yy)[end];dp=np.diff(np.r_[0,tp])
    return float(np.sum((dp/np.sum(yy))*(tp/(end+1))))
def counts(g):
    y=g.label.to_numpy(dtype=int);p=g.alert.to_numpy(dtype=bool);n=len(g);pos=int(y.sum());neg=n-pos
    tp=int(np.sum((y==1)&p));fp=int(np.sum((y==0)&p));tn=neg-fp;fn=pos-tp
    assert tp+fp+tn+fn==n
    return dict(sessions=n,positives=pos,negatives=neg,TP=tp,TN=tn,FP=fp,FN=fn,alerts=tp+fp,alert_rate=(tp+fp)/n,FPR=fp/neg if neg else '',recall=tp/pos if pos else '',FNR=fn/pos if pos else '',rate_role='FPR' if pos==0 else 'recall' if neg==0 else 'mixed_class_alert_rate',ranking_metrics_computed=False,ranking_status='NOT_COMPUTED_FOR_DESCRIPTIVE_GROUP')
worst=[];scenario=[];primary_errors=[];comparisons=[];hashes=[];allmeta={};rawrows=0;ties=0;maxapdiff=0.;scenario_comparisons=0;cell_counts=0
with ZipFile(S) as z,ZipFile(F) as fz:
    manifest=json.loads(z.read('audit_export_manifest.json'));expected={x['path']:x for x in manifest['files']}
    for n in z.namelist():
        if n in expected:assert sha(z.read(n))==expected[n]['sha256'],n
    names=sorted(n for n in z.namelist() if n.startswith('scores/') and n.endswith('.csv'));assert len(names)==60
    for member in names:
        stem=Path(member).name.removesuffix('_scores.csv');config,condition,seed,test=stem.split('_',3);seed=int(seed)
        scorebytes=z.read(member);d=readcsv(scorebytes);rawrows+=len(d)
        assert d.session_id.is_unique and set(d.client)=={'C1','C2','C3'}
        assert set(d.partition)=={test} and set(d.label)<={0,1} and np.isfinite(d.loss).all()
        assert len(d)==(2364 if test=='test_held_out' else 645)
        calmember=f'calibrations/{config}_{condition}_{seed}.json';calbytes=z.read(calmember);cal=json.loads(calbytes)
        assert cal['configuration']==config and cal['condition']==condition and cal['training_seed']==seed
        assert cal['fit_partition']=='validation' and cal['test_data_used'] is False and cal['primary_quantile']==.99
        cellmember='cells/'+stem+'.json';cell=json.loads(fz.read(cellmember));q=cell['metrics']['quantiles']['0.99']
        assert cell['checkpoint_sha256']==cal['selected_checkpoint_sha256'] and cell['calibration_sha256']==sha(calbytes)
        mapped=labels.loc[d.session_id].reset_index(drop=True)
        for col in ('partition','primary_class'):assert list(mapped[col])==list(d[col]),(member,col)
        binary=mapped.binary_label.astype(str).str.upper().map({'TRUE':1,'FALSE':0});assert binary.notna().all() and list(binary)==list(d.label)
        resolved=mapped.campaign_id.where(mapped.campaign_id!='',mapped.scenario_id)
        assert list(resolved)==list(d.scenario),(member,'scenario_binding')
        for col in ('legitimate_subtype','threat_family'):d[col]=mapped[col].to_numpy()
        for row in d.itertuples():
            meta=(row.client,row.partition,int(row.label),row.scenario,row.primary_class,row.legitimate_subtype,row.threat_family)
            assert allmeta.setdefault(row.session_id,meta)==meta
        d['threshold']=d.client.map({c:v['thresholds']['0.99'] for c,v in cal['clients'].items()})
        d['alert']=d.loss>d.threshold
        d['calibrated_score']=[(v-cal['clients'][c]['median'])/cal['clients'][c]['scale'] for c,v in zip(d.client,d.loss)]
        aps={};ns={};ps={}
        for c,g in d.groupby('client',sort=True):
            assert cal['clients'][c]['alert_operator']=='>' and cal['clients'][c]['scale']>0
            value=ap(g.label,g.loss);aps[c]=value;ns[c]=len(g);ps[c]=int(g.label.sum())
            original=q['per_client'][c]['AP'];diff=abs(value-original);maxapdiff=max(maxapdiff,diff);assert diff<1e-12
            co=counts(g)
            for name in ('TP','TN','FP','FN','sessions','positives','negatives'):assert co[name]==q['per_client'][c][name],(member,c,name)
            cell_counts+=7
        low=min(aps.values());ids=[c for c,v in aps.items() if v==low];ties+=len(ids)>1
        assert ids==q['worst_client_ids'] and abs(low-q['worst_client_AP'])<1e-12
        worst.append(dict(configuration=config,condition=condition,seed=seed,test=test,C1_AP=aps['C1'],C2_AP=aps['C2'],C3_AP=aps['C3'],worst_AP=low,worst_client_ids=';'.join(ids),tie_count=len(ids),AP_score_representation='raw_loss',AP_status='DEFINED_BOTH_CLASSES',C1_sessions=ns['C1'],C2_sessions=ns['C2'],C3_sessions=ns['C3'],C1_positives=ps['C1'],C2_positives=ps['C2'],C3_positives=ps['C3'],score_member=member,score_sha256=sha(scorebytes),checkpoint_sha256=cal['selected_checkpoint_sha256']))
        oldscenario={r['scenario']:r for r in q['scenario_counts']}
        for scope in ['all_clients','C1','C2','C3']:
            dd=d if scope=='all_clients' else d[d.client==scope]
            for field in ['scenario','primary_class','legitimate_subtype','threat_family']:
                data=dd if field in ('scenario','primary_class') else dd[dd[field]!='']
                for group,g in data.groupby(field,sort=True,dropna=False):
                    co=counts(g);r=dict(configuration=config,condition=condition,seed=seed,test=test,scope=scope,group_field=field,group=group,primary_classes=';'.join(sorted(set(g.primary_class))),legitimate_subtypes=';'.join(sorted(set(g.legitimate_subtype)-{''})),threat_families=';'.join(sorted(set(g.threat_family)-{''})),quantile=.99,alert_operator='>',decision_score_representation='raw_loss_vs_client_validation_threshold',threshold_min=float(g.threshold.min()),threshold_max=float(g.threshold.max()),score_member=member,calibration_member=calmember,**co)
                    scenario.append(r)
                    if scope=='all_clients' and field=='scenario':
                        original=oldscenario[group]
                        for k in ('sessions','positives','TP','TN','FP','FN'):assert co[k]==original[k],(member,group,k)
                        scenario_comparisons+=6
                    if scope=='all_clients' and field!='scenario':
                        primary_errors.append(dict(test=test,condition=condition,configuration=config,seed=seed,group_field=field,group=group,raw_median=float(np.median(g.loss)),calibrated_median=float(np.median(g.calibrated_score)),**co))
        globalco=counts(d)
        for k in ('sessions','positives','negatives','TP','TN','FP','FN'):assert globalco[k]==q['global'][k]
        cell_counts+=7
        hashes.extend([dict(archive=S.name,member=member,sha256=sha(scorebytes)),dict(archive=S.name,member=calmember,sha256=sha(calbytes)),dict(archive=F.name,member=cellmember,sha256=sha(fz.read(cellmember)))])
assert rawrows==90270 and len(allmeta)==3009
def writecsv(name,rows):
    with (O/name).open('w',encoding='utf-8',newline='') as f:
        wr=csv.DictWriter(f,fieldnames=list(rows[0]));wr.writeheader();wr.writerows(rows)
writecsv('worst_client_by_seed_reconstructed.csv',worst)
writecsv('scenario_error_by_seed_reconstructed.csv',scenario)
writecsv('class_error_by_seed_reconstructed.csv',primary_errors)
summ=[]
df=pd.DataFrame(primary_errors)
for key,g in df.groupby(['test','condition','configuration','group_field','group'],sort=True):
    assert len(g)==5 and len(set(g.sessions))==1
    r=dict(zip(['test','condition','configuration','group_field','group'],key));r.update(n_seeds=5,sessions_per_model=int(g.sessions.iloc[0]))
    for out,col in [('TP','TP'),('TN','TN'),('FP','FP'),('FN','FN'),('mean_alert_rate','alert_rate'),('raw_median','raw_median'),('calibrated_median','calibrated_median')]:
        r[out+'_mean_across_seeds']=float(g[col].mean());r[out+'_sd_across_seeds']=float(g[col].std(ddof=1))
    summ.append(r)
writecsv('descriptive_class_error_summary_reconstructed.csv',summ)
original=readcsv((I/'descriptive_class_error_summary_original.csv').read_bytes());new=pd.DataFrame(summ)
keys=['test','condition','configuration','group_field','group'];merged=original.merge(new,on=keys,suffixes=('_original','_new'),validate='one_to_one');assert len(merged)==len(original)==len(new)
maxsummarydiff=0.
for col in [c for c in original.columns if c not in keys]:
    dif=np.abs(merged[col+'_original'].astype(float)-merged[col+'_new'].astype(float));mx=float(dif.max());maxsummarydiff=max(maxsummarydiff,mx);assert mx<1e-10,(col,mx)
    comparisons.append(dict(check='preserved_descriptive_summary',field=col,rows=len(merged),max_absolute_difference=mx,status='PASS'))
W=pd.DataFrame(worst);ws=[]
for (condition,config,test),g in W.groupby(['condition','configuration','test'],sort=True):
    r=dict(condition=condition,configuration=config,test=test,n_seeds=len(g))
    for col in ['C1_AP','C2_AP','C3_AP','worst_AP']:r[col+'_mean']=float(g[col].mean());r[col+'_sample_sd']=float(g[col].std(ddof=1))
    ws.append(r)
writecsv('client_AP_summary_reconstructed.csv',ws)
tables=json.loads((I/'manuscript_tables.json').read_text())
for row in tables['Table 4.8'][1:]:
    condition='reference' if row[0]=='Reference' else 'noniid';g=next(x for x in ws if x['condition']==condition and x['configuration']==row[1] and x['test']=='test_held_out')
    for j,col in enumerate(['C1_AP','C2_AP','C3_AP','worst_AP'],2):
        actual=f"{g[col+'_mean']:.4f} ± {g[col+'_sample_sd']:.4f}";assert actual==row[j],(row,actual)
        comparisons.append(dict(check='Word_Table_4_8',condition=condition,configuration=row[1],field=col,expected=row[j],actual=actual,status='PASS'))
selectors=[('test_held_out','routine_legitimate'),('test_held_out','unusual_legitimate'),('test_known','unusual_legitimate')]
for row,(test,group) in zip(tables['Table 4.10'][1:],selectors):
    for col,condition in [(2,'reference'),(3,'noniid')]:
        g=new[(new.test==test)&(new.condition==condition)&(new.configuration=='C')&(new.group_field=='primary_class')&(new.group==group)].iloc[0]
        assert int(g.sessions_per_model)==int(row[1].replace(',',''))
        actual=f'{100*g.mean_alert_rate_mean_across_seeds:.2f} ± {100*g.mean_alert_rate_sd_across_seeds:.2f}';assert actual==row[col],(row,actual)
        comparisons.append(dict(check='Word_Table_4_10',test=test,group=group,condition=condition,expected=row[col],actual=actual,status='PASS'))
receipt=dict(status='PASS',record_type='NEW_POST_TEST_DERIVATION_FROM_PRESERVED_OUTPUTS',created_utc=datetime.now(timezone.utc).isoformat(),training_performed=False,inference_performed=False,thresholds_refitted=False,score_reversal=False,historical_missing_files_recovered=False,score_files=60,calibration_files=30,evaluations=60,score_rows=rawrows,distinct_test_sessions=3009,primary_worst_client_rows=int((W.test=='test_held_out').sum()),all_test_worst_client_rows=len(worst),client_AP_values=3*len(worst),minimum_tie_cases=ties,scenario_trace_rows=len(scenario),class_by_seed_rows=len(primary_errors),class_summary_rows=len(summ),original_cell_count_fields_matched=cell_counts,original_scenario_count_fields_matched=scenario_comparisons,maximum_client_AP_difference=maxapdiff,maximum_class_summary_difference=maxsummarydiff,word_table_4_8_fields=24,word_table_4_10_fields=6,AP_formula='Non-interpolated average precision; tied raw scores grouped before precision-recall increments; no trapezoidal interpolation.',worst_client_rule='Minimum raw-score AP among C1/C2/C3 within each model/condition/seed/test; retain every exact tied minimum.',decision_rule='raw loss > saved client validation threshold at q=0.99',group_denominator='Sessions per model/group/scope; separate grouping families overlap and must not be added together.',uncertainty='Mean and sample SD across the five fixed seeds; repeated sessions are not independent samples.',python=sys.version,numpy=np.__version__,pandas=pd.__version__,platform=platform.platform(),inputs=[dict(file=p.name,bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(I.iterdir()) if p.is_file()])
(O/'Derivation_Receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
(O/'Numerical_Reconciliation.json').write_text(json.dumps(comparisons,ensure_ascii=False,indent=2),encoding='utf-8')
(O/'Source_Member_Hashes.json').write_text(json.dumps(hashes,indent=2),encoding='utf-8')
print(json.dumps({k:receipt[k] for k in ['status','score_rows','all_test_worst_client_rows','scenario_trace_rows','class_summary_rows','maximum_client_AP_difference','maximum_class_summary_difference','word_table_4_8_fields','word_table_4_10_fields']},indent=2))
