from pathlib import Path
from zipfile import ZipFile
from lxml import etree as E
import shutil,json,hashlib
R=Path(__file__).parent;I=R/'inputs';I.mkdir(exist_ok=True)
B=Path('C:/Users/RNO/Downloads/review_FL')
source=Path('C:/Users/RNO/Desktop/Coureses/P1/final_content_review_2026_10_12/delivery/Research_Report_Chapters_1_to_6_v1_13_Clean_Reading_20261012.docx')
sha=lambda b:hashlib.sha256(b).hexdigest();lineage=[]
for n in ['01_Saved_Score_Audit_Inputs_Original.zip','02_Final_Evaluation_Original.zip']:
 shutil.copyfile(B/n,I/n);lineage.append(dict(source=str(B/n),destination=n,sha256=sha((I/n).read_bytes())))
extracts=[('04_EHR_FL_Benchmark_Release_Candidate_v1_0.zip','EHR_FL_Benchmark_Release_Candidate_v1_0/data/labels.csv','labels.csv'),('ehr-fl-secagg-study-main.zip','ehr-fl-secagg-study-main/analysis/final_score_audit/descriptive_class_error_summary.csv','descriptive_class_error_summary_original.csv'),('ehr-fl-secagg-study-main.zip','ehr-fl-secagg-study-main/executed/EHR_FL_Main_Experiments_Package_v1_0_3/main_study/evaluation.py','evaluation_original.py')]
for archive,member,out in extracts:
 with ZipFile(B/archive) as z:data=z.read(member)
 (I/out).write_bytes(data);lineage.append(dict(source=str(B/archive),source_archive_sha256=sha((B/archive).read_bytes()),member=member,destination=out,sha256=sha(data)))
W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
txt=lambda x:''.join(x.itertext()) if False else ''.join(t.text or '' for t in x.iter(W+'t'))
with ZipFile(source) as z:doc=E.fromstring(z.read('word/document.xml'))
tables={};pending=None
for el in doc.find(W+'body'):
 if el.tag==W+'p':
  t=txt(el)
  for name in ['Table 4.8','Table 4.10']:
   if t.startswith(name+' ' ) or t.startswith(name+'.'):pending=name
 elif el.tag==W+'tbl' and pending:
  tables[pending]=[[txt(c) for c in row.findall(W+'tc')] for row in el.findall(W+'tr')];pending=None
assert set(tables)=={'Table 4.8','Table 4.10'},tables
(I/'manuscript_tables.json').write_text(json.dumps(tables,ensure_ascii=False,indent=2),encoding='utf-8')
lineage.append(dict(source=str(source),sha256=sha(source.read_bytes()),destination='manuscript_tables.json',captions=list(tables)))
(I/'Input_Lineage.json').write_text(json.dumps(lineage,indent=2),encoding='utf-8')
plan=json.loads((R/'Execution_Plan.json').read_text());plan['steps'][0].update(step='[100%] Locate frozen score, label and calibration sources and establish derivation contracts',status='completed');plan['steps'][1].update(step='[70%] Reconstruct both trace files and independently reconcile reported results',status='in_progress');(R/'Execution_Plan.json').write_text(json.dumps(plan,indent=2))
print(json.dumps(tables,ensure_ascii=False,indent=2))
