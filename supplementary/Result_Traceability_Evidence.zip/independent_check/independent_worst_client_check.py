"""Read preserved sources and independently reconstruct held-out client AP.

No model loading, training, inference, calibration fitting or threshold selection.
Uses a tie-grouped exact-rational AP calculation rather than importing the study
implementation. Outputs are newly derived records, not recovered historical files.
"""
from __future__ import annotations

import ast
import csv
from collections import Counter, defaultdict
from fractions import Fraction
import hashlib
from io import StringIO
import json
import math
from pathlib import Path
import re
import statistics
import sys
import xml.etree.ElementTree as ET
from zipfile import ZipFile

BASE = Path('C:/Users/RNO/Downloads/review_FL')
OUT = Path(__file__).resolve().parent
SCORE_PATH = BASE/'01_Saved_Score_Audit_Inputs_Original.zip'
DUPLICATE_PATH = BASE/'Final_Score_Audit_Evidence_20260909T142009Z_2ad79bf6.zip'
BENCH_PATH = BASE/'04_EHR_FL_Benchmark_Release_Candidate_v1_0.zip'
CODE_PATH = BASE/'ehr-fl-secagg-study-main.zip'
REPORT_PATH = BASE/'Final_Evaluation_Report_Review_20260909T142009Z_2ad79bf6.json'
DOC_PATH = Path('C:/Users/RNO/Desktop/Coureses/P1/final_content_review_2026_10_12/delivery/Research_Report_Chapters_1_to_6_v1_13_Clean_Reading_20261012.docx')
SEEDS = (11,29,47,71,97)
CLIENTS = ('C1','C2','C3')
TOL = 1e-12

def sha(data):
    return hashlib.sha256(data).hexdigest()

def rows(data):
    return list(csv.DictReader(StringIO(data.decode('utf-8-sig'))))

def dump_json(name, value):
    (OUT/name).write_text(json.dumps(value,indent=2,ensure_ascii=False,allow_nan=False),encoding='utf-8')

def dump_csv(name, values):
    with (OUT/name).open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(values[0]))
        writer.writeheader();writer.writerows(values)

def ap_exact(labels,scores):
    """Sum precision at each distinct descending score, weighted by recall gain.

    Equal raw float scores enter one group; no arbitrary ordering within ties.
    Positive label is 1. Higher loss is more positive. No interpolation/trapezoids.
    """
    assert len(labels)==len(scores) and set(labels)=={0,1}
    groups=defaultdict(lambda:[0,0])
    for label,score in zip(labels,scores):
        assert math.isfinite(score)
        groups[score][0]+=label;groups[score][1]+=1
    positives=sum(labels);tp=0;n=0;result=Fraction(0)
    for score in sorted(groups,reverse=True):
        added_positive,added_n=groups[score]
        tp+=added_positive;n+=added_n
        result+=Fraction(added_positive,positives)*Fraction(tp,n)
    return result, len(groups), sum(count[1]>1 for count in groups.values())

def table48_from_docx():
    w={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
    with ZipFile(DOC_PATH) as z:
        root=ET.fromstring(z.read('word/document.xml'))
    children=list(root.find('w:body',w));caption=False
    for item in children:
        text=''.join(t.text or '' for t in item.findall('.//w:t',w))
        if item.tag.endswith('}p') and text.startswith('Table 4.8:'):
            caption=True;continue
        if caption and item.tag.endswith('}tbl'):
            table=[[ ''.join(t.text or '' for t in cell.findall('.//w:t',w)) for cell in row.findall('w:tc',w)] for row in item.findall('w:tr',w)]
            # The list of tables repeats the caption before unrelated tables.
            if table and table[0]==['Condition','Model','C1 AP','C2 AP','C3 AP','Worst AP']:
                return table
    raise AssertionError('Table 4.8 not found')

def main():
    source_checks=[]
    with ZipFile(CODE_PATH) as code:
        pipeline_name=next(n for n in code.namelist() if n.endswith('app/ehr_preprocessing/pipeline.py'))
        pipeline=code.read(pipeline_name)
        clientmap=None
        for node in ast.parse(pipeline.decode('utf-8-sig')).body:
            if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CLIENTS' for t in node.targets):
                clientmap=ast.literal_eval(node.value)
        assert set(clientmap)==set(CLIENTS)
        revmap={v:k for k,v in clientmap.items()}
        eval_name=next(n for n in code.namelist() if n.endswith('main_study/evaluation.py'))
        evaluation=code.read(eval_name)
        source_checks.extend([{'archive':str(CODE_PATH),'member':pipeline_name,'sha256':sha(pipeline)}, {'archive':str(CODE_PATH),'member':eval_name,'sha256':sha(evaluation)}])
        (OUT/'Inspected_Study_Evaluation_Source.txt').write_bytes(evaluation)
    with ZipFile(BENCH_PATH) as benchmark:
        label_name=next(n for n in benchmark.namelist() if n.endswith('/data/labels.csv'))
        label_bytes=benchmark.read(label_name)
        labels=rows(label_bytes)
        source_checks.append({'archive':str(BENCH_PATH),'member':label_name,'sha256':sha(label_bytes),'rows':len(labels)})
    assert len(labels)==17464 and len({r['session_id'] for r in labels})==17464
    source_by_id={r['session_id']:r for r in labels}
    expected_held={r['session_id'] for r in labels if r['partition']=='test_held_out'}
    assert len(expected_held)==2364
    report=json.loads(REPORT_PATH.read_text(encoding='utf-8-sig'))
    reported={(r['configuration'],r['condition'],r['seed']):r for r in report['per_seed_primary_results'] if r['test']=='test_held_out'}
    assert len(reported)==30 and report['per_client_ranking']=='raw'
    client_rows=[];minimum_rows=[];maximum_ap_delta=0.;maximum_minimum_delta=0.;compared_source_rows=0;used_members=[]
    with ZipFile(SCORE_PATH) as scores:
        manifest=json.loads(scores.read('audit_export_manifest.json'))
        manifest_by_member={r['path']:r for r in manifest['files']}
        integrity=json.loads(scores.read('source_integrity.json'))
        assert next(r['sha256'] for r in integrity['files'] if r['file']=='labels.csv')==sha(label_bytes)
        assert len([n for n in scores.namelist() if n.startswith('scores/') and n.endswith('.csv')])==60
        held_members=sorted(n for n in scores.namelist() if n.endswith('_test_held_out_scores.csv'))
        assert len(held_members)==30
        for member in held_members:
            match=re.fullmatch(r'scores/([ABC])_(reference|noniid)_(11|29|47|71|97)_test_held_out_scores.csv',member)
            assert match,member
            configuration,condition,seed=match[1],match[2],int(match[3]);stem=f'{configuration}_{condition}_{seed}'
            payload=scores.read(member)
            assert sha(payload)==manifest_by_member[member]['sha256']
            assert len(payload)==manifest_by_member[member]['bytes']
            data=rows(payload)
            assert len(data)==2364 and len({r['session_id'] for r in data})==2364
            assert {r['session_id'] for r in data}==expected_held
            calibration_member=f'calibrations/{stem}.json';calibration_bytes=scores.read(calibration_member)
            assert sha(calibration_bytes)==manifest_by_member[calibration_member]['sha256']
            cal=json.loads(calibration_bytes)
            assert (cal['configuration'],cal['condition'],cal['training_seed'])==(configuration,condition,seed)
            assert cal['fit_partition']=='validation' and cal['test_data_used'] is False
            assert sha(calibration_bytes)==reported[(configuration,condition,seed)]['calibration_sha256']
            groups=defaultdict(list)
            for r in data:
                original=source_by_id[r['session_id']]
                expected=(revmap[original['hospital_id']],original['partition'],str(int(original['binary_label']=='TRUE')),original['scenario_id'],original['primary_class'])
                assert tuple(r[k] for k in ('client','partition','label','scenario','primary_class'))==expected
                assert (r['label']=='1')==(r['primary_class']=='threat')
                groups[r['client']].append(r)
            assert set(groups)==set(CLIENTS)
            fractions={};aps={}
            for client in CLIENTS:
                group=groups[client];y=[int(r['label']) for r in group];raw=[float(r['loss']) for r in group]
                assert all(v>=0 for v in raw)
                assert cal['clients'][client]['scale']>0
                exact,n_distinct,n_tied_groups=ap_exact(y,raw);ap=float(exact)
                calibrated=[(v-cal['clients'][client]['median'])/cal['clients'][client]['scale'] for v in raw]
                z_exact,_,_=ap_exact(y,calibrated)
                assert exact==z_exact,('within-client affine ranking changed',stem,client)
                reported_ap=reported[(configuration,condition,seed)]['per_client_metrics'][client]['AP']
                delta=abs(ap-reported_ap);maximum_ap_delta=max(maximum_ap_delta,delta);assert delta<=TOL
                fractions[client]=exact;aps[client]=ap
                expected_n={'C1':784,'C2':806,'C3':774}[client]
                assert len(group)==expected_n and sum(y)==63
                client_rows.append({'configuration':configuration,'condition':condition,'seed':seed,'test':'test_held_out','client':client,'sessions':len(group),'positives':sum(y),'negatives':len(y)-sum(y),'raw_AP':ap,'reported_AP':reported_ap,'absolute_difference':delta,'distinct_raw_scores':n_distinct,'tied_score_groups':n_tied_groups,'within_client_calibrated_AP_equal':True,'score_member':member,'score_member_sha256':sha(payload)})
            exactmin=min(fractions.values());minimum=float(exactmin)
            worst=[client for client in CLIENTS if fractions[client]==exactmin]
            original_record=reported[(configuration,condition,seed)]
            delta=abs(minimum-original_record['worst_client_AP']);maximum_minimum_delta=max(maximum_minimum_delta,delta);assert delta<=TOL
            assert worst==original_record['worst_client_ids']
            minimum_rows.append({'configuration':configuration,'condition':condition,'seed':seed,'test':'test_held_out','C1_AP':aps['C1'],'C2_AP':aps['C2'],'C3_AP':aps['C3'],'worst_client_AP':minimum,'worst_client_ids':'|'.join(worst),'worst_client_tie_count':len(worst),'exact_AP_tie_definition':'exact equality of tie-grouped rational AP; no display rounding','reported_worst_client_AP':original_record['worst_client_AP'],'reported_worst_client_ids':'|'.join(original_record['worst_client_ids']),'reported_AP_absolute_difference':delta,'score_member':member,'score_member_sha256':sha(payload),'calibration_member':calibration_member,'calibration_member_sha256':sha(calibration_bytes)})
            compared_source_rows+=len(data)
            used_members.extend([{'member':member,'sha256':sha(payload),'rows':len(data)},{'member':calibration_member,'sha256':sha(calibration_bytes),'rows':None}])
    table=table48_from_docx();assert len(table)==7
    tablekeys={('Reference' if condition=='reference' else 'Non-IID',config):(condition,config) for condition in ('reference','noniid') for config in 'ABC'}
    summaries=[];rounding_checks=[]
    for table_row in table[1:]:
        condition,configuration=tablekeys[(table_row[0],table_row[1])]
        group=sorted([r for r in minimum_rows if (r['condition'],r['configuration'])==(condition,configuration)],key=lambda r:r['seed'])
        assert [r['seed'] for r in group]==list(SEEDS)
        record={'configuration':configuration,'condition':condition,'test':'test_held_out','n_seeds':5}
        for client in CLIENTS:
            vals=[r[f'{client}_AP'] for r in group]
            record[f'{client}_mean_AP']=statistics.mean(vals);record[f'{client}_sample_SD']=statistics.stdev(vals)
        minima=[r['worst_client_AP'] for r in group]
        record['mean_of_within_seed_minima']=statistics.mean(minima)
        record['sample_SD_of_within_seed_minima']=statistics.stdev(minima)
        record['minimum_of_client_means']=min(record[f'{c}_mean_AP'] for c in CLIENTS)
        record['mean_of_minima_minus_minimum_of_means']=record['mean_of_within_seed_minima']-record['minimum_of_client_means']
        record['worst_client_frequency']=dict(Counter(c for r in group for c in r['worst_client_ids'].split('|')))
        record['tied_seed_count']=sum(r['worst_client_tie_count']>1 for r in group)
        for j,client in enumerate(CLIENTS):
            actual=f"{record[f'{client}_mean_AP']:.4f} ± {record[f'{client}_sample_SD']:.4f}"
            assert actual==table_row[j+2],(condition,configuration,client,actual,table_row[j+2])
            rounding_checks.append({'condition':condition,'configuration':configuration,'column':client,'computed_display':actual,'manuscript_display':table_row[j+2],'status':'PASS'})
        actual=f"{record['mean_of_within_seed_minima']:.4f} ± {record['sample_SD_of_within_seed_minima']:.4f}"
        assert actual==table_row[5],(condition,configuration,actual,table_row[5])
        rounding_checks.append({'condition':condition,'configuration':configuration,'column':'Worst AP','computed_display':actual,'manuscript_display':table_row[5],'status':'PASS'})
        summaries.append(record)
    dump_csv('Independent_HeldOut_Client_AP.csv',client_rows)
    dump_csv('Independent_HeldOut_Worst_Client_Per_Seed.csv',minimum_rows)
    dump_json('Independent_Table_4_8_Summary.json',summaries)
    dump_json('Independent_Table_4_8_Rounding_Checks.json',rounding_checks)
    dump_json('Source_Member_Provenance.json',{'source_members':source_checks,'used_score_and_calibration_members':used_members,'report_path':str(REPORT_PATH),'report_sha256':sha(REPORT_PATH.read_bytes()),'manuscript_path':str(DOC_PATH),'manuscript_sha256':sha(DOC_PATH.read_bytes()),'client_map_from_preserved_pipeline':clientmap})
    status={'status':'PASS','purpose':'New derived traceability reconstruction from preserved scores and source labels; not recovery of historical filenames','python_executable':sys.executable,'python_version':sys.version,'script_sha256':sha(Path(__file__).read_bytes()),'score_zip_path':str(SCORE_PATH),'score_zip_sha256':sha(SCORE_PATH.read_bytes()),'duplicate_zip_path':str(DUPLICATE_PATH),'duplicate_zip_sha256':sha(DUPLICATE_PATH.read_bytes()),'duplicate_archives_are_byte_identical':SCORE_PATH.read_bytes()==DUPLICATE_PATH.read_bytes(),'benchmark_zip_path':str(BENCH_PATH),'benchmark_zip_sha256':sha(BENCH_PATH.read_bytes()),'metric_semantics':'Per-client raw-loss noninterpolated AP; label 1 threat; higher loss positive; group tied scores; retain every exact worst-client AP tie within each seed. Table 4.8 is mean and sample SD of within-seed minima.','thresholds_enter_AP':False,'held_out_score_files':30,'held_out_score_rows':compared_source_rows,'distinct_held_out_sessions':len(expected_held),'client_AP_rows':len(client_rows),'worst_client_seed_rows':len(minimum_rows),'summary_rows':len(summaries),'table_4_8_display_checks':len(rounding_checks),'worst_client_AP_tied_seed_rows':sum(r['worst_client_tie_count']>1 for r in minimum_rows),'max_client_AP_abs_difference_vs_preserved_report':maximum_ap_delta,'max_worst_AP_abs_difference_vs_preserved_report':maximum_minimum_delta,'comparison_absolute_tolerance':TOL,'source_label_membership_and_metadata_exact':True,'within_client_positive_affine_calibration_ranking_equal':True,'training_performed':False,'model_loaded':False,'inference_performed':False,'thresholds_fitted_or_changed':False,'original_sources_modified':False}
    dump_json('Independent_Check_Receipt.json',status)
    print(json.dumps(status,indent=2))
    print('\nTABLE 4.8 SUMMARIES')
    for s in summaries:
        print(s['condition'],s['configuration'],f"{s['mean_of_within_seed_minima']:.12f} ± {s['sample_SD_of_within_seed_minima']:.12f}", 'min(client means)=',s['minimum_of_client_means'],'worst client frequencies=',s['worst_client_frequency'])

if __name__=='__main__':
    main()
