"""Read-only independent comparison of canonical reconstruction and original records."""
import csv, hashlib, json, sys
from collections import defaultdict
from io import StringIO
from pathlib import Path
from zipfile import ZipFile
from independent_worst_client_check import ap_exact

ROOT=Path('C:/Users/RNO/Desktop/Coureses/P1/result_trace_completion_2026_10_12')
OUT=ROOT/'independent_check'
BASE=Path('C:/Users/RNO/Downloads/review_FL')
CANON=ROOT/'outputs/worst_client_by_seed_reconstructed.csv'
REPORT=BASE/'Final_Evaluation_Report_Review_20260909T142009Z_2ad79bf6.json'
SCORES=BASE/'01_Saved_Score_Audit_Inputs_Original.zip'
BENCH=BASE/'04_EHR_FL_Benchmark_Release_Candidate_v1_0.zip'
TOL=1e-12
def sha(b): return hashlib.sha256(b).hexdigest()
def loadcsv(b): return list(csv.DictReader(StringIO(b.decode('utf-8-sig'))))
def key(r): return (r['configuration'],r['condition'],int(r['seed']),r['test'])

canonical=loadcsv(CANON.read_bytes());assert len(canonical)==60
assert len({key(r) for r in canonical})==60
report=json.loads(REPORT.read_text(encoding='utf-8-sig'))
original={key(r):r for r in report['per_seed_primary_results']}
assert set(original)=={key(r) for r in canonical}
primary={key(r):r for r in loadcsv((OUT/'Independent_HeldOut_Worst_Client_Per_Seed.csv').read_bytes())}
assert len(primary)==30
provenance=json.loads((OUT/'Source_Member_Provenance.json').read_text(encoding='utf-8'))
revmap={v:k for k,v in provenance['client_map_from_preserved_pipeline'].items()}
with ZipFile(BENCH) as z:
    labelname=next(n for n in z.namelist() if n.endswith('/data/labels.csv'))
    labels={r['session_id']:r for r in loadcsv(z.read(labelname))}
expected={part:{sid for sid,r in labels.items() if r['partition']==part} for part in ('test_held_out','test_known')}
results=[];all_source_rows=0;max_original=0.;max_independent=0.;max_primary=0.
with ZipFile(SCORES) as z:
    manifest={r['path']:r for r in json.loads(z.read('audit_export_manifest.json'))['files']}
    for c in canonical:
        k=key(c);o=original[k];payload=z.read(c['score_member']);data=loadcsv(payload)
        assert sha(payload)==c['score_sha256']==manifest[c['score_member']]['sha256']
        assert c['checkpoint_sha256']==o['checkpoint_sha256']
        assert len({r['session_id'] for r in data})==len(data)
        assert {r['session_id'] for r in data}==expected[c['test']]
        assert c['AP_score_representation']=='raw_loss' and c['AP_status']=='DEFINED_BOTH_CLASSES'
        groups=defaultdict(list)
        for r in data:
            s=labels[r['session_id']]
            meta=(revmap[s['hospital_id']],s['partition'],str(int(s['binary_label']=='TRUE')),s['scenario_id'],s['primary_class'])
            assert tuple(r[x] for x in ('client','partition','label','scenario','primary_class'))==meta
            groups[r['client']].append(r)
        exact={};deltas_original=[];deltas_independent=[]
        for client in ('C1','C2','C3'):
            group=groups[client];y=[int(r['label']) for r in group]
            exact[client]=ap_exact(y,[float(r['loss']) for r in group])[0]
            cv=float(c[f'{client}_AP']);ov=o['per_client_metrics'][client]['AP'];iv=float(exact[client])
            deltas_original.append(abs(cv-ov));deltas_independent.append(abs(cv-iv))
            assert abs(cv-ov)<=TOL and abs(cv-iv)<=TOL
            assert int(c[f'{client}_sessions'])==len(group)==o['per_client_metrics'][client]['sessions']
            assert int(c[f'{client}_positives'])==sum(y)==o['per_client_metrics'][client]['positives']
        minimum=min(exact.values());ids=[x for x in ('C1','C2','C3') if exact[x]==minimum]
        assert c['worst_client_ids'].split('|')==ids==o['worst_client_ids']
        assert int(c['tie_count'])==len(ids)
        deltas_original.append(abs(float(c['worst_AP'])-o['worst_client_AP']))
        deltas_independent.append(abs(float(c['worst_AP'])-float(minimum)))
        assert max(deltas_original)<=TOL and max(deltas_independent)<=TOL
        pd=None
        if k in primary:
            p=primary[k]
            pd=max([abs(float(c[f'{x}_AP'])-float(p[f'{x}_AP'])) for x in ('C1','C2','C3')]+[abs(float(c['worst_AP'])-float(p['worst_client_AP']))])
            assert pd<=TOL and p['worst_client_ids']==c['worst_client_ids'] and int(p['worst_client_tie_count'])==int(c['tie_count'])
            max_primary=max(max_primary,pd)
        max_original=max(max_original,max(deltas_original));max_independent=max(max_independent,max(deltas_independent))
        all_source_rows+=len(data)
        results.append({'configuration':k[0],'condition':k[1],'seed':k[2],'test':k[3],'status':'PASS','score_member':c['score_member'],'score_member_sha256':sha(payload),'sessions':len(data),'canonical_worst_client_ids':ids,'tie_count':len(ids),'max_abs_delta_vs_original_record':max(deltas_original),'max_abs_delta_vs_independent_formula':max(deltas_independent),'max_abs_delta_vs_earlier_held_out_check':pd})
receipt={'status':'PASS','scope':'Canonical worst-client reconstruction vs preserved original evaluation records and independent exact-rational AP calculation for both test sets; primary held-out rows additionally checked against prior independent output','canonical_path':str(CANON),'canonical_sha256':sha(CANON.read_bytes()),'original_report_path':str(REPORT),'original_report_sha256':sha(REPORT.read_bytes()),'score_zip_path':str(SCORES),'score_zip_sha256':sha(SCORES.read_bytes()),'script_sha256':sha(Path(__file__).read_bytes()),'python_executable':sys.executable,'total_canonical_rows':len(canonical),'held_out_rows':len(primary),'secondary_known_rows':len(canonical)-len(primary),'independent_client_AP_values_checked':180,'independent_worst_AP_values_checked':60,'saved_score_rows_checked':all_source_rows,'held_out_distinct_sessions':len(expected['test_held_out']),'known_distinct_sessions':len(expected['test_known']),'all_worst_client_ids_exactly_match':True,'all_tie_counts_exactly_match':True,'tied_rows':sum(r['tie_count']>1 for r in results),'max_absolute_difference_vs_original_records':max_original,'max_absolute_difference_vs_independent_formula':max_independent,'max_absolute_difference_vs_previous_primary_independent_check':max_primary,'tolerance':TOL,'no_training_or_inference_or_threshold_changes':True,'original_sources_modified':False,'rows':results}
(OUT/'Cross_Check_Canonical_Worst_Client.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False,allow_nan=False),encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k!='rows'},indent=2))
