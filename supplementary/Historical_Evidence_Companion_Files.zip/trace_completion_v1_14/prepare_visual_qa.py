from pathlib import Path
import json,hashlib,sys
from pypdf import PdfReader
R=Path(__file__).parent;kind=sys.argv[1];d=R/f'qa/render_{kind}_final'
oldpath=R.parent/'final_content_review_2026_10_12/qa/Final_Visual_Coverage.json'
old=json.loads(oldpath.read_text());prior={x.get('SHA256',x.get('sha256')):x for x in old['page_records'] if x['status']=='PASS'}
changed=[];reuse=[]
for p in sorted(d.glob('page-*.png'),key=lambda p:int(p.stem.split('-')[1])):
 page=int(p.stem.split('-')[1]);h=hashlib.sha256(p.read_bytes()).hexdigest()
 if h in prior:reuse.append(dict(page=page,path=str(p),sha256=h,status='PASS',review_mode='EXACT_PNG_SHA256_REUSE',prior_coverage_file=str(oldpath),prior_record=prior[h]))
 else:changed.append(page)
pdf=next(d.glob('*.pdf'));pages=PdfReader(pdf).pages;locations=[]
for i,p in enumerate(pages,1):
 s=p.extract_text() or ''
 for phrase in ['supplementary per-seed record','Per-seed scenario records','Supplementary records reconstructed','reconstructed per-seed record']:
  if phrase in s:locations.append(dict(phrase=phrase,physical_page=i,first_lines=s[:70]))
result=dict(kind=kind,pages=len(pages),changed_pages=changed,approved_reuse=reuse,changed_text_locations=locations)
(R/f'qa/Visual_Reuse_{kind}.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(kind=kind,pages=len(pages),changed_pages=changed,reused=len(reuse),locations=locations),ensure_ascii=False,indent=2))
