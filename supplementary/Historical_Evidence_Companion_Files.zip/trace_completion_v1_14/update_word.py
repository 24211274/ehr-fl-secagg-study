from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from lxml import etree as E
import json,sys,hashlib
from datetime import datetime,timezone
R=Path(__file__).parent;D=R/'delivery';D.mkdir(exist_ok=True)
OLD=R.parent/'final_content_review_2026_10_12/delivery'
SRC=OLD/'Research_Report_Chapters_1_to_6_v1_13_Clean_Reading_20261012.docx'
sys.path.insert(0,str(OLD.parent));from ooxml_helpers import W,txt,replace_text,serial,highlight
NS={'w':W[1:-1]};REL='{http://schemas.openxmlformats.org/package/2006/relationships}';OFF='http://schemas.openxmlformats.org/officeDocument/2006/relationships';CT='{http://schemas.openxmlformats.org/package/2006/content-types}'
with ZipFile(SRC) as z:parts={n:z.read(n) for n in z.namelist()}
source_doc=E.fromstring(parts['word/document.xml']);paras=list(source_doc.iter(W+'p'))
specs=[
 ('4.6','Individual-seed values and the unresolved availability of the historical minimum-client identity file are documented in the Evidence Companion.','The supplementary per-seed record retains all three client AP values and the identities of all clients attaining each minimum (Appendix C.4).','yellow','Replaces the unresolved trace-file status with the verified reconstructed record. The mean of within-seed minima remains unchanged.'),
 ('4.8.1','The Evidence Companion identifies the available A/B/C summaries and the historical individual-seed scenario file that was not located.','Per-seed scenario records retain the counts and denominators underlying the A/B/C summaries (Appendix C.4).','yellow','Reconstructed from preserved scores, labels and frozen validation thresholds; the original historical file was not recovered.'),
 ('C.4','Detailed output indices, constituent client values and unavailable historical file identities are documented in the Evidence Companion.','Supplementary records reconstructed from preserved test scores and labels retain each seed’s client AP values, minimum-client identities and scenario confusion counts. Their AP summaries reproduce Table 4.8; scenario counts computed using the saved validation thresholds reproduce Table 4.10. No model was retrained or threshold refitted. The derivation code and numerical checks accompany the result traceability evidence.','green','Newly documented post-test derivation. Client AP uses raw loss; confusion counts use loss > saved client threshold at q = 0.99. The evidence preserves source hashes, exact values and independent checks.'),
 ('Table C.6 note','The supplied record contains constituent client AP values; a packaged table retaining every within-seed minimum-client identity was not identified in the inspected supplied archives.','The reconstructed per-seed record retains all three client AP values and every client attaining the minimum.','yellow','Updates trace availability only. The five-seed t intervals and the qualification concerning equivalence are unchanged.')
]
changes=[]
for section,old,new,colour,reason in specs:
 found=[(i,p) for i,p in enumerate(paras) if old in txt(p)];assert len(found)==1,(section,len(found))
 i,p=found[0];changes.append(dict(section=section,paragraph_index=i,before=txt(p),after=txt(p).replace(old,new),old_sentence=old,new_sentence=new,highlight=colour,reason=reason))

def tabletext(doc):return [[[txt(c) for c in r.findall(W+'tc')] for r in t.findall(W+'tr')] for t in doc.iter(W+'tbl')]
original_tables=tabletext(source_doc)
outnames={'clean':'Research_Report_Chapters_1_to_6_v1_14_Clean_Reading_20261012.docx','highlighted':'Research_Report_Chapters_1_to_6_v1_14_Result_Trace_Highlighted_20261012.docx'}
for kind,name in outnames.items():
 pp=dict(parts);doc=E.fromstring(parts['word/document.xml']);allp=list(doc.iter(W+'p'));comments=E.Element(W+'comments',nsmap={'w':W[1:-1]})
 for cid,change in enumerate(changes):
  p=allp[change['paragraph_index']];assert txt(p)==change['before'];replace_text(p,change['after'],change['highlight'] if kind=='highlighted' else None)
  if change['section']=='C.4':
   # Link only the final evidence phrase, preserving all preceding runs and formatting.
   phrase='result traceability evidence';found=False
   for node in list(p.iter(W+'t')):
    if phrase in (node.text or ''):
     run=node.getparent();s=node.text;prefix,tail=s.split(phrase,1);node.text=prefix
     link=E.Element(W+'hyperlink',{'{'+OFF+'}id':'rIdResultTraceEvidence'});lr=E.SubElement(link,W+'r');pr=E.SubElement(lr,W+'rPr');E.SubElement(pr,W+'rStyle',{W+'val':'Hyperlink'});E.SubElement(lr,W+'t').text=phrase
     if kind=='highlighted':highlight(lr,'cyan')
     pos=list(p).index(run);p.insert(pos+1,link)
     if tail:
      tr=E.Element(W+'r');E.SubElement(tr,W+'t').text=tail;p.insert(pos+2,tr)
     found=True;break
   assert found
  if kind=='highlighted':
   start=E.Element(W+'commentRangeStart',{W+'id':str(cid)});end=E.Element(W+'commentRangeEnd',{W+'id':str(cid)});p.insert(1 if p.find(W+'pPr') is not None else 0,start);p.append(end)
   ref=E.SubElement(p,W+'r');E.SubElement(ref,W+'commentReference',{W+'id':str(cid)})
   c=E.SubElement(comments,W+'comment',{W+'id':str(cid),W+'author':'Research review',W+'date':datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')});cp=E.SubElement(c,W+'p');cr=E.SubElement(cp,W+'r');E.SubElement(cr,W+'t').text=change['reason']
  assert txt(p)==change['after']
 assert tabletext(doc)==original_tables
 pp['word/document.xml']=serial(doc);rels=E.fromstring(pp['word/_rels/document.xml.rels']);E.SubElement(rels,REL+'Relationship',Id='rIdResultTraceEvidence',Type=OFF+'/hyperlink',Target='Result_Traceability_Evidence.zip',TargetMode='External')
 if kind=='highlighted':
  pp['word/comments.xml']=serial(comments);E.SubElement(rels,REL+'Relationship',Id='rIdResultTraceComments',Type=OFF+'/comments',Target='comments.xml');ct=E.fromstring(pp['[Content_Types].xml']);E.SubElement(ct,CT+'Override',PartName='/word/comments.xml',ContentType='application/vnd.openxmlformats-officedocument.wordprocessingml.comments+xml');pp['[Content_Types].xml']=serial(ct)
 pp['word/_rels/document.xml.rels']=serial(rels)
 with ZipFile(D/name,'w',ZIP_DEFLATED) as z:
  for n,b in pp.items():z.writestr(n,b)
(R/'Word_Changes.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2),encoding='utf-8')
plan=json.loads((R/'Execution_Plan.json').read_text());plan['steps'][1].update(step='[100%] Reconstruct both trace files and independently reconcile reported results',status='completed');plan['steps'][2].update(step='[60%] Update Word locally with highlighted changes and preserve evidence',status='in_progress');(R/'Execution_Plan.json').write_text(json.dumps(plan,indent=2))
print(json.dumps(dict(outputs=outnames,changed_paragraphs=len(changes),tables_preserved=len(original_tables)),indent=2))
