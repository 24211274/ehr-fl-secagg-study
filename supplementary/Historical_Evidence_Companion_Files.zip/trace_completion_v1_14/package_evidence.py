from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import shutil,json,hashlib
R=Path(__file__).parent;D=R/'delivery';OLD=R.parent/'final_content_review_2026_10_12/delivery'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['ME06_Evidence.zip','Security_Validation_Evidence.zip','SV05_Repair_Evidence.zip','Literature_Refresh_ME04_ME05_20261011.zip']:
 shutil.copyfile(OLD/name,D/name);assert sha(OLD/name)==sha(D/name)
for name in ['worst_client_by_seed_reconstructed.csv','scenario_error_by_seed_reconstructed.csv']:
 shutil.copyfile(R/'outputs'/name,D/name)
requirements=(R/'provenance_ethics_requirements_AR.md').read_text(encoding='utf-8')
requirements=requirements.replace('لم تُرسل مراسلة، ولم يُقدَّم طلب للجامعة، ولم يُعدَّل Word.','لم تُرسل مراسلة ولم يُقدَّم طلب للجامعة. حدّثت النسخة 1.14 تتبع النتائج فقط؛ بقي توثيق المصدر والحقوق والحالة الأخلاقية غير متحقق منه.')
(D/'Data_Provenance_and_Ethics_Requirements_AR.md').write_text(requirements,encoding='utf-8')
shutil.copyfile(R/'README_Result_Traceability.md',D/'README_Result_Traceability.md')

trace_files=[R/'derive_traces.py',R/'prepare_inputs.py',R/'README_Result_Traceability.md',R/'Word_Changes.json',R/'qa/Derivation_Run.log']
for folder in ['inputs','outputs','independent_check','scenario_independent_check']:
 trace_files.extend(p for p in (R/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
trace_files=sorted(set(trace_files));entries=[]
with ZipFile(D/'Result_Traceability_Evidence.zip','w',ZIP_DEFLATED) as z:
 for p in trace_files:
  rel=p.relative_to(R).as_posix();z.write(p,rel);entries.append(dict(path=rel,bytes=p.stat().st_size,sha256=sha(p)))
 z.writestr('Trace_Evidence_Manifest.json',json.dumps(dict(scope='New post-test derivation from preserved outputs; not historical recovery or new training',files=entries),indent=2))
with ZipFile(D/'Result_Traceability_Evidence.zip') as z:
 assert len(z.namelist())==len(set(z.namelist()))
 for e in entries:assert hashlib.sha256(z.read(e['path'])).hexdigest()==e['sha256']
trace_sha=sha(D/'Result_Traceability_Evidence.zip')
oldcomp=(OLD/'Evidence_Companion.md').read_text(encoding='utf-8')
addition=f'''# Evidence Companion — current result traceability supplement

Revision 1.14 supplies newly reconstructed per-seed worst-client and scenario-error records. The derivation uses preserved scores, source labels and frozen validation calibration records; it does not recover the historical missing files or repeat training. All 24 formatted Table 4.8 fields and all six Table 4.10 FPR fields matched. Independent calculations checked all 60 worst-client records and all 44,220 scenario records. Scientific table values and figures are unchanged.

- [Result_Traceability_Evidence.zip](Result_Traceability_Evidence.zip) — SHA-256 `{trace_sha}`. Includes portable derivation code, preserved inputs, full numerical records, original-member hashes, execution receipt and independent checks.
- [worst_client_by_seed_reconstructed.csv](worst_client_by_seed_reconstructed.csv)
- [scenario_error_by_seed_reconstructed.csv](scenario_error_by_seed_reconstructed.csv)
- [Data provenance and ethics requirements](Data_Provenance_and_Ethics_Requirements_AR.md)

The data-generation provenance, source-label validity, use/redistribution rights and institutional ethics status remain unverified to the extent described in the thesis. Numerical reconciliation does not resolve these matters. The prior annotated revision is retained in Evidence_Companion_Files.zip.

The historical record below is preserved verbatim. Earlier statements that trace files were not located describe the audit state before this reconstruction and are not claims about the current supplementary outputs.

---

'''
(D/'Evidence_Companion.md').write_text(addition+oldcomp,encoding='utf-8')
with ZipFile(OLD/'Evidence_Companion_Files.zip') as oldz,ZipFile(D/'Evidence_Companion_Files.zip','w',ZIP_DEFLATED) as newz:
 used=set()
 for n in oldz.namelist():newz.writestr(n,oldz.read(n));used.add(n)
 for p in [OLD/'Research_Report_Chapters_1_to_6_v1_13_Clean_Reading_20261012.docx',OLD/'Research_Report_Chapters_1_to_6_v1_13_Content_Reviewed_Highlighted_20261012.docx',R/'Word_Changes.json']:
  rel=('history_v1_13/' if p.suffix=='.docx' else 'trace_completion_v1_14/')+p.name;assert rel not in used;newz.write(p,rel)
print(json.dumps(dict(trace_archive_sha256=trace_sha,trace_files=len(trace_files),historical_companion_retained=True,original_evidence_archives_unchanged=True),indent=2))
