from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from lxml import etree as E
import json,hashlib,os
R=Path(__file__).parent;D=R/'delivery';Q=R/'qa';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def rows(p):
 v=read(p);return v if isinstance(v,list) else v['rows']
coverage=[]
for kind,records in [('clean',['Visual_QA_Clean_Results.json','Visual_QA_Clean_Appendices.json']),('highlighted',['Visual_QA_Highlighted_Results.json','Visual_QA_Highlighted_Appendices.json'])]:
 reuse=read(Q/f'Visual_Reuse_{kind}.json');allrows={v['page']:v for v in reuse['approved_reuse']}
 for filename in records:
  for v in rows(Q/filename):
   assert v['status']=='PASS' and v['page'] not in allrows
   assert sha(Path(v['path']))==v.get('sha256',v.get('SHA256'))
   v=dict(v,approval_file=filename);allrows[v['page']]=v
 assert set(allrows)==set(range(1,104)),(kind,set(range(1,104))-set(allrows))
 for page,v in sorted(allrows.items()):
  p=Q/f'render_{kind}_final/page-{page}.png';assert sha(p)==v.get('sha256',v.get('SHA256'));coverage.append({**v,'kind':kind})
(Q/'Final_Visual_Coverage.json').write_text(json.dumps(dict(status='PASS',pages_per_copy=103,copy_count=2,total_page_approvals=206,all_page_hashes_verified=True,page_records=coverage),ensure_ascii=False,indent=2),encoding='utf-8')
nav=[read(Q/f'Navigation_Verified_{k}.json') for k in ['clean','annotated']];assert all(v['all_match'] and v['navigation_references']==150 for v in nav)
ind=read(Q/'Independent_Word_Consistency.json');assert ind['status'].startswith('PASS')
docx=sorted(D.glob('*.docx'));assert len(docx)==2
targets=[]
for p in docx:
 with ZipFile(p) as z:
  rels=E.fromstring(z.read('word/_rels/document.xml.rels'))
  for rel in rels:
   if rel.get('TargetMode')=='External':
    target=rel.get('Target');assert (D/target).is_file(),(p.name,target);targets.append(dict(document=p.name,target=target,sha256=sha(D/target)))
 for_source=[p.name,sha(p)]
receipt=read(R/'outputs/Derivation_Receipt.json');assert receipt['status']=='PASS'
for f in ['independent_check/Cross_Check_Canonical_Worst_Client.json','scenario_independent_check/Cross_Check_Canonical_Scenarios.json']:assert read(R/f)['status']=='PASS'
for row in read(R/'inputs/Input_Lineage.json'):
 source=Path(row['source']);expected=row.get('source_archive_sha256',row.get('sha256'));assert sha(source)==expected,source
assert sha(R/'outputs/worst_client_by_seed_reconstructed.csv')==read(R/'independent_check/Cross_Check_Canonical_Worst_Client.json')['canonical_sha256']
assert sha(R/'outputs/scenario_error_by_seed_reconstructed.csv')==read(R/'scenario_independent_check/Cross_Check_Canonical_Scenarios.json')['canonical_sha256']
# Preserve final QA receipts without shipping page images or PDFs.
with ZipFile(D/'Evidence_Companion_Files.zip','a',ZIP_DEFLATED) as z:
 names=set(z.namelist())
 for p in [R/'update_word.py',R/'finalize_delivery.py',R/'package_evidence.py',R/'prepare_visual_qa.py',R/'Word_Changes.json']+list(Q.glob('*.json')):
  rel='trace_completion_v1_14/'+p.relative_to(R).as_posix()
  if rel not in names:z.write(p,rel);names.add(rel)
assert len(names)==len(set(names))
manifest=dict(revision='1.14',verification_status='PASS',word_changes=4,pages_per_copy=103,visual_page_approvals=206,navigation_references_per_copy=150,scientific_tables_preserved=44,scientific_figures_preserved=7,performance_numbers_changed=False,trace_derivation_status=receipt['status'],no_training_or_threshold_refitting=True,data_provenance_and_ethics_status='UNVERIFIED_PENDING_ORIGINAL_DOCUMENTATION',relative_word_targets_verified=targets,files=[dict(name=p.name,bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(D.iterdir()) if p.is_file() and p.name not in ['Delivery_Manifest.json','Research_Report_v1_14_Traceability_Bundle_20261012.zip']])
(D/'Delivery_Manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
bundle=D/'Research_Report_v1_14_Traceability_Bundle_20261012.zip'
with ZipFile(bundle,'w',ZIP_DEFLATED) as z:
 for p in sorted(D.iterdir()):
  if p.is_file() and p!=bundle:z.write(p,p.name)
with ZipFile(bundle) as z:
 assert len(z.namelist())==len(set(z.namelist()))
 for v in manifest['files']:assert hashlib.sha256(z.read(v['name'])).hexdigest()==v['sha256']
plan=read(R/'Execution_Plan.json');plan['steps'][3].update(step='[100%] Verify final documents and deliver exact provenance and ethics evidence requests',status='completed');(R/'Execution_Plan.json').write_text(json.dumps(plan,indent=2))
print(json.dumps(dict(status='PASS',visual_pages=206,docx_outputs=[p.name for p in docx],bundle=bundle.name,bundle_bytes=bundle.stat().st_size,all_relative_links_exist=True),indent=2))
