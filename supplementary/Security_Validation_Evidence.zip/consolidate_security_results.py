"""Consolidate selected immutable security receipts; no target tests executed."""
from pathlib import Path
from collections import Counter,defaultdict
import csv,datetime,hashlib,json

BASE=Path('/mnt/c/Users/RNO/Desktop/Coureses/P1/ars_security_execution_2026_10_11')
R=Path('/home/mai/ehr_me06_reproduction_20261011_v1')
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):Path(p).write_text(json.dumps(v,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
def utc(s):
    if isinstance(s,(int,float)):return datetime.datetime.fromtimestamp(s,datetime.timezone.utc).isoformat()
    return datetime.datetime.fromisoformat(s.replace('Z','+00:00')).astimezone(datetime.timezone.utc).isoformat()
def item(p):return {'path':p.relative_to(BASE).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)}

paths={'prg':BASE/'prg/results_attempt_01.json','protocol':BASE/'protocol/attempt_02/results/Protocol_Results.json','exports':BASE/'exports/attempt_01/SV07_Results.json'}
data={k:read(p) for k,p in paths.items()}
rows=[]
for key,records in [('prg',data['prg']['results']),('protocol',data['protocol']['cases']),('exports',data['exports']['cases'])]:
    for c in records:
        identifier=c.get('case',c.get('id'))
        group=c.get('group','SV-07')
        ev=c.get('evidence',{})
        if key=='protocol':
            ev={k:v for k,v in c.items() if k in ['expectation','aggregate_callbacks','total_local_fit_callbacks','model_advancements','exception','max_abs_average_error','quantization_bound','predeclared_error_bound','observed_stages','stages','benchmark_data_read','trained_model_loaded','test_harness','transport']}
            ev['fixture']=c.get('fixture',{})
        start=c.get('start_utc',c.get('start_unix'));end=c.get('end_utc',c.get('end_unix'))
        rows.append({'group':group,'case_id':identifier,'status':c['status'],'selected_attempt':'02' if key=='protocol' else '01','expected':c.get('acceptance',c.get('expectation','Conformance/freshness criterion in sealed SV01/SV06 contract')),'start_utc':utc(start) if start else '', 'end_utc':utc(end) if end else '', 'aggregate_callbacks':c.get('aggregate_callbacks',''),'local_toy_fit_callbacks':c.get('total_local_fit_callbacks',''),'evidence_summary_json':json.dumps(ev,ensure_ascii=False,sort_keys=True),'source_json':paths[key].relative_to(BASE).as_posix(),'source_json_sha256':sha(paths[key])})
assert len(rows)==101 and len({x['case_id'] for x in rows})==101
total=Counter(x['status'] for x in rows);assert total=={'PASS':99,'FAIL':1,'OBSERVED_BOUNDARY':1},total
grouped={g:dict(Counter(x['status'] for x in rows if x['group']==g)) for g in [f'SV-0{i}' for i in range(1,8)]}
assert grouped=={'SV-01':{'PASS':28},'SV-02':{'PASS':17},'SV-03':{'PASS':7},'SV-04':{'PASS':28},'SV-05':{'PASS':6,'FAIL':1},'SV-06':{'PASS':1},'SV-07':{'PASS':12,'OBSERVED_BOUNDARY':1}},grouped
with (BASE/'Results.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

before=read(BASE/'exports/attempt_01/original_seal_before.json')
source=[]
inv=read(R/'input_inventory.json')
for section in ['source','preprocessing_source']:
    for ent in inv[section]:
        p=R/section/ent['path'];h=sha(p)
        source.append({'section':section,'relative_path':ent['path'],'bytes':p.stat().st_size,'sha256':h,'matches_sealed_input':h==ent['sha256']})
protected=[]
for rec in before['protected_runtime_files']:
    p=Path(rec['path']);protected.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
seal={'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_files':source,'protected_runtime_files':protected,'source_files_count':len(source),'source_input_failures':sum(not x['matches_sealed_input'] for x in source),'same_as_before_SV07_execution':source==before['source_files'] and protected==before['protected_runtime_files'],'scope':'Read-only final original215source+84preprocessing source entries and4 protected helper/wheel/lock files; byte hashing only, no benchmark parsing/model loading.'}
assert len(source)==299 and seal['source_input_failures']==0 and seal['same_as_before_SV07_execution']
write(BASE/'Consolidated_Source_Seal.json',seal)

attempts=[]
for key,rel in [('prg','prg/execution_receipt_attempt_01.json'),('protocol_first','protocol/attempt_01/Attempt_Receipt.json'),('protocol_selected','protocol/attempt_02/Attempt_Receipt.json'),('exports','exports/attempt_01/execution_receipt.json')]:
    p=BASE/rel;rec=read(p)
    counts=dict(Counter(c['status'] for c in read(BASE/'protocol/attempt_01/results/Protocol_Results.json')['cases'])) if key=='protocol_first' else (dict(Counter(c['status'] for c in data['prg']['results'])) if key=='prg' else (dict(Counter(c['status'] for c in data['protocol']['cases'])) if key=='protocol_selected' else dict(Counter(c['status'] for c in data['exports']['cases']))))
    attempts.append({'stage':key,'receipt':item(p),'start_utc':utc(rec['start_utc']),'end_utc':utc(rec['end_utc']),'exit_code':rec['exit_code'],'raw_receipt_timestamps_preserved':True,'counts':counts,'selected':key!='protocol_first'})
assert attempts[1]['counts']=={'PASS':57,'FAIL':2}
failure=next(c for c in data['protocol']['cases'] if c['status']=='FAIL')
assert failure['id']=='SV05_PARALLEL_LIST_LENGTH_MISMATCH' and failure['exception']['type']=='KeyError' and failure['exception']['message']=='22' and failure['aggregate_callbacks']==0 and failure['total_local_fit_callbacks']==3
scope=read(BASE/'Suite_Scope.json')
prg_fresh=next(c for c in data['prg']['results'] if c['group']=='SV-06')['evidence']
qapath=BASE/'Independent_Evidence_Checks.json';qa=read(qapath)
provenance_files=[BASE/'Suite_Scope.json',BASE/'prg/contract.json',BASE/'prg/sealed_before_execution_attempt_01.json',BASE/'prg/run_checks.py',BASE/'prg/launch_checks.ps1',BASE/'protocol/Acceptance_Contract.json',BASE/'protocol/Acceptance_Seal.json',BASE/'protocol/Harness_Repair_01.json',BASE/'protocol/Protocol_Evidence_Manifest.json',BASE/'protocol/attempt_01/Executed_Script.py',BASE/'protocol/attempt_02/Executed_Script.py',BASE/'exports/run_sv07.py',BASE/'exports/attempt_01/contract.json',BASE/'exports/attempt_01/contract.sha256']+list(paths.values())+[BASE/'Consolidated_Source_Seal.json',BASE/'Results.csv',qapath]
summary={
 'suite_id':scope['suite_id'],'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'COMPLETED_WITH_RETAINED_FAIL_AND_METADATA_BOUNDARY',
 'selected_records':101,'selected_status_counts':dict(total),'group_status_counts':grouped,
 'counting_rule':'One row per selected case/record only. Protocol attempt02 selected; attempt01 retained but excluded from final101. SV06 twenty sessions count as one grouped record. Subassertions and prior545softwaretests excluded.',
 'selected_result_files':[item(p) for p in paths.values()],'execution_attempts':attempts,
 'timestamp_note':'All consolidated timestamps are converted to UTC using encoded offsets. PRG source fields named start_utc/end_utc contain+08:00 strings; originals preserved unchanged.',
 'material_passport':{'source_docx_sha256':scope['source_docx_sha256'],'runtime':'WSL Ubuntu-24.04 / Python3.12.3 / CPU','executable':str(R/'.venv/bin/python'),'flower_version':'1.22.0+mai.prg7570.1','official_flower_release':False,'local_backport':'HMAC PRG helper from contributor PR7570, commit e87804ad00c46bff6dc3f058b73de81529e50bc0','helper_sha256':'62935b91cf10f41f2036f8ccdbe65f257de86d4ada65cff7ff9fe254927c361c','crypto_parameters':scope['main_crypto_configuration'],'inputs':'Public four-coordinate vectors, public PRG references, deliberately malformed toy messages and public export canaries; direct named validator fixtures. No benchmark records or learned weights.','protected_asset':scope['protected_asset'],'observer':scope['observer'],'original_sources_modified':False,'private_protocol_material_exported':False,'test_generated_secrets':'Ephemeral toy protocol secrets generated and compared only in memory; not exported with values/digests.','local_paths_and_public_metadata':'Receipts may include local paths/client labels/public protocol IDs; not anonymous publication artifacts.'},
 'retained_target_failure':{'case_id':failure['id'],'criterion':'ValueError or RuntimeError controlled rejection required before accepted aggregate','actual_exception':failure['exception'],'accepted_aggregate_callbacks':0,'local_toy_fit_callbacks':3,'toy_aggregate_state_advancements':0,'reproduced_in_attempts':[1,2],'classification':'Malformed parallel-list alignment/input validation and late diagnostic failure under public toy fixture; no accepted corrupted aggregate or plaintext disclosure demonstrated.','target_fix_applied':False},
 'harness_repair':read(BASE/'protocol/Harness_Repair_01.json'),
 'metadata_boundary':{'case_id':'SV07-13','observed_fields':['request_id','exception_class','traceback_file','traceback_function'],'public_metadata_output_files':2,'payload_safe_output_files_scanned':9,'payload_canary_categories':9,'payload_canary_matches':0,'positive_control_detected_categories':9,'interpretation':'Payload/error-message redaction is not arbitrary metadata sanitisation. Trusted public metadata and sharing review required.'},
 'freshness_diagnostics':prg_fresh,
 'source_preservation':{'source_entries_checked':299,'source_input_hash_failures':0,'same_as_before_execution':True,'protected_runtime_build_files':4,'final_seal':item(BASE/'Consolidated_Source_Seal.json'),'installed_flower_runtime_files_checked_in_SV01':424},
 'independent_evidence_qa_snapshot':{'status':qa['status'],'checks_count':qa['checks_count'],'scope':qa['scope'],'file':item(qapath)},
 'scope_not_executed':[{'item':'TLS/network deployment/organisational PKI','reason':'Local in-memory transport; certificate/network configuration absent and excluded from current trusted-host benchmark.'},{'item':'Host/OS isolation and administrator compromise','reason':'One trusted shared WSL host holds toy party contexts; requires isolated endpoints and separate threat/deployment design.'},{'item':'Arbitrary collusion or malicious-server proof','reason':'Requires explicit coalition/security assumptions and protocol analysis; finite fixtures cannot establish a theorem.'},{'item':'Differential privacy, membership inference, inversion and poisoning evaluations','reason':'Separate attack/task design, baselines, independent splits and metrics needed; SecAgg alone does not imply those protections.'},{'item':'Formal cryptographic security/entropy certification','reason':'Finite conformance/nonreuse tests and library identity do not prove unpredictability or full protocol security.'},{'item':'Full30-run EHR benchmark rerun for security suite','reason':'Not required to test these named public-fixture properties; no source/model algorithm changed and original performance tables retained. Current results do not extend security validation to every live model round.'},{'item':'Historical actual secret or full private-log audit','reason':'Unnecessary sensitive material excluded; selected synthetic output paths tested only.'},{'item':'Automatic patch of retained target failure','reason':'Would alter frozen source identity; diagnosis retained for separately versioned hardening and unchanged-fixture retest.'}],
 'formal_security_certification':False,'zero_leakage_proven':False,'production_readiness_established':False,
 'provenance_records':[item(p) for p in provenance_files],
}
write(BASE/'Security_Validation_Summary.json',summary)

table='\n'.join(f'| {g} | {v.get("PASS",0)} | {v.get("FAIL",0)} | {v.get("OBSERVED_BOUNDARY",0)} |' for g,v in grouped.items())
attempttable='\n'.join(f'| {a["stage"]} | {a["start_utc"]} | {a["end_utc"]} | {a["exit_code"]} | '+', '.join(f'{k}={v}' for k,v in a['counts'].items())+' |' for a in attempts)
report=f'''# تقرير تنفيذ التحقق الأمني المحدود

**النتيجة الأساسية: اكتملت المجموعات السبع، وبقي معيار واحد غير محقق وحدّ واحد لتصدير metadata. لا تُعد النتيجة شهادة أمنية ولا إثباتًا بانعدام التسرب.**

يتضمن الملخص المختار **101 سجل تحقق:99 PASS، و1 FAIL، و1 OBSERVED_BOUNDARY**. العدّ لسجلات حالات محددة، وليس101 تجربة تدريب مستقلة أو101 برهانًا أمنيًا. احتُسبت20 جلسة التشخيص في SV-06 سجلًا مجمعًا واحدًا. لم تُضف الاختبارات البرمجية السابقة وعددها545 إلى هذا العدد، ولم تُحسب المحاولة الأولى للبروتوكول مرتين.

## 1. أهم نتيجة تحتاج إجراء

الحالة `SV05_PARALLEL_LIST_LENGTH_MISMATCH` لم تحقق معيار الرفض المتوقع. اختبرت قائمة مصدر قصيرة مقارنة بقائمة الرسائل المشفرة للعميل الثالث. كان المتوقع `ValueError` أو `RuntimeError` من مسار رفض مضبوط؛ ظهر بدلًا منه `KeyError('22')` متأخرًا عند UNMASK، بعد3 استدعاءات fit على متجهات toy عامة. بقي عدد استدعاءات التجميع المقبولة0 وعدد انتقالات حالة aggregate المصغرة0.

**المعنى:** توقف التنفيذ ولم يقبل aggregate، لكن المدخل المشوه لم يُرفض بفحص صريح مبكر لتطابق القوائم. لا تثبت الحالة قبول تحديث فاسد أو كشف تحديث فردي. إنها ملاحظة تحقق من المدخلات وتشخيص الخطأ ضمن هذه الحالة المحددة. أُبقيت FAIL في المحاولتين، ولم يُعدّل المصدر لإخفائها.

الإصلاح المقترح لاحقًا: إضافة فحص تطابق طول قائمتي ciphertext/source، وهويات المصدر المتوقعة وتفرّدها قبل استدعاء modifier؛ رفض مضبوط قبل local fit، ثم إعادة نفس الحالة مع ضوابط إيجابية. يجب إصدار هوية مصدر جديدة عند أي patch. لا يوجد دليل أن تجارب الأداء التاريخية استعملت هذه الرسالة المشوهة.

## 2. بطاقة المواد والتنفيذ — Material Passport

| العنصر | المادة الفعلية |
|---|---|
| معرف المجموعة | {scope['suite_id']} |
| النظام | Ubuntu-24.04 داخل WSL، Python3.12.3، تنفيذ CPU محلي |
| Python | `{R}/.venv/bin/python` |
| Flower | `1.22.0+mai.prg7570.1`؛ بناء محلي مع تعديل helper، وليس إصدارًا رسميًا جديدًا |
| مصدر التعديل | contributor PR7570، commit `e87804ad00c46bff6dc3f058b73de81529e50bc0` |
| بصمة helper | `62935b91cf10f41f2036f8ccdbe65f257de86d4ada65cff7ff9fe254927c361c` |
| إعدادات التجميع |3 shares، threshold2، وجوب مشاركة العملاء الثلاثة، max_weight4096، clipping8، quantization2^22، modulus2^31 |
| المدخلات | متجهات عامة ذات4 إحداثيات، مراجع PRG عامة، رسائل toy مشوهة عمدًا، canaries عامة؛ اختبارات مباشرة لبعض validators |
| الأصل المحمي | متجه معاملات العميل الفردي عند واجهة رسائل التجميع المحددة |
| منظور الرصد | واجهة التطبيق/دخول الخادم؛ المضيف ونهايات العميل المفترض أنها أمينة موثوقة |
| البيانات والأوزان | لم تُفتح سجلات benchmark أو checkpoints متعلمة، ولم يحدث تدريب أو inference جديد |
| الأسرار المؤقتة | ولّد البروتوكول مفاتيح ومواد toy مؤقتة في الذاكرة عند الحاجة؛ لم تُصدّر القيم أو بصماتها |
| المصدر الأصلي | لم يُعدّل. ملفات scripts الجديدة منفصلة عن source وcampaign والبيئة المثبتة |

## 3. نتائج المجموعات السبع

| المجموعة | PASS | FAIL | ملاحظة حدود |
|---|---:|---:|---:|
{table}
| الإجمالي |99 |1 |1 |

- **SV-01:** تطابقت هوية helper والدالة وروابط client/server، وملفات Flower المثبتة الـ424 مع wheel. نجحت بوابات هوية البناء على callbacks عامة، ومتجه HMAC من RFC4231، والمقارنة مع decoder مستقل عبر15 modulus، وحدود الأشكال/النوع/النطاق. أُعيدت حالة التصادم المصطنعة للنسخة القديمة وتميّزت16 مدخلًا عامًا في النسخة المحلية؛ هذا regression test ولا يثبت collision resistance.
- **SV-02:** نجحت17 حالة حسابية وحدودية، شملت oracle عامة ومسار StrictSecAggPlusWorkflow الفعلي مع أوزان غير متساوية وحدود القيم، ورفض مدخلات عددية/أوزان/أشكال غير صالحة. قيم aggregate المصغرة وقعت داخل الحدود العددية المسبقة.
- **SV-03:** نجحت7 حالات لرصد ingress وحقول الرسائل. أظهر ضبط B معاملات plaintext، بينما لم تعبر ArrayRecords معبأة في ردود collection الإيجابية لـC. رُفضت حقول plaintext/digest/loss/status/config المحقونة في الحالات المحددة. هذا رصد لقنوات محددة، وليس قياسًا شاملًا للمعلومات المتسربة.
- **SV-04:** نجحت28 حالة، منها نقص/تكرار/هوية غريبة/خطأ ردود في المراحل الأربع، وقواعد الجولات والمشاركة وعدم fallback. فشل بعض المسارات المتأخرة بعد عمل toy محلي، لذلك لا يُقال إن كل رفض منع كل callback. حالة SETUP restart هي characterization مسبقة تؤكد السماح بإعادة SETUP مع تحذير؛ نجاحها لا يثبت replay resistance عامة.
- **SV-05:** نجحت6 حالات تخص المفاتيح والرسائل المشفرة ومسار shares، وبقيت الحالة السابعة FAIL كما ورد أعلاه. اختبارات إعادة تشفير share عامة بمفتاح يملكه harness تختبر فحص المسار؛ لا تثبت قدرة مهاجم خارجي على الحصول على مفاتيح حقيقية.
- **SV-06:** نُفذت20 جلسة مستقلة وثلاثة عملاء في كل جلسة، أي60 سياقًا. لوحظ120 سياق مفتاح EC مميزًا و60 سياقًا مميزًا في كل فئة seeds/مفاتيح أزواج/ردود masked المفحوصة؛ اشتق الطرفان مفاتيح متطابقة للأزواج. نُفذت setup/share/collect الفعلية، دون unmask في هذه المجموعة. لا يثبت عدم التكرار المحدود entropy أو unpredictability.
- **SV-07:** نجح12 فحصًا actual observer/failure capsule، وكشف الضبط الإيجابي canaries التسع. خلت مخرجات JSON التسعة المحددة من هذه القيم العامة. سُجلت حدود metadata بصورة مستقلة كما يلي.

## 4. حدود metadata والتصدير

تصدّر الآلية المسموح به من request ID، واسم فئة exception، وملف/دالة traceback. عندما وُضع marker عام عمدًا في هذه الحقول ظهر في مخرجين تشخيصيين؛ هذا هو `SV07-13 OBSERVED_BOUNDARY`. بقيت canaries الخاصة بمحتوى payload ورسائل الخطأ غير المعروفة غائبة.

إذًا تحمي فحوص هذه الجولة مسارات payload ورسائل الخطأ المحددة، لكنها **لا تُعقّم كل قيمة نصية داخل metadata**. يلزم أن تكون metadata عامة موثوقة، وأن تُراجع المسارات والمعرّفات قبل المشاركة الخارجية. هذه ملاحظة تصميم تشخيصي، ولا تثبت تسرب بيانات EHR أو أسرار بروتوكول فعلية. لم تشمل الجولة جميع السجلات الخاصة أو stores أو ذاكرة المضيف.

## 5. سجل المحاولات والتواريخ الفعلية

كل الأوقات في الجدول **UTC** بعد تحويل offsets المسجلة، ويقابلها وقت سنغافورة بإضافة8 ساعات. بعض حقول PRG المسماة `start_utc/end_utc` تحتوي في الأصل offset `+08:00`؛ حُوّلت في الملخص فقط وحُفظت الملفات الأصلية دون تعديل. جميع عمليات الاختبار أدناه جرت في11 أكتوبر2026.

| التنفيذ | بداية UTC | نهاية UTC | Exit | نتيجة السجلات |
|---|---|---|---:|---|
{attempttable}

المحاولة الأولى للبروتوكول احتوت57 PASS و2 FAIL. واحدة بسبب API خطأ في harness: استدعاء `recorddict_to_fitres` دون `keep_input`. أُصلح الاستدعاء التجريبي فقط إلى `keep_input=True` وسُجل ذلك في `protocol/Harness_Repair_01.json`. لم يتغير acceptance أو target. بعد الإصلاح أصبحت58 PASS و1 FAIL في المحاولة الثانية، واستمرت `KeyError('22')`. Exit2 في المحاولتين يحفظ وجود معيار غير محقق.

حُفظت scripts المنفذة والـhashes والأوامر والبدايات والنهايات وstdout/stderr ونتائج كل حالة في كلا مجلدي المحاولة. الاختيار الإحصائي النهائي يستخدم protocol attempt02 فقط. لا يحذف ذلك دليل المحاولة الأولى.

## 6. سلامة المصدر وأصل الدليل

حُفظت عقود القبول قبل التنفيذ في `prg/contract.json` و`protocol/Acceptance_Contract.json` و`exports/attempt_01/contract.json` مع seals وSHA256. احتفظ كل منفّذ بأوامره وسجلاته والـscripts الدقيقة. يربط `Security_Validation_Summary.json` كل مصدر نتيجة ببصمته، و`Results.csv` يحتوي101 صف حالة مع المرجع ووقت UTC المختار.

بعد اكتمال المحاولات المختارة، أعيدت مقارنة ملفات المصدر **299** (215 مصدرًا و84 preprocessing-source) بالمخزون الأصلي وبالحالة السابقة: صفر اختلاف. بقي helper والـwheelان وdependency lock دون تغيير. دليل الختم النهائي `Consolidated_Source_Seal.json`. هذا ليس فحصًا لكل ملف على المضيف أو إثبات host isolation. نُفذ أيضًا فحص مستقل للدليل، snapshot بعدد{qa['checks_count']} فحصًا، حالته{qa['status']}؛ يُرجع نطاقه إلى `Independent_Evidence_Checks.json` ولا يُضاف عدده إلى101.

## 7. ما لم يُنفذ ولماذا

| النطاق غير المنفذ | السبب وما يلزم لتوسيعه |
|---|---|
| TLS وشبكة فعلية وPKI مؤسسية | التنفيذ in-memory؛ يتطلب certificates وإعداد شبكة ونشر مستقلًا. |
| عزل المضيف وحماية من administrator | المضيف المشترك موثوق ويحوي سياقات toy؛ يلزم توزيع على نهايات معزولة ونموذج تهديد جديد. |
| تواطؤ اعتباطي أو إثبات خادم خبيث | يحتاج افتراضات coalition وتحليل البروتوكول؛ لا تثبته عينات عددية محدودة. |
| DP وmembership inference وinversion وpoisoning | تحتاج تصميم هجوم ومقاييس وضوابط وبيانات مستقلة؛ SecAgg وحده لا يثبتها. |
| إثبات تشفير رسمي أو اعتماد entropy | conformance وعدم تكرار محدود لا يثبتان الأمان الرياضي أو جودة مولّد النظام تحت جميع الظروف. |
| إعادة حملة EHR ذات30 run | غير لازمة لفحص الخصائص المسماة على متجهات عامة؛ المصدر والخوارزمية لم يتغيرا. لم يمتد الدليل الأمني إلى جميع جولات التدريب الفعلية. |
| مسح كل الأسرار والسجلات الخاصة تاريخيًا | غير لازم لهذا الفحص وقد يكشف مواد حساسة؛ اقتصرت الجولة على مخرجات synthetic محددة. |
| patch تلقائي لمعيار FAIL | يُغير المصدر المجمد؛ يتطلب نسخة مصرحًا بها وهوية جديدة وإعادة نفس fixture والضوابط. |

## 8. الصياغة العلمية التي تسمح بها الأدلة

يمكن القول إن **التنفيذ المحلي خضع لتحقق محدود على بيانات عامة لسلامة هوية البناء، ومطابقة PRG، وصحة aggregate وحدوده، وقنوات رسائل محددة، وبعض حالات الفشل والتلاعب، وتشخيص عدم إعادة الاستخدام، وتصدير diagnostics**. يجب أن يرافق ذلك ذكر FAIL المتبقي وحدود metadata.

لا تسمح الأدلة بعبارات «ثبت الأمان بالكامل»، «لا يمكن تسريب أي معلومات»، «مقاوم لكل التواطؤ أو الهجمات»، أو «جاهز للنشر السريري». ولا تنسب هذه الجولة تحسين الأداء أو السرعة إلى التشفير؛ لم تُعد تجربة التدريب أو قياس full-wire traffic/isolated crypto time.

الأولوية التالية هي معالجة فحص تطابق القوائم في نسخة منفصلة إذا أريد تقوية التنفيذ، مع إبقاء ملاحظة الحالية في التقرير. أما نتائج الأداء الأصلية فتبقى كما هي؛ لم تظهر هنا واقعة تبطل حساباتها أو تغيّر نموذجها.
'''
(BASE/'Security_Validation_Report_AR.md').write_text(report)
print(json.dumps({'status':summary['status'],'selected_records':len(rows),'counts':dict(total),'groups':grouped,'source_entries':299,'source_failures':0,'files':['Results.csv','Security_Validation_Summary.json','Security_Validation_Report_AR.md','Consolidated_Source_Seal.json']},ensure_ascii=False,indent=2))
