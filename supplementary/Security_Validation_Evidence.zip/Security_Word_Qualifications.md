# Current v1.9 wording after the bounded security suite

Read-only review of the current manuscript. DOCX SHA-256 remains `8362f01c48e0be9f6b7458d2ae5a4ad9d140f882afc5a7527ac3a6f719287c4b`; its hash-matched extracted blocks and final rendered page text were inspected. No DOCX edit was made by this reviewer. Page references below are the **existing v1.9 printed pages**, which will move after new material is inserted. Proposed Section 4.11 / Appendix D.9 references should follow the editor's final numbering.

## Wording that needs a dated or scope distinction

1. **§3.8, p34, F0357.** Current: “Eavesdropping, malicious coordination, compromised endpoints and client collusion were not tested.” Keep the main benchmark's threat model, but a blanket statement about all final-version work would obscure the new selected negative fixtures and boundary demonstration. Suggested replacement:

   “The main benchmark did not evaluate eavesdropping, coordinated malicious parties, compromised endpoints or client collusion. Subsequent public-toy negative tests and boundary demonstrations are reported separately in Section 4.11 and Appendix D.9; they do not establish protection against these threats. TLS was not used.”

2. **§3.8, p35, F0362.** Current: “the installed wheel payload was not supplied.” This refers to the historical installation, whereas ME-06 rebuilt a candidate and the security suite used that retained rebuilt environment. Replace only that clause with:

   “the historical installed wheel payload was not supplied; the subsequent rebuild and runtime checks are documented separately in Appendix D.8 and Section 4.11.”

3. **§3.8, p36, F0364.** Current historical missing-reply/ID paragraph says that absence of a data callback was supported by source inspection. The new suite now records local toy callback counts. Preserve historical evidential limits instead of erasing them:

   “In those historical records, missing replies or mismatched identifiers produced no aggregation callback. That count alone did not establish absence of a client data callback; the reported ordering was supported by source inspection. The subsequent bounded suite records local toy-fit and accepted-aggregate callbacks separately, including local work completed before late-stage rejection (Section 4.11). Hash and message-format checks establish consistency, not authenticated execution on a remote host.”

4. **Appendix C.2, p94, F0726.** Current opening: “The results below are from the recorded candidate-build public protocol check, not newly run cryptographic tests.” This is still correct for the historical tables immediately below, but should explicitly separate them from the new campaign:

   “The results below are historical candidate-build public-protocol records. They remain distinct from the subsequently executed bounded suite reported in Section 4.11 and Appendix D.9. These historical fixtures were not rerun as part of the earlier source-only audit.”

   Retain the remaining explanation of lattice/non-lattice and historical refusal cases.

5. **Table C.5, p96, F0746, “Verification boundary” row.** Current text excludes malicious-input tests without an explicit historical modifier. Proposed replacement:

   “Historical functional fixtures and local range guards; subsequent selected malformed-input tests are reported in Section 4.11. Neither set is an exhaustive saturation/attack assessment or cryptographic proof.”

   Do not replace the historical main-weight error `1.4738 × 10^-6` or its `1.0561 × 10^-5` bound with newly generated toy-case values. They concern different fixtures.

6. **Appendix C, note following Table C.5, F0747, p96.** Current: “No new protocol execution was performed during that earlier source-only audit; the subsequent ME-06 execution is documented in Appendix D.8.” Already historically qualified and therefore accurate. Append one short clause if desired:

   “The later bounded security-validation execution is documented separately in Section 4.11 and Appendix D.9.”

7. **Table 6.1, p77, F0608, Objective 3 row.** Add Section 4.11 / Appendix D.9 to the evidence cell. Suggested conclusion cell:

   “Aggregation integration and selected numerical/message/refusal checks completed; one controlled-rejection criterion remained unmet. No comprehensive privacy certification.”

   This adds the new finding without altering the objective or rewriting historical success as security certification.

## Places to add the new evidence while preserving their existing limitations

- **English Abstract, F0032, front matter.** Its trusted-host/honest-participant protection limit remains correct. A short addition can acknowledge both positive evidence and the finding without giving protocol-subset counts as whole-suite counts:

  “Subsequent bounded local validation supported selected numerical and message-exposure controls but identified a malformed-message rejection limitation.”

  Mirror any substantive addition in the Malay abstract, F0036, preserving technical scope. This reviewer has not certified Malay-language style.

- **§5.3, p65, F0545.** Retain the distinction from reconstruction-attack resistance and host confidentiality. After the current paragraph, add:

  “The later public-toy suite directly exercised selected message boundaries and refusal paths (Section 4.11). An unequal ciphertext/source-list fixture still aborted without an accepted aggregate, but raised an unexpected late KeyError and failed the predeclared controlled-rejection criterion.”

- **§5.7.5, p73, F0587.** The statement that the helper was not cryptographically certified remains true. Do not delete it because HMAC consistency tests passed. Add:

  “The bounded validation narrows uncertainty about the tested code paths; it does not resolve host isolation or cryptographic assurance. The retained malformed-message finding concerns early validation and diagnostic control, rather than a demonstrated accepted corrupted aggregate or plaintext disclosure.”

- **§6.2, p76, F0602, and §6.3 p76–77.** Current “privacy leakage was not quantified” and “without establishing comprehensive privacy protection” must stay. Add the new suite outcome, including the unmet criterion and aggregate-output boundary, after Results/Discussion have already reported them. Do not introduce test counts here that are absent from Results.

- **Appendix E.2, pp112–113, F0819, SecAgg+ setup row.** Its statement that numerical fixtures are not security certification remains valid. An optional evidence update is: “Selected post-benchmark validation is reported separately in Section 4.11; one controlled-rejection criterion remained unmet.”

- **Appendix E.3, p113, F0822.** Broaden the evidence phrase from “inspected interface and tested numerical behaviour” to “inspected interface, tested numerical behaviour and selected message/refusal controls”. Retain all no-quantified-gain/no-equivalence/no-host-confidentiality limits. Add a concise mention that the malformed-message criterion and aggregate-output disclosure boundary remain limitations.

## Statements that remain accurate and should not be removed

- No TLS, independent organisational deployment or shared-host administrator confidentiality was established.
- No cryptographic certification, differential privacy, poisoning robustness or quantitative reconstruction-attack reduction was established.
- All 3 clients were required; threshold 2 did not make dropout successful operation part of the application policy.
- The main benchmark did not quantify privacy leakage or validate a non-inferiority margin/cost ceiling.
- Source rights, label validity, ethics status and clinical generalisation remain unresolved by this security suite.
- Historical numerical/source-only audit statements in Appendix C remain valid once their historical scope is explicit.
- The new cases use tiny public arrays and in-memory transport, plus selected direct code-path fixtures. They must not be called 59 full deployment/benchmark tests, 59 cryptographic proofs, or attacks on real hospital records.

## Important interpretation of the retained FAIL

The protocol subset has 58 PASS and 1 FAIL in 59 final-attempt cases. The failed case reached UNMASK, raised `KeyError('22')`, recorded 3 local toy fit callbacks and **0 accepted aggregates / 0 toy aggregate-state advancements**. It failed the sealed expectation of a controlled `ValueError`/`RuntimeError` rejection. The final manuscript should report the unmet criterion and safe abort together. It must not imply that a malformed update was accepted, that a real benchmark checkpoint advanced, or that plaintext/secret material leaked.

Whole-suite group counts and the separately observed aggregate-output boundary must be taken from the root's final consolidated evidence, not inferred from this protocol subset.
