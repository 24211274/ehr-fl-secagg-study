"""Packaged renderer with read-only Word PDF export on this Windows host."""
from pathlib import Path
import importlib.util, subprocess
script=Path(r'C:\Users\RNO\.codex\plugins\cache\openai-primary-runtime\documents\26.1009.11318\skills\documents\render_docx.py')
spec=importlib.util.spec_from_file_location('packaged_renderer',script)
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
def word_export(doc_path,user_profile,convert_tmp_dir,stem,verbose=False):
    pdf=Path(convert_tmp_dir)/(stem+'.pdf')
    helper=Path(__file__).parent.parent/'review_qa/export_word_pdf.ps1'
    cp=subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(helper),'-InputDocx',str(doc_path),'-OutputPdf',str(pdf)],capture_output=True,text=True,timeout=120)
    return (str(pdf) if pdf.exists() else '',cp.stdout+'\n'+cp.stderr)
mod.convert_to_pdf=word_export
mod.main()
