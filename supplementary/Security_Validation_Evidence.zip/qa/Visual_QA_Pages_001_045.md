# Visual QA of final render pages001–045

All **45 individual page PNGs** were opened with `view_image(detail="original")` at their original910×1287 resolution (110dpi). This report covers `qa/render_final/page-1.png` through `page-45.png`, from the first cover through printedpage31. It does not claim visual inspection of pages46–135.

The documents skill's render→inspect-every-page requirement was read and applied. No DOCX, source or render image was changed by this reviewer. Root will bind the accepted final DOCX hash after repairs. Per-image hashes identifying the inspected render are in `Visual_QA_Pages_001_045.json`.

**Status: corrections required before final acceptance.** No clipping, overlapping content, missing glyph, broken table or footer collision was observed in these45 pages. Tables2.1–2.3 and3.1–3.3, the architecture figure, and the green/yellow/cyan/magenta/gray highlights remain legible. The issues are paragraph flow/navigation and visible sentence spacing.

## Required layout/navigation corrections

1. **Physicalpage6 / printedv:** Malaykeywords alone on an almost blank page. Keep keywords with the Malayabstract, for example by modestly tightening only this abstract's spacing after the new insertion. Do not silently truncate the abstract.
2. **Physicalpage12 / printedxi:** a single TableE.1 list-of-tables entry spills onto a separate page. Modestly tighten list-of-tables spacing so it remains with the rest if practical; otherwise update navigation to the actual two-page list.
3. **Physicalpage7 TOC:** Roman frontmatter entries are stale. Current actual TOC startsvi (listedv), Figurelistix (listedviii), Tablelistx (listedix), Symbols/listxii (listedx), Appendixlistxiii (listedxi). Recompute after layout corrections, since removing the two orphan pages changes these again. Arabicbody page1 starts physicalpage15 in this inspected render; do not assume an old physical/printed offset.

## Visible boundary-spacing corrections

The following visible joins should be checked against paragraph/run text and restored with an ordinary sentence space if confirmed:

- Physicalpage4 / printediii: `security.Protection claims` → `security. Protection claims` (new abstract insertion boundary).
- Physicalpage22 / printed8: `explanations.In their` → `explanations. In their` (appears joined in originalPNG).
- Physicalpage25 / printed11: `practical risk.These findings` → `practical risk. These findings`.
- Samepage25: `Secure Aggregation protocol.Bell et al.` → `Secure Aggregation protocol. Bell et al.`.
- Physicalpage31 / printed17: `FedAvg.Full-text assessment` → `FedAvg. Full-text assessment`.

Some joins are inherited highlighted run boundaries, not necessarily new security-update text. No scientific assertion changes are proposed by this QA. Declaration grammatical wording on physicalpage3 is an inherited university-template query; do not alter mandated boilerplate solely from this visual check.

## Every inspected page

| Physicalpage | Printedpage | Inspection observation |
|---:|---|---|
| 1 | unnumbered | Cover: clean title/author/affiliation. |
| 2 | unnumbered | Inner title page: clean. |
| 3 | ii | Declaration: clean layout; inherited grammatical boilerplate query remains, no edit undertaken. |
| 4 | iii | Abstract fits; visible missing boundary space security.Protection flagged. |
| 5 | iv | Malay abstract body readable; keywords spill to page6. |
| 6 | v | Orphan Malay keyword paragraph alone on otherwise blank page. |
| 7 | vi | TOC readable but frontmatter Roman entries stale after pagination expansion. |
| 8 | vii | TOC continuation readable; new4.11 entry visible. |
| 9 | viii | TOC continuation readable; newD.9 entry visible. |
| 10 | ix | Figure list readable; printedix differs fromTOC targetviii. |
| 11 | x | Table list readable; last TableE.1 spills to page12. |
| 12 | xi | Single orphan TableE.1 list entry. |
| 13 | xii | Abbreviation table fits with readable cells; printedxii differs fromTOC targetx. |
| 14 | xiii | Appendix list readable; printedxiii differs fromTOC targetxi. |
| 15 | 1 | Readable body/highlights, clean footer, no clipping/overlap/missing glyphs observed. |
| 16 | 2 | Readable body/highlights, clean footer, no clipping/overlap/missing glyphs observed. |
| 17 | 3 | Readable body/highlights, clean footer, no clipping/overlap/missing glyphs observed. |
| 18 | 4 | Readable body/highlights, clean footer, no clipping/overlap/missing glyphs observed. |
| 19 | 5 | Readable body/highlights, clean footer, no clipping/overlap/missing glyphs observed. |
| 20 | 6 | Readable body/highlights, clean footer, no clipping/overlap/missing glyphs observed. |
| 21 | 7 | Readable body/highlights, clean footer, no clipping/overlap/missing glyphs observed. |
| 22 | 8 | Senturk paragraph appears explanations.In boundary join; verify plainOOXML text. |
| 23 | 9 | Readable body/highlights, clean footer, no clipping/overlap/missing glyphs observed. |
| 24 | 10 | Readable body/highlights, clean footer, no clipping/overlap/missing glyphs observed. |
| 25 | 11 | Visible risk.These and protocol.Bell sentence joins; verify/run-space repair. |
| 26 | 12 | Readable body/highlights, clean footer, no clipping/overlap/missing glyphs observed. |
| 27 | 13 | Readable body/highlights, clean footer, no clipping/overlap/missing glyphs observed. |
| 28 | 14 | Table2.1 begins, all columns readable. |
| 29 | 15 | Table2.1 continuation/repeated header readable; final row andnote fit. |
| 30 | 16 | Readable body/highlights, clean footer, no clipping/overlap/missing glyphs observed. |
| 31 | 17 | Visible FedAvg.Full-text boundary join in highlighted source paragraph. |
| 32 | 18 | Readable body/highlights, clean footer, no clipping/overlap/missing glyphs observed. |
| 33 | 19 | Tables2.2 and2.3 clean; latter continues with header. |
| 34 | 20 | Table2.3 continuation readable, no clipped cells. |
| 35 | 21 | Table2.3 continuation readable; Researchgap heading/firstlines stay paired. |
| 36 | 22 | Researchgap yellow highlights readable. |
| 37 | 23 | Readable body/highlights, clean footer, no clipping/overlap/missing glyphs observed. |
| 38 | 24 | Architecture figure andcaption clear; allnodes/arrows within page. |
| 39 | 25 | Table3.1 clean; following paragraph close to table but not overlapping. |
| 40 | 26 | Table3.2 clean; highlighted inclusionparagraph andsectionheading readable. |
| 41 | 27 | Table3.3 readable with wrapped codefieldnames and intact mathglyphs. |
| 42 | 28 | Readable body/highlights, clean footer, no clipping/overlap/missing glyphs observed. |
| 43 | 29 | Readable body/highlights, clean footer, no clipping/overlap/missing glyphs observed. |
| 44 | 30 | Readable body/highlights, clean footer, no clipping/overlap/missing glyphs observed. |
| 45 | 31 | Readable body/highlights, clean footer, no clipping/overlap/missing glyphs observed. |

After repairs, re-render and inspect every changed page plus any page whose pagination/layout shifts. This reviewed render must not be described as the repaired final version until that verification is done.
