# Final visual QA of pages 4 through 18

Status: **CORRECTION_REQUIRED** for one inherited sentence-spacing defect. All 15 assigned final page PNGs were opened and inspected individually at original image detail. No clipping, overlap, missing glyphs, broken tables or footer collisions were observed.

Final DOCX SHA-256 supplied by root and recorded in Final_Structural_Integrity.json: `084dad138b929bc88828bd50a805fff2d1c1b12cbb21a2906cbc8ffa0b28de82`.

The JSON companion binds each observation to the exact inspected PNG SHA-256. This report covers only physical pages 4–18 of the repaired 133-page render. Earlier visual QA remains unchanged; the root reviewer handles pixel-identical page mapping and other changed pages.

## Repair checks

- English abstract: the missing space before 'Protection claims' is fixed; abstract and keywords fit on printed page iii.
- Malay abstract: keywords are retained on the same page as the abstract, printed page iv.
- List of Tables: all entries, including Table E.1, fit on one page, printed page ix.
- Roman frontmatter Table of Contents references match the inspected actual page footers: iii, iv, v, viii, ix, x and xi.
- Remaining correction: physical page 13 / printed page 1, bottom line, `2011; Hedda et al., 2017).The current benchmark` → `2011; Hedda et al., 2017). The current benchmark`. This is an inherited word-spacing issue and does not alter the scientific statement. Root was notified before completion.

## Page-by-page inspection

| Physical page | Printed page | Status | Observation |
|---|---|---|---|
| 4 | iii | PASS | English abstract and keywords fit on one page. The boundary 'security. Protection claims' contains a visible space. Green and yellow highlights remain legible; no clipping or footer collision. |
| 5 | iv | PASS | Malay abstract and Kata kunci are retained on the same page. The shorter green security sentence preserves the 99 PASS, 1 FAIL and metadata-boundary statements. No orphaned keyword page; no clipping or overlap. |
| 6 | v | PASS | First Table of Contents page is legible. Roman references match inspected actual frontmatter pages: abstract iii, Malay abstract iv, contents v, figures viii, tables ix, symbols x, appendices xi. |
| 7 | vi | PASS | Second Table of Contents page is legible. Section labels, leaders, page numbers and cyan highlights remain within margins; no overlapping entries. |
| 8 | vii | PASS | Final Table of Contents page ends after Appendix E entries. Normal trailing whitespace; no detached continuation or clipped content. |
| 9 | viii | PASS | List of Figures remains on one page with readable captions, dot leaders and highlighted page numbers. Actual Roman footer matches contents reference. |
| 10 | ix | PASS | Entire List of Tables fits on one page, including final Table E.1. All entries and highlights are legible; no clipping, crowding collision or orphan continuation. Footer matches contents reference. |
| 11 | x | PASS | Symbols and abbreviations table is intact, with all rows visible and no glyph loss or clipping. Footer matches contents reference. |
| 12 | xi | PASS | List of Appendices is legible; all five entries remain within margins. Footer matches contents reference. |
| 13 | 1 | CORRECTION_REQUIRED | Introduction layout and highlights are legible, but the last line contains a visible inherited sentence join: '2011; Hedda et al., 2017).The current benchmark'. Insert a space between ').' and 'The'. No clipping or overlap. |
| 14 | 2 | PASS | Continuation of introduction and Problem statement is legible. Paragraph/page transitions and highlights are intact; no clipping or overlap. |
| 15 | 3 | PASS | Research questions, aim and first two objectives are legible. Yellow and cyan highlights remain readable. No clipping or footer collision. |
| 16 | 4 | PASS | Objectives continuation, Research scope and Contribution heading are legible. No broken sentence layout, clipping or overlap. |
| 17 | 5 | PASS | Contribution continuation and Organisation of report are legible. The 'evidence and literature-search records' boundary has a visible word space. No clipping or overlap. |
| 18 | 6 | PASS | Literature Review opening and EHR audit-log discussion are legible, including green additions. Heading, paragraph flow and footer remain clear; no clipping or overlap. |

## Date and scope limits

Security execution occurred on 11 October 2026. Final render QA/delivery crossed to 12 October 2026 in Asia/Singapore; this does not change the experiment date.

No DOCX was edited, no renderer was run, and no original security results, execution timestamps or old QA files were modified. This visual review does not independently certify all body navigation references, scientific claims or security properties.
