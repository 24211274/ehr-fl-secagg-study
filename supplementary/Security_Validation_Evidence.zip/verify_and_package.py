from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from lxml import etree as E
from PIL import Image
from collections import Counter
import json, hashlib, csv, shutil
ROOT=Path(__file__).resolve().parent;QA=ROOT/'qa';D=ROOT/'delivery'
DOCX=D/'Research_Report_Chapters_1_to_6_v1_10_SecurityValidation_Highlighted_20261011.docx'
SRC=ROOT.parent/'ars_manuscript_update_v1_9_2026_10_11'/DOCX.name.replace('v1_10_SecurityValidation','v1_9_ME06_Verified')
W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}';R='{http://schemas.openxmlformats.org/officeDocument/2006/relationships}'
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def text(el):return ''.join(n.text or '' for n in el.iter(W+'t'))
with ZipFile(SRC) as z:original={n:z.read(n) for n in z.namelist()}
with ZipFile(DOCX) as z:current={n:z.read(n) for n in z.namelist()};assert z.testzip() is None
assert sha(SRC.read_bytes())=='8362f01c48e0be9f6b7458d2ae5a4ad9d140f882afc5a7527ac3a6f719287c4b'
for n,b in current.items():
    if n.endswith('.xml') or n.endswith('.rels'):E.fromstring(b)
ob=E.fromstring(original['word/document.xml']).find(W+'body');nb=E.fromstring(current['word/document.xml']).find(W+'body')
newtables=[p for p in nb if p.tag==W+'tbl'];unchanged=0
for i,el in enumerate(ob):
    if el.tag==W+'tbl' and i not in [550,608,746]:
        assert sum(E.tostring(t)==E.tostring(el) for t in newtables)>=1,(i,text(el)[:80]);unchanged+=1
assert len(newtables)==len([p for p in ob if p.tag==W+'tbl'])+3
oc=E.fromstring(original['word/comments.xml']);nc=E.fromstring(current['word/comments.xml']);cm={c.get(W+'id'):c for c in nc}
assert all(E.tostring(c)==E.tostring(cm[c.get(W+'id')]) for c in oc)
for tag in ['commentRangeStart','commentRangeEnd','commentReference']:
    oldcounts=Counter(x.get(W+'id') for x in ob.iter(W+tag));newcounts=Counter(x.get(W+'id') for x in nb.iter(W+tag))
    assert all(newcounts[k]==v for k,v in oldcounts.items()),(tag,'old anchors changed')
    assert set(newcounts).issubset(cm)
for c in nc:
    if c.get(W+'id') not in {x.get(W+'id') for x in oc}:
        assert all(sum(n.get(W+'id')==c.get(W+'id') for n in nb.iter(W+t))==1 for t in ['commentRangeStart','commentRangeEnd','commentReference'])
media=[n for n in original if n.startswith('word/media/')];assert all(original[n]==current[n] for n in media)
for i in range(614,657):assert any(text(p)==text(ob[i]) for p in nb),i
# Historical main-weight numerical statement remains untouched.
for phrase in ['1.4738','1.0561']:assert phrase in text(nb)
rels=E.fromstring(current['word/_rels/document.xml.rels']);targets=[x.get('Target') for x in rels if x.get('Type','').endswith('/hyperlink')]
assert 'ME06_Evidence.zip' in targets and 'Security_Validation_Evidence.zip' in targets
assert sha((D/'ME06_Evidence.zip').read_bytes())=='ed395d9fad8dd017b6ef726bfd76091ba8a63101e6d0b97183ab229d0427313c'
summary=read(ROOT/'Security_Validation_Summary.json');rows=list(csv.DictReader((ROOT/'Results.csv').open(encoding='utf-8-sig',newline='')))
assert len(rows)==101
assert summary['selected_status_counts']=={'PASS':99,'FAIL':1,'OBSERVED_BOUNDARY':1}
assert summary['source_preservation']['source_entries_checked']==299 and summary['source_preservation']['source_input_hash_failures']==0
for rec in summary['provenance_records']+summary['selected_result_files']:
    p=ROOT/rec['path'];assert p.stat().st_size==rec['bytes'] and sha(p.read_bytes())==rec['sha256'],rec['path']
assert '99 PASS' in text(nb) and 'KeyError' in text(nb) and 'OBSERVED_BOUNDARY' in text(nb)
nav=read(QA/'Navigation_Verified.json');assert nav['all_match'] and nav['navigation_references']==174
# Final render page identity reconciliation, using decoded pixels rather than PNG metadata.
def pixel(p):
    with Image.open(p) as im:return sha(im.convert('RGB').tobytes())
oldpages={pixel(p):int(p.stem.split('-')[-1]) for p in (QA/'render_final').glob('page-*.png')}
mapping=[]
for p in sorted((QA/'render_delivery').glob('page-*.png'),key=lambda p:int(p.stem.split('-')[-1])):
    h=pixel(p);mapping.append({'final_page':int(p.stem.split('-')[-1]),'pixel_sha256':h,'previous_inspected_page':oldpages.get(h)})
(QA/'Final_Visual_Identity_Map.json').write_text(json.dumps(mapping,indent=2),encoding='utf-8')
changed=[m['final_page'] for m in mapping if m['previous_inspected_page'] is None]
report={'source_docx_sha256':sha(SRC.read_bytes()),'final_docx_sha256':sha(DOCX.read_bytes()),'selected_cases':101,'statuses':summary['selected_status_counts'],'unchanged_original_scientific_tables':unchanged,'supplemented_evidence_tables':[550,608,746],'new_tables':3,'original_comments_preserved':len(oc),'new_comments':len(nc)-len(oc),'unchanged_media_parts':len(media),'bibliography_entries_preserved':43,'original_ME06_attachment_verified':True,'relative_attachments_present':True,'navigation_references_verified':174,'final_pages':len(mapping),'visually_identical_prior_inspected_pages':len(mapping)-len(changed),'final_changed_pages_requiring_visual_qa':changed,'no_target_fix_applied':True}
(QA/'Final_Structural_Integrity.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report))
if '--package' not in __import__('sys').argv:raise SystemExit(0)
finalvisual=read(QA/'Final_Visual_QA.json');assert finalvisual['all_final_pages_covered'] and finalvisual['blocking_defects']==0 and finalvisual['docx_sha256']==report['final_docx_sha256']
# Retain generated evidence only; no raw data, weights, secrets, rendered PDF/PNG.
names=['README_AR.md','Suite_Scope.json','Results.csv','Security_Validation_Summary.json','Security_Validation_Report_AR.md','Consolidated_Source_Seal.json','Independent_Evidence_Checks.json','Independent_Security_Evidence_Review.md','Manuscript_Evidence_QA.md','Security_Word_Qualifications.md','Word_Change_Ledger.json','build_security_revision.py','consolidate_security_results.py','finalize_navigation.py','render_with_word.py','qa_other_workers.py','verify_and_package.py','stabilize_sentence_spaces.py','Execution_Plan.json']
payload={n:(ROOT/n).read_bytes() for n in names}
links=[]
for folder in ['prg','protocol','exports']:
    for p in sorted((ROOT/folder).rglob('*')):
        if p.is_symlink():links.append({'path':p.relative_to(ROOT).as_posix(),'target':str(p.readlink()),'stored_as_metadata_only':True});continue
        try:
            if p.is_file() and '__pycache__' not in p.parts:payload[p.relative_to(ROOT).as_posix()]=p.read_bytes()
        except OSError as exc:
            if getattr(exc,'winerror',None)!=1920 or 'public_fixture_inputs/symlinked/' not in p.relative_to(ROOT).as_posix():raise
            links.append({'path':p.relative_to(ROOT).as_posix(),'kind':'WSL-created synthetic fixture symlink unreadable through Windows stat','stored_as_metadata_only':True,'reason':'No dereference of WSL special link; fixture outcome remains in SV07-10 and source control files are separately retained'})
for p in QA.glob('*'):
    if p.is_file() and p.suffix in ['.json','.md']:payload[p.relative_to(ROOT).as_posix()]=p.read_bytes()
payload['Symlink_Inventory.json']=json.dumps(links,indent=2).encode()
manifest={'suite_id':'EHR-FL-SECURITY-20261011','counting_rule':'Final protocol attempt02 plus first PRG/export attempts; all earlier attempts retained','selected_status_counts':summary['selected_status_counts'],'manifest_excludes_itself':True,'public_canaries_and_controls_are_synthetic':True,'raw_benchmark_or_weights_included':False,'generated_private_protocol_values_or_digests_included':False,'files':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(payload.items())]}
target=D/'Security_Validation_Evidence.zip'
with ZipFile(target,'w',ZIP_DEFLATED) as z:
    for n,b in sorted(payload.items()):z.writestr(n,b)
    z.writestr('MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2))
with ZipFile(target) as z:
    assert z.testzip() is None
    for item in manifest['files']:
        b=z.read(item['path']);assert len(b)==item['bytes'] and sha(b)==item['sha256']
shutil.copy2(ROOT/'Security_Validation_Report_AR.md',D/'Security_Validation_Report_AR.md')
delivery=[DOCX,target,D/'ME06_Evidence.zip',D/'Security_Validation_Report_AR.md']
(ROOT/'Delivery_Manifest.json').write_text(json.dumps({'files':[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in delivery],'security_zip_payload_files':len(payload),'all_payload_hashes_verified':True},indent=2),encoding='utf-8')
print(json.dumps({'zip':str(target),'payload_files':len(payload),'bytes':target.stat().st_size,'all_verified':True}))
