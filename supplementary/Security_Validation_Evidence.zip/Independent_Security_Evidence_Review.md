# Independent evidence review of SV02–SV05 and SV07

Reviewer scope: read-only review of the other workers' contracts, scripts, receipts, retained attempts, individual case records, reports and selected artifacts. **No new protocol/security experiment and no target/source modification was performed in this review.** This reviewer implemented SV01/SV06, so those own-worker results are excluded from the claim of independent review here; root review covers their independent QA.

## Verdict

The reviewed records support **58 PASS + 1 retained FAIL for SV02–SV05**, and **12 PASS + 1 explicitly separate metadata-boundary observation for SV07**. I found no additional mislabeled PASS in the inspected final cases. The reported statuses respect the unchanged pre-execution contracts. The suite must not be reported as all passed, a security certification, or comprehensive privacy protection.

Read-only artifact/contract/classification QA completed **244 checks with zero discrepancies**. These are evidence-consistency checks, not 244 security experiments. Details and exact checks are preserved in `Independent_Evidence_Checks.json`; the review helper `qa_other_workers.py` only reads existing artifacts and writes this independent QA result.

## Retained target finding — must remain open

`protocol/attempt_02/results/SV05_PARALLEL_LIST_LENGTH_MISMATCH.json` is correctly **FAIL** under the sealed contract. Removing one source ID while retaining its encrypted-share list reached UNMASK and caused `KeyError('22')`, after three public toy fit callbacks but with **zero accepted aggregate callbacks and zero toy aggregate advancement**. The same outcome exists in both attempts.

The failure concerns missing early, controlled alignment validation and its unexpected late error. It does not demonstrate acceptance of a poisoned aggregate, disclosure of an individual update, an exploitable external attack, or compromised historical results. The tiny fixture used harness-controlled party contexts. A potential fix is a separately versioned early length/identity alignment guard before local fit, followed by rerunning the unchanged case and positive controls. No fix was applied in this execution task.

## SV02–SV05 fidelity

1. **Criteria and settings:** the seal predates the first attempt; contract hash is unchanged. Three shares, threshold two, max weight 4096, clipping range 8, quantization 2^22, modulus 2^31 and timeout 600 match the prescribed main settings. Tiny public draw counts and one toy round are explicitly different from the main 30-round study budget.
2. **Actual versus fixture code:** the harness uses installed Flower ClientApp/SecAgg code and actual project StrictSecAggPlusWorkflow, cohort, wire, range, restored-array and numeric-bound functions. Its client guard is a toy-aware replica of the setup/cohort guard and uses `toy=True`; its small strategy is also a fixture. Selected direct cases call actual named project guards. These are not full benchmark ServerApp/LocalTask deployments or new EHR training runs.
3. **Plain positive control:** the B control is a native plain Flower NumPyClient reply with a known public vector, rather than the complete EHR B application. Its plaintext visibility passed. Its zero aggregation count is structurally true for that direct fixture, not an independently instrumented live B strategy counter.
4. **C observation boundary:** successful C replies were observed before upstream server processing, with no populated plaintext ArrayRecord and with masked blobs. Allowed metadata remains: client label, public input-model digest, steps/draws, num_examples and status fields. Field/schema checks do not prove non-recoverability of protected inputs or zero inference from allowed quantities. Ordinary evaluation metrics are outside parameter masking.
5. **Numeric evidence:** retained lattice oracle results report exact integer recovery; strict and off-grid cases use independently computed weighted means and predeclared bounds. All full positive fixtures reached the ordered four stages and one accepted aggregate. Direct range/shape/weight validators are explicitly separate from protocol completions.
6. **Early versus late rejection:** setup/share mutations have zero toy fit callbacks. Later collect/unmask mutations can occur after one or three fit callbacks. All selected rejected final fixtures had zero accepted aggregate callbacks. This must not become the stronger claim that every bad message prevented all local work or every possible failure is atomic/rollback-safe.
7. **Allowed restart:** the direct SETUP-restart characterization is correctly reported as observing permitted upstream behavior. Its PASS is not replay-resistance evidence. Selected repeated-round/collect/local-file guards have narrower passing refusal tests.
8. **Tampering fixtures:** wrong source/destination cases were re-encrypted with keys available to the harness's own toy-party contexts. These test route validation and do not show an outside adversary can access real participant keys. The ciphertext-bitflip failure is specific to the chosen encrypted-share fixture, not a proof of arbitrary model-update integrity or Byzantine robustness.

## Attempt retention and one harness repair

Both attempts preserve the executed script, receipts, stdout/stderr and 59 per-case JSON copies. Their script hashes match the receipts/results; per-case copies match the aggregate result file. Attempt 01 retained 57 PASS and two FAIL records. Attempt 02 retained 58 PASS and one FAIL; both exit codes are 2.

The exact script difference is supplying `keep_input=True` to the read-only B-control FitRes decoder. This matches `Harness_Repair_01.json`; no target acceptance condition was loosened and no target source/runtime fix was made. The implementation criterion failure remained FAIL. It would be misleading to count the first API error as a separate target security defect or to erase it from the execution history.

## SV07 fidelity and metadata limitation

- The contract was written before execution; contract, script and log hashes match the receipt. Twelve PASS cases and one OBSERVED_BOUNDARY correspond to the contract's 13 records.
- The actual measurement observer and failure-capsule functions were exercised, with native Flower record types, controlled callbacks and an in-memory reply transport. Only `measurement_scope()` was substituted with an explicit public fixture to avoid benchmark reads. These are selected output-path tests, not a full network/deployment audit.
- Independently checked all **nine selected payload-safe JSON outputs** for all nine literal public canary categories: no matches. The deliberately unsafe positive-control file contains every category. This validates scanner sensitivity for those literal canaries and selected outputs; it is not an arbitrary-encoding or semantic-secret detector.
- The **two metadata-boundary artifacts** are correctly retained separately. A public marker survives in permitted request IDs, exception class and traceback file/function metadata. They are not secretly omitted from a claim of universal sanitization: the report explicitly identifies the trusted-public-metadata assumption and need to review metadata before external sharing.
- Source preservation records contain **299 original entries**, all matching their sealed hashes before/after; the four listed protected runtime/build files are unchanged. This protects that inventory, not all files on the host or all installed libraries.
- Actual secret keys, masks, shares or EHR rows were not used in the export fixtures. “No actual secret leakage observed” is therefore not equivalent to an attack experiment using real secrets. Full private logs, Flower stores, process memory, host compromise and network traffic remain outside these tests.

## Reporting requirements

Use the final statuses with the target FAIL visible. Describe validation as **bounded implementation checks on public fixtures under trusted local-host assumptions**. Preserve the distinction between message-interface exposure, later strategy exposure and shared-host access. Do not infer TLS, remote attestation, authenticated institutional participants, collusion resistance, differential privacy, malicious-server security, poisoning resistance, cryptographic proof or clinical deployment readiness.

The tested response policy requiring all three participants supports failure on the selected incomplete-cohort fixtures. It does not establish successful dropout recovery merely because reconstruction threshold is two. With three participants, the aggregate plus two known contributions also reveals the remaining contribution algebraically; this inherent boundary is not addressed by the suite and must remain outside broad privacy claims.

## Inspected evidence locations

- `protocol/Acceptance_Contract.json`, `Acceptance_Seal.json`, both `attempt_01` and `attempt_02` scripts/receipts/results/logs, `Harness_Repair_01.json`, current `security_protocol_suite.py`, `Protocol_Execution_Report.md`.
- `exports/run_sv07.py`, `SV07_Report.md`, `Latest_Attempt.json`; `exports/attempt_01` contract/hash, execution receipt, aggregate/per-case records, source seals, nine selected output artifacts, positive control and two metadata-boundary artifacts.
- Earlier inspected main project source supports interpretation of field/cohort guards. The present review did not re-execute any target case. No complete audit of all dependency cryptography or all private project outputs is claimed.
