# SV-07: bounded export and diagnostic redaction validation

Execution on **11 October 2026** completed in the retained WSL virtual environment. **Result: 12 checks PASS, one metadata-boundary observation; no failed checks.** Overall result is **PASS_WITH_METADATA_BOUNDARY**, not comprehensive leakage certification.

The acceptance contract and SHA-256 were saved before execution. Attempt01 is retained with command, script hash, start/end UTC timestamps, exit code0, stdout, empty stderr, per-case results, fixture inputs, positive control and every selected runtime-output artifact.

## Actual code exercised

- Original `source/app/mai_measurement.py`: `record_bytes`, `timing_boundary_mod`, `client_span`, `ObservedRawGrid` and `server_report`.
- Original `source/main_study/failure_evidence.py`: `collect_failure_capsule`.
- Installed Flower1.22.0+mai.prg7570.1 native `Message`, `RecordDict`, `ConfigRecord`, `MetricRecord` and `ArrayRecord` conversions, with the source package's test-only received-message fixture.

Only `measurement_scope()` was replaced in-process with an explicit public30-round/reference+noniid fixture so the observer could be tested without reading training inputs. Controlled callbacks and an in-memory reply transport were used. This was not a full deployment, training run or protocol privacy experiment. Original code and installed files were not edited.

## Results

| Case | Test | Observed outcome |
|---|---|---|
| SV07-01 | Scanner sensitivity: deliberately unsafe synthetic export | All9 public-canary categories detected. This control file is explicitly excluded from payload-safe artifacts. |
| SV07-02 | Actual counter on native config/metric/array records | Only numeric counts exported:167 array,20 metric,381 config,568 total logical-content bytes; no canary. |
| SV07-03 | Actual client observer, successful callback | Preserved request/public routing metadata and incoming401/outgoing153 logical-content byte counts; none of9 payload canaries exported. |
| SV07-04 | Actual client observer, exception carrying public canary | Exception propagated; failure output retained `RuntimeError` type and omitted the exception message; no canary. |
| SV07-05 | Actual raw-grid observer and server report | One observed in-memory exchange exported counts/routing/phase metadata; no request/reply payload canary. |
| SV07-06 | Approved client timing span | Exported only approved span name, wall/process-CPU durations and completion state. |
| SV07-07 | Failure capsule with unknown exception message and extra payload fields | Message redacted; unknown payload fields omitted; public identity and file-hash diagnostics retained. |
| SV07-08 | Failure capsule with allowlisted round error, normal frame and fake source/local/loss values | Safe error message, public frame and last recorded round2 retained; source/local/loss canaries omitted. |
| SV07-09 | Invalid exception-class syntax | Class replaced by `UNKNOWN`; payload/error canaries absent. |
| SV07-10 | Symlinked fixture result/trace/history inputs | Linked records ignored; no failure/frame/round data copied. |
| SV07-11 | Unsupported job identity | Rejected with `ValueError`; no capsule emitted. |
| SV07-12 | Scan every selected payload-safe runtime JSON | **Nine output files**, nine public-canary categories, zero literal matches. Sources, contracts and test-input files were not falsely treated as leaked runtime outputs. |
| SV07-13 | Deliberate public marker in allowed metadata | **Observed boundary:** request ID, exception class, traceback filename/function were copied to two diagnostic outputs, as expected from the source. Payload/error canaries remained absent. These two boundary outputs are kept separately from the nine payload-safe files. |

## What the result establishes

For the specified fixtures and selected output paths, actual observer code exported public metadata, counts and timings instead of payload values; actual failure-capsule code redacted unrecognised exception messages and omitted additional record fields, source lines, local variables and losses. The scanner's ability to detect the literal public test markers was independently controlled.

**Metadata is intentionally allowed, not universally sanitised.** Arbitrary content put into request IDs, traceback filenames/functions or valid exception-class names can appear in diagnostics. The implementation therefore requires trusted public metadata and a metadata review before external sharing. The observed boundary is not evidence that any actual EHR data or cryptographic secret leaked. A claim that these functions remove secrets from every possible string, file or log would exceed this result.

Full private logs, Flower stores, process memory, the shared host, network transport, secret recovery, side channels and arbitrary source-generated strings were outside this check. No raw benchmark data or model was opened by the test process, and no attempted open was blocked by its benchmark/model guard. No actual keys, mask values, shares, cryptographic seeds or EHR records were used: all marker strings and arrays were public test fixtures.

## Source and runtime preservation

Before and after execution, all **299 inventory entries** (215 original source plus84 preprocessing-source entries) matched the sealed input hashes and each other. The installed PRG helper, both retained Flower wheels and dependency lock were also unchanged. This protected-file check is not a scan of every installed package or the entire host.

## Evidence locators

- `attempt_01/contract.json` and `contract.sha256`: prespecified acceptance and scope.
- `attempt_01/execution_receipt.json`: command, timestamps, exit code and source-preservation result.
- `attempt_01/SV07_Results.json`: every check and narrow claim/limitation.
- `attempt_01/case_results/`: individual check records.
- `attempt_01/payload_safe_outputs/`: the9 scanned observer/capsule runtime outputs.
- `attempt_01/controls/`: deliberately unsafe public-canary sensitivity control.
- `attempt_01/metadata_boundary_observations/`: the2 intentionally adversarial public-metadata outputs.
- `attempt_01/public_fixture_inputs/`: synthetic local inputs preserved for repeatability.
- `attempt_01/original_seal_before.json` and `original_seal_after.json`:299 original-file hashes plus4 protected runtime/build files.
- `attempt_01/stdout.log` and `stderr.log`: child execution logs, no actual secret material.

Script SHA-256: `71650cbe8124360ba548cafc1e0e5277c3fe0e80eefe3f5afea3bd8995cdfc2f`.

Contract SHA-256: `1a07f4601d6132c9db4dd8aa6c9c33ec81d0ed80e45a69511e85268bf5c3166b`.
