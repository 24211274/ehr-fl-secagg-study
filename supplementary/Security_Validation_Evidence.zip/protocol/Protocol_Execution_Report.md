# SV-02–SV-05 executed bounded validation

Final selected attempt: `attempt_02`. **58 PASS, 1 FAIL, 0 ERROR, 0 NOT_RUN in 59 selected cases.** The FAIL is retained under the unchanged pre-execution acceptance contract. Neither all cases nor the full implementation are declared security-certified.

The suite ran with `/home/mai/ehr_me06_reproduction_20261011_v1/.venv/bin/python` in Ubuntu-24.04, user `mai`, using the preserved source and installed Flower `1.22.0+mai.prg7570.1`. It used public 4-element arrays, three in-memory client contexts and selected direct validator calls. No benchmark training/inference, learned checkpoint loading, raw EHR dataset access or original source/runtime modification occurred.

## Acceptance and attempt retention

- Pre-execution contract: `Acceptance_Contract.json`, SHA-256 `ad167328e3ebd66e191bccfe37b56a1245ef1c77a4af9016ebe2f9c45f826ea7`.
- Pre-execution seal: `Acceptance_Seal.json`, timestamp `2026-10-11T15:43:06.5843252Z` (23:43:06 Asia/Singapore).
- First attempt: `attempt_01`, start/end `15:43:20.9756950Z` / `15:43:29.9929963Z`, exit code 2. Script SHA-256 `b16537f41d39bf23a348efbd258a5e705402c5bd8cafc1776facc8048a226d4d`.
- First attempt reported 57 PASS and 2 FAIL. One is a **harness API error**, not an implementation security failure: the B plaintext control called `recorddict_to_fitres` without the required `keep_input` argument. Its original script, receipt, stdout/stderr and case JSON remain intact. `Harness_Repair_01.json` records the sole repair, supplying `keep_input=True`.
- Second attempt: `attempt_02`, start/end `15:44:13.1835799Z` / `15:44:21.9938491Z`, exit code 2. Script SHA-256 `43b261dc923dcf802eadf3286729db727bca9d1ef4893f42476356c8e989f212`.
- The contract and target code were unchanged between attempts. The actual target criterion failure reproduced and was not fixed or reclassified as PASS.

Each attempt folder includes the executed script copy, `Attempt_Receipt.json`, stdout/stderr, individual case JSON files and `results/Protocol_Results.json`. Exit code 2 correctly signals the retained unmet criterion.

## Actual outcomes

| Group | PASS | FAIL | What was exercised |
|---|---:|---:|---|
| SV-02 — numerical masking and range | 17 | 0 | Three retained public oracle cases; real project strict workflow with unequal weights and boundary values; finite/dtype/range checks; valid/invalid weights; recovered carrier/shape consistency. |
| SV-03 — message ingress and allowlist | 7 | 0 | Real plain Flower positive control; C ingress observed before upstream processing; injected populated ArrayRecord, output digest, extra loss metric, free status text and unknown config; stale public input fingerprint. |
| SV-04 — cohort, stages and no fallback | 28 | 0 | Missing/duplicate/foreign/error replies at each of four stages; wrong settings/stage; incomplete unmask cohort; skipped/repeated round; direct stage-repeat, local fit completion-file and unprotected fit guards; direct actual project aggregate callback guards. |
| SV-05 — selected key/share fixtures | 6 | 1 | Duplicate/replaced/malformed keys; corrupted Fernet ciphertext; authentic toy share payloads with deliberately wrong source/destination; unequal parallel ciphertext/source lists. |

The strict unequal-weight positive case made one accepted aggregate callback with 3 local toy fit callbacks and maximum aggregate error `1.2772423896301177e-08`, below `0.0002111707435688004`. The boundary case with weights `[4096,4096,4096]` and public parameter magnitudes up to 8 had error `7.947285984855057e-08`, below `9.5367431640625e-06`.

The B control had one populated plaintext parameter ArrayRecord. In the positive C collection-stage replies, no populated ArrayRecords crossed server ingress; masked parameter blobs and the allowlisted public metadata were present. This validates the named output-channel checks for these fixtures, not a universal information-leakage bound.

Missing/duplicate/foreign/error cohort mutations at SETUP, SHARE_KEYS, COLLECT_MASKED_VECTORS and UNMASK were refused with zero accepted aggregate callbacks. Late-stage failures can occur **after local toy fit callbacks**. Per-case records preserve those callback counts; no claim that every rejected exchange prevented all local work is made.

`SV04_SETUP_RESTART_CHARACTERIZATION` confirms that the upstream stage validator permits a SETUP restart with a warning. PASS here means the predeclared characterization was observed. It is not a claim of comprehensive replay resistance. The separate collection-stage repeat and local completion-file guards were refused in their selected fixtures.

## Retained unmet criterion — SV05_PARALLEL_LIST_LENGTH_MISMATCH

The fixture removed one element from the third client's source-ID list while retaining its ciphertext list. The contract required rejection with `ValueError` or `RuntimeError` before an accepted aggregate.

Observed outcome in both attempts:

- all four stage names were reached;
- 3 local toy fit callbacks occurred;
- UNMASK raised `KeyError('22')`;
- accepted aggregate callbacks and toy aggregate-state advancements were both 0;
- no aggregate was accepted and no benchmark checkpoint was written.

The **typed, controlled-rejection criterion failed**. The system still aborted; the evidence does **not** show an accepted corrupted aggregate, plaintext update disclosure or successful security bypass. The malformed request escaped early explicit list-alignment validation and surfaced as an unexpected dictionary lookup failure later in the protocol. This is a bounded input-validation/diagnostic hardening finding under the chosen malformed-message fixture.

Possible future hardening, not applied here: validate equal ciphertext/source-list lengths and expected unique source identities in the checked client wrapper before calling the upstream modifier; reject with a controlled error before local fit, then rerun this unchanged fixture and suitable positive controls. Such a patch would need a separately versioned source/runtime identity. Current benchmark results are unaffected by this isolated test; there is no evidence the historical benchmark used malformed messages.

## Scope fidelity and limitations

The cryptographic constants match the main study: 3 shares, reconstruction threshold 2, max weight 4096.0, clipping range 8.0, quantization range 2^22 and modulus 2^31. Every protocol case uses one toy round; it is not a new 30-round benchmark experiment. Application policy requires all 3 participants despite threshold 2.

The harness executes the real installed Flower ClientApp, SecAgg modifier and project `StrictSecAggPlusWorkflow`, and calls the project's cohort, wire, range, restored-array and numerical-bound validators. Its toy client guard mirrors the project's setup/cohort rules but explicitly uses `toy=True` for the public budget allowlist. It does **not** execute the complete benchmark ServerApp or real EHR LocalTask training. Selected direct cases call the named actual project methods before model/data access. Do not describe all 59 cases as full end-to-end deployment tests.

“Model advancements” in this harness means acceptance of the tiny aggregate state in the toy strategy; it does not mean a benchmark neural-network checkpoint. The B positive control directly observes its raw reply; its local callback count is not separately instrumented. Direct validator cases report no protocol aggregation and are explicitly identified as direct-path fixtures.

The wrong-route share fixtures re-encrypt a deliberately altered authenticated payload using a harness-owned public-toy-party key so that the route checks themselves are exercised. That is a local diagnostic fixture, not evidence that an external attacker can obtain a client's real key.

Message observations retain record/field names, byte counts, public stage labels and callback counts. No protocol keys, private masks, shares, raw EHR records or full serialized protocol payloads are exported. The in-memory harness necessarily owns all toy-party contexts and is not an isolation experiment.

The suite does not establish TLS, organisational authentication, protection from the shared-host operator, arbitrary collusion tolerance, differential privacy, membership/gradient-inversion resistance, poisoning robustness, formal cryptographic proof or production readiness. Functional and selected negative-test success must not be converted into those claims.
