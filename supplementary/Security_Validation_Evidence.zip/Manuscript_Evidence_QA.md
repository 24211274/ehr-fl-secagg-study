# Independent manuscript-to-evidence review

Reviewed on 11 October 2026. This is a read-only review of the newly written security material, not another security experiment or a security certificate. No DOCX, target source, acceptance contract, result or earlier independent-check file was modified by this review.

## Reviewed snapshot and method

- Final draft: `delivery/Research_Report_Chapters_1_to_6_v1_10_SecurityValidation_Highlighted_20261011.docx`.
- Reviewed final DOCX SHA-256: `aca013a3eda4f082ae76445b07572526ae84246392d6cb5c828a3d03be5beb3b`.
- Read all new prose/table entries in `Word_Change_Ledger.json`, the construction script `build_security_revision.py`, revised extracted text and the final DOCX XML. Compared the additions against the executed contracts, scripts, receipts and results reviewed in `Independent_Security_Evidence_Review.md`, plus the SV-01/SV-06 results and implementation that I executed. My review of my own SV-01/SV-06 work is not independent execution validation; the root reviewer performed that complementary inspection.
- Separate read-only checks are recorded in `qa/Manuscript_Evidence_Structural_Checks.json`: 105 checks passed, zero failed. These 105 checks are document/evidence checks, not additional security cases. The earlier 244 evidence checks and their file remain unchanged.

## Outcome

No remaining material manuscript-to-evidence discrepancy was found in the new security sections. This finding concerns the accuracy and boundaries of the new reporting, not a declaration that the whole thesis or implementation is secure, correct or complete.

| Item | Evidence and manuscript assessment |
|---|---|
| Counts and units | Table 4.16, Section 4.11, both abstracts, conclusion and D.9 consistently report 101 selected case records: 99 PASS, one FAIL, one OBSERVED_BOUNDARY. Totals match 29 PRG/freshness records, 59 selected protocol records and 13 export records. Sessions, internal assertions and the 244 evidence checks are not added as security cases. |
| Group allocation | SV-01 28 PASS; SV-02 17 PASS; SV-03 7 PASS; SV-04 28 PASS; SV-05 6 PASS + 1 FAIL; SV-06 1 grouped PASS; SV-07 12 PASS + 1 boundary. This matches the retained case results. |
| Numerical results | Five positive public fixtures completed the four ordered stages with one accepted aggregate each. The two lattice oracle sums were exact. Off-grid maximum absolute weighted-mean coordinate error 2.0504618684302756e-5 is below 0.0001239776611328125. Strict edge error 7.947285984855057e-8 is below 9.5367431640625e-6. Printed rounded values agree. These are fixture-specific numerical checks, not privacy scores. |
| Open failure | `SV05_PARALLEL_LIST_LENGTH_MISMATCH` remains FAIL. It raised `KeyError('22')` at UNMASK after three toy-fit callbacks, with zero accepted aggregate and zero toy aggregate-state advancement. The manuscript does not recast this as controlled rejection, an accepted corrupted aggregate or a proved disclosure. The proposed early validation is explicitly future correction, not an applied patch. |
| Retained attempts | Attempt 01 retains 57 PASS and 2 FAIL; the B-control decoder API-call repair alone leads to attempt 02 with 58 PASS and the same target FAIL. Both protocol exit codes remain 2. The contract and target were unchanged. |
| Real paths versus fixtures | Methods and D.9 explicitly distinguish actual installed Flower/project validators from toy strategy, mirrored client guard/public-budget exception, direct method cases and plain B control. SV-07's public `measurement_scope()` substitution is disclosed. No complete EHR application, network deployment or new benchmark run is claimed. |
| Interface visibility | Empty plaintext parameter records and present masked blobs describe observed C ingress fields. The text does not equate that observation with host/process isolation, attack non-recoverability or inference resistance. Fit metadata is not described as universally encrypted. |
| Freshness | D.9 correctly reports 20 sessions/60 client contexts, 120 distinct public-key representations and 120 distinct private-key representations, plus the four respective 60-context categories. It discloses same NumPy seed, actual setup/share/collect calls, no UNMASK in this group and finite-diagnostic limits. |
| Export scope | The nine selected output files omit nine literal public payload canaries and the scanner control detects 9/9. Two separate metadata artifacts retain the public marker. OBSERVED_BOUNDARY is preserved; no universal absence-of-secrets or sanitization proof is claimed. Public canaries are identified as synthetic, not real data or generated secret values. |
| Chronology | The new contracts are explicitly before the new executions, after the historical benchmark was known. Later audit, earlier ME-06 replay and historical candidate-build records are distinguished. No retrospective prespecification or independent external replication is implied. |
| Runtime/source identity | Helper hash, Flower build, 424 matching runtime files, 299 source/preprocessing entries and four sealed runtime/build files match their specific evidence inventories; the coverage is not inflated to the complete host. Contract hashes and UTC/Singapore times agree. |
| Unexecuted scope | Table D.13 explicitly leaves broader network/authentication, compromised-host/collusion, inference/DP, poisoning/general replay, formal crypto, full benchmark/independent replication and complete-log/encoding scans unexecuted. All-three participation remains required despite threshold two. |
| Other evidence items | ME-10 is updated to bounded execution with open finding/limits. ME-11 is not closed by these tests; isolated cryptographic time/full-wire measurements remain absent. ME-02, ME-04/05, clinical/ethics and external generalisation remain separate. |
| Original scientific material | 62 unmodified original table texts are retained; three evidence/conclusion tables are supplemented and three new tables added. All original media bytes, all 360 comment IDs/texts and the copied ME-06 ZIP are retained. No other original package part changed besides document XML, comments and document relationships. |

## Precision corrections checked

Two minor ambiguities identified during review were corrected in the final checked DOCX:

1. The off-grid statistic is now described as the largest maximum absolute aggregation error; it is not called a mean absolute error.
2. D.9 states 120 distinct public-key representations **and** 120 distinct private-key representations, avoiding an ambiguous combined count of 120.

The Malay abstract was checked only for correspondence of the added counts and bounded-security meaning. Malay grammar, idiom and translation quality are **not certified** by this reviewer.

## Limits of this review

This review did not rerun the target suites, edit the document, conduct a new source-coverage audit, validate the whole historical study or certify the implementation. Full-page visual review is recorded separately in `qa/Visual_QA_Pages_091_135.md`; the root reviewer handles final rendering, navigation and delivery-package checks.
