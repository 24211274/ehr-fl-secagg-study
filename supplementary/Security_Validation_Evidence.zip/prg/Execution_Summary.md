# SV-01 / SV-06 executed validation

**Result:** attempt 01 completed with exit code 0, 29/29 prespecified cases PASS, zero failures and zero NOT RUN cases. The 29 cases comprise 28 SV-01 cases and one grouped SV-06 experiment containing 20 independent three-client sessions. These are validation cases, not 29 thesis training runs.

The launcher ran on 11 October 2026 from 15:42:43.4434840 to 15:42:50.9302234 UTC. Python case execution was 15:42:47.673829–15:42:50.726835 UTC. Runtime: retained Ubuntu-24.04 WSL environment, Python 3.12.3, Flower `1.22.0+mai.prg7570.1`. The contract and scripts were hashed and saved before execution; the launcher confirms contract and script unchanged afterward. Standard error is empty.

## SV-01 — identity and primitive conformance

- Installed version, helper module, helper function and client/server function bindings matched the pinned local identity.
- Candidate wheel digest and RECORD checks passed; all **424 installed Flower runtime files** and installed package metadata matched the sealed wheel.
- The actual application identity middleware accepted the correct identity and refused wrong/old identities before its callback. Missing/extra identity fields were refused; positive and negative identity queries did not call the data callback. The valid callback was a synthetic empty reply and performed no training.
- RFC 4231 HMAC-SHA256 case 1 matched; independent scalar decoding matched at all **15 prescribed moduli** across five shape cases. Shape/type/range checks, six invalid-modulus rejection cases, deterministic same-public-key behavior and independence from public NumPy seeds passed.
- The known constructed legacy seed-fold collision was reproduced for **16 public inputs**; the installed candidate distinguished those inputs. This is a regression diagnostic and does not prove collision resistance.
- Tensor-boundary continuity, empty-list handling and an independent **100,000-coordinate public array** reference passed.

## SV-06 — fresh key and mask-context diagnostics

The installed client `_setup`, `_share_keys` and `_collect_masked_vectors` functions executed for **20 independent three-client sessions (60 client contexts)**. Every session used the same three public four-coordinate vectors and reset the public NumPy seed to 177. No secret RNG was replaced or seeded by the harness.

Within each tested category, comparisons in memory found:

| Category | Contexts compared | Distinct contexts observed |
|---|---:|---:|
| Generated EC public keys | 120 | 120 |
| Generated EC private-key representations | 120 | 120 |
| Private-mask seeds | 60 | 60 |
| Pairwise mask keys | 60 | 60 |
| Pairwise share-encryption keys | 60 | 60 |
| Masked aggregation replies | 60 | 60 |

Both endpoints derived matching ECDH/HKDF keys for every tested pair. Setup/share stages did not consume NumPy RNG state. Only boolean checks and counts were exported; generated keys, seeds, shares, masks, masked replies and their digests were not exported.

This experiment used direct real installed client-stage functions on public fixtures in memory. **Unmasking, the full server workflow, network deployment and multi-round live-model lifecycle were not tested by this group.** Full protocol arithmetic and selected fault paths belong to the separately executed SV02–SV05 suite. Independent sessions and finite nonreuse observations do not establish cryptographic entropy, unpredictability, replay resistance or security against compromised RNGs.

## Evidence and limits

- `contract.json`: expectations fixed before execution.
- `sealed_before_execution_attempt_01.json`: pre-execution script/contract/launcher hashes and command.
- `run_checks.py`, `launch_checks.ps1`: retained exact scripts.
- `execution_receipt_attempt_01.json`: command, timestamps, exit code, unchanged checks and log hashes.
- `results_attempt_01.json`: per-case results, timestamps and bounded evidence.
- `stdout_attempt_01.txt`, `stderr_attempt_01.txt`: complete logs; stderr empty.

Contract SHA-256: `133172442839c69da1553dc538fdb6e8dfc1bab673549e7f27391cbbd8bd5a22`.

Executed Python script SHA-256: `87ff62869bec0b7216bde3392fa151ad46a6739e4e82cbdf2fdb0fe3ac0f19a7`.

No benchmark dataset was read and no training or inference occurred. No source, dependency, runtime or campaign file was edited. Bytecode writes were disabled. Build consistency and middleware guards are not remote attestation or participant authentication; passing public conformance tests does not certify the helper or complete protocol cryptographically. No formal privacy or zero-leakage claim follows from these results.

Primary references for interpretation: [version-pinned Flower client](https://raw.githubusercontent.com/adap/flower/v1.22.0/framework/py/flwr/client/mod/secure_aggregation/secaggplus_mod.py), [pinned contributor helper](https://raw.githubusercontent.com/adap/flower/e87804ad00c46bff6dc3f058b73de81529e50bc0/framework/py/flwr/common/secure_aggregation/secaggplus_utils.py), [RFC 4231](https://www.rfc-editor.org/info/rfc4231/). Source-reading scope and protocol limits were recorded in the earlier feasibility report; this summary reports new execution only.
