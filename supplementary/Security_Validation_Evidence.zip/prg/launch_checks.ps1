$ErrorActionPreference = 'Stop'
$taskDirectory = 'C:\Users\RNO\Desktop\Coureses\P1\ars_security_execution_2026_10_11\prg'
$wslScript = '/mnt/c/Users/RNO/Desktop/Coureses/P1/ars_security_execution_2026_10_11/prg/run_checks.py'
$pythonExecutable = '/home/mai/ehr_me06_reproduction_20261011_v1/.venv/bin/python'
$arguments = @('-d','Ubuntu-24.04','--','env','PYTHONDONTWRITEBYTECODE=1',$pythonExecutable,'-B',$wslScript)
$before = [ordered]@{
    attempt = 1
    start_utc = [DateTime]::UtcNow.ToString('o')
    executable = 'wsl.exe'
    arguments = $arguments
    contract_sha256_before_execution = (Get-FileHash -LiteralPath (Join-Path $taskDirectory 'contract.json') -Algorithm SHA256).Hash.ToLowerInvariant()
    script_sha256_before_execution = (Get-FileHash -LiteralPath (Join-Path $taskDirectory 'run_checks.py') -Algorithm SHA256).Hash.ToLowerInvariant()
    launcher_sha256_before_execution = (Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash.ToLowerInvariant()
    stdout_file = 'stdout_attempt_01.txt'
    stderr_file = 'stderr_attempt_01.txt'
    fresh_secret_material_will_not_be_exported = $true
}
$before | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $taskDirectory 'sealed_before_execution_attempt_01.json') -Encoding utf8
$process = Start-Process -FilePath 'wsl.exe' -ArgumentList $arguments -WindowStyle Hidden -Wait -PassThru -RedirectStandardOutput (Join-Path $taskDirectory 'stdout_attempt_01.txt') -RedirectStandardError (Join-Path $taskDirectory 'stderr_attempt_01.txt')
$receipt = [ordered]@{
    attempt = 1
    start_utc = $before.start_utc
    end_utc = [DateTime]::UtcNow.ToString('o')
    exit_code = $process.ExitCode
    executable = $before.executable
    arguments = $arguments
    sealed_receipt_sha256 = (Get-FileHash -LiteralPath (Join-Path $taskDirectory 'sealed_before_execution_attempt_01.json') -Algorithm SHA256).Hash.ToLowerInvariant()
    contract_unchanged = ((Get-FileHash -LiteralPath (Join-Path $taskDirectory 'contract.json') -Algorithm SHA256).Hash.ToLowerInvariant() -eq $before.contract_sha256_before_execution)
    script_unchanged = ((Get-FileHash -LiteralPath (Join-Path $taskDirectory 'run_checks.py') -Algorithm SHA256).Hash.ToLowerInvariant() -eq $before.script_sha256_before_execution)
    stdout_sha256 = (Get-FileHash -LiteralPath (Join-Path $taskDirectory 'stdout_attempt_01.txt') -Algorithm SHA256).Hash.ToLowerInvariant()
    stderr_sha256 = (Get-FileHash -LiteralPath (Join-Path $taskDirectory 'stderr_attempt_01.txt') -Algorithm SHA256).Hash.ToLowerInvariant()
}
$receipt | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $taskDirectory 'execution_receipt_attempt_01.json') -Encoding utf8
$receipt | ConvertTo-Json -Depth 8
exit $process.ExitCode
