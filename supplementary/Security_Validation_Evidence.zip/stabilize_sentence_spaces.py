"""Preserve a visible space at six reviewed sentence/run boundaries."""
from pathlib import Path
from zipfile import ZipFile
from lxml import etree as E
import json
ROOT=Path(__file__).resolve().parent
DOCX=ROOT/'delivery/Research_Report_Chapters_1_to_6_v1_10_SecurityValidation_Highlighted_20261011.docx'
W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}';XML='{http://www.w3.org/XML/1998/namespace}'
with ZipFile(DOCX) as z:infos=z.infolist();parts={i.filename:z.read(i.filename) for i in infos}
r=E.fromstring(parts['word/document.xml']);b=r.find(W+'body')
checks=['explanations. In their','practical risk. These findings','Secure Aggregation protocol. Bell','FedAvg. Full-text','2011; Hedda et al., 2017). The current benchmark','source-only audit. Equal- and unequal-weight']
records=[]
for phrase in checks:
    ps=[p for p in b.findall(W+'p') if phrase in ''.join(t.text or '' for t in p.iter(W+'t')).replace('\u00a0',' ')]
    assert len(ps)==1,(phrase,len(ps));p=ps[0];ts=list(p.iter(W+'t'));s=''.join(t.text or '' for t in ts)
    start=s.replace('\u00a0',' ').index(phrase);offset=start+phrase.index('. ')+1
    at=0
    for i,t in enumerate(ts):
        val=t.text or ''
        if at<=offset<at+len(val):
            pos=offset-at;assert val[pos] in [' ','\u00a0']
            if pos==len(val)-1 and i+1<len(ts):
                t.text=val[:-1];ts[i+1].text='\u00a0'+(ts[i+1].text or '');ts[i+1].set(XML+'space','preserve')
            else:t.text=val[:pos]+'\u00a0'+val[pos+1:]
            t.set(XML+'space','preserve');break
        at+=len(val)
    assert ''.join(t.text or '' for t in ts).replace('\u00a0',' ')==s.replace('\u00a0',' ')
    records.append({'phrase':phrase,'change':'Visible nonbreaking sentence space; wording and scientific content unchanged'})
parts['word/document.xml']=E.tostring(r,xml_declaration=True,encoding='UTF-8',standalone=True)
with ZipFile(DOCX,'w') as z:
    for info in infos:z.writestr(info,parts[info.filename])
(ROOT/'qa/Sentence_Space_Repairs.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
ledger=json.loads((ROOT/'Word_Change_Ledger.json').read_text(encoding='utf-8'));ledger.append({'operation':'formatting','sentence_boundaries':records})
(ROOT/'Word_Change_Ledger.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'stabilized_sentence_boundaries':len(records)}))
