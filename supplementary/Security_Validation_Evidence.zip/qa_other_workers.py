"""Read-only evidence checks, not new protocol/security experiments."""
from pathlib import Path
import json,hashlib,difflib,collections

ROOT=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
checks=[]
def check(name,v,details=None):
    checks.append({'check':name,'status':'PASS' if v else 'FAIL','details':details})

ep=ROOT/'exports/attempt_01';ec=read(ep/'contract.json');er=read(ep/'SV07_Results.json');receipt=read(ep/'execution_receipt.json')
check('export contract saved before execution',ec['created_before_execution_utc']<receipt['start_utc'])
check('export contract hash',sha(ep/'contract.json')==receipt['contract_sha256']==(ep/'contract.sha256').read_text().strip())
check('export script hash',sha(ROOT/'exports/run_sv07.py')==receipt['script_sha256']==ec['code_sha256'])
check('export exit0 and log hashes',receipt['exit_code']==0 and sha(ep/'stdout.log')==receipt['stdout_sha256'] and sha(ep/'stderr.log')==receipt['stderr_sha256'])
check('export 13 cases match contract', [x['id'] for x in er['cases']]==[x['id'] for x in ec['cases']] and len(er['cases'])==13)
check('export 12 pass plus one boundary',sum(x['status']=='PASS' for x in er['cases'])==12 and sum(x['status']=='OBSERVED_BOUNDARY' for x in er['cases'])==1)
before=read(ep/'original_seal_before.json');after=read(ep/'original_seal_after.json')
check('export 299 source entries unchanged and sealed',len(before['source_files'])==299 and before['source_files']==after['source_files'] and all(x['matches_sealed_input'] for x in before['source_files']))
check('export four protected files unchanged',len(before['protected_runtime_files'])==4 and before['protected_runtime_files']==after['protected_runtime_files'])
tokens=[f'PUBLIC_SV07_{x.upper()}_CANARY_20261011_ONLY'.encode() for x in ['payload','seed','mask','share','key','array','error','local','loss']]
safe=list((ep/'payload_safe_outputs').rglob('*.json'));control=list((ep/'controls').rglob('*.json'));boundary=list((ep/'metadata_boundary_observations').rglob('*.json'))
check('export nine selected outputs have no literal payload canaries',len(safe)==9 and not any(t in p.read_bytes() for t in tokens for p in safe))
check('export positive control detects all nine categories',len(control)==1 and all(t in control[0].read_bytes() for t in tokens))
mark=b'PUBLIC_SV07_METADATA_BOUNDARY_CANARY_ONLY'
check('export two boundary artifacts separately retained',len(boundary)==2 and all(mark in p.read_bytes() for p in boundary) and not any(t in p.read_bytes() for t in tokens for p in boundary))
c12=next(x for x in er['cases'] if x['id']=='SV07-12')
for row in c12['evidence']['files']:
    p=ep/row['path'];check('export output hash '+row['path'],sha(p)==row['sha256'] and p.stat().st_size==row['bytes'])

pp=ROOT/'protocol';pc=read(pp/'Acceptance_Contract.json');ps=read(pp/'Acceptance_Seal.json')
check('protocol contract hash and case count',sha(pp/'Acceptance_Contract.json')==ps['contract_sha256'] and len(pc['cases'])==ps['case_count']==59)
reports=[]
for n in [1,2]:
    ap=pp/f'attempt_{n:02d}';ar=read(ap/'Attempt_Receipt.json');pr=read(ap/'results/Protocol_Results.json');reports.append(pr)
    check(f'protocol attempt{n} script hash',sha(ap/'Executed_Script.py')==ar['script_sha256']==pr['script_sha256'])
    check(f'protocol attempt{n} contract and exit2',ar['contract_sha256']==ps['contract_sha256']==pr['contract_sha256'] and ar['exit_code']==2)
    check(f'protocol attempt{n} matching percase copies',all(read(ap/'results'/f"{r['id']}.json")==r for r in pr['cases']))
    check(f'protocol attempt{n} ordered cases equal contract',[r['id'] for r in pr['cases']]==[s['id'] for s in pc['cases']])
check('protocol seal before first execution',ps['utc_time']<read(pp/'attempt_01/Attempt_Receipt.json')['start_utc'])
script1=(pp/'attempt_01/Executed_Script.py').read_text();script2=(pp/'attempt_02/Executed_Script.py').read_text()
expected=script1.replace('compat.recorddict_to_fitres(reply.content).parameters','compat.recorddict_to_fitres(reply.content,keep_input=True).parameters')
check('protocol only retained B decoder repair',expected==script2,{'diff_lines':list(difflib.unified_diff(script1.splitlines(),script2.splitlines()))})
check('protocol source working script equals attempt2',sha(pp/'security_protocol_suite.py')==sha(pp/'attempt_02/Executed_Script.py'))
pr=reports[1]
check('protocol final counts',len(pr['cases'])==59 and pr['counts']['PASS']==58 and pr['counts']['FAIL']==1 and pr['counts']['ERROR']==0)
expected_settings={'num_shares':3,'reconstruction_threshold':2,'max_weight':4096.,'clipping_range':8.,'quantization_range':2**22,'modulus_range':2**31,'timeout':600.}
check('protocol main crypto settings match',pr['main_crypto_parameters']==expected_settings)
for spec,r in zip(pc['cases'],pr['cases']):
    check('protocol fixture matches sealed '+r['id'],r['fixture']==spec)
    if spec.get('mutation'):
        check('protocol mutation actually injected '+r['id'],r.get('fault_injected') is True)
    if spec['expectation']=='reject':
        expected_pass=bool(r.get('exception')) and r['exception']['type'] in spec['expected_exception_types'] and r['aggregate_callbacks']==0
        check('protocol negative classification '+r['id'],(r['status']=='PASS')==expected_pass)
        check('protocol rejected case zero accepted aggregate '+r['id'],r['aggregate_callbacks']==0)
    elif not spec.get('direct'):
        stages=r.get('observed_stages',r.get('stages'))
        error=r.get('max_abs_average_error');bound=r.get('quantization_bound',r.get('predeclared_error_bound'))
        check('protocol positive ordered stages and bound '+r['id'],stages==['setup','share_keys','collect_masked_vectors','unmask'] and r['aggregate_callbacks']==1 and error<=bound)
    if spec.get('stage') in ('setup','share_keys') and spec.get('mutation'):
        check('protocol pretraining rejection zero toyfit '+r['id'],r['total_local_fit_callbacks']==0)
bad=next(r for r in pr['cases'] if r['id']=='SV05_PARALLEL_LIST_LENGTH_MISMATCH')
check('protocol target FAIL retained accurately',bad['status']=='FAIL' and bad['exception']['type']=='KeyError' and bad['aggregate_callbacks']==0 and bad['total_local_fit_callbacks']==3 and bad['observed_stages'][-1]=='unmask')
restart=next(r for r in pr['cases'] if r['id']=='SV04_SETUP_RESTART_CHARACTERIZATION')
check('protocol allowed setup restart honestly characterized',restart['public_result']['upstream_setup_restart_allowed'] is True and restart['public_result']['not_a_replay_resistance_guarantee'] is True)
out={'scope':'independent read-only QA of other workers SV02-05/SV07 evidence; no new target test','status':'PASS' if all(x['status']=='PASS' for x in checks) else 'FAIL','checks_count':len(checks),'failed':[x for x in checks if x['status']=='FAIL'],'checks':checks}
(ROOT/'Independent_Evidence_Checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ['status','checks_count','failed']},indent=2))
