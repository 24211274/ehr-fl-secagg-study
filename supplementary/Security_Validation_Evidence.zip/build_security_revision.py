"""Surgical OOXML update; preserves original package parts and scientific tables."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from copy import deepcopy
from lxml import etree as E
import json, hashlib, shutil

ROOT=Path(__file__).resolve().parent
SRC=ROOT.parent/'ars_manuscript_update_v1_9_2026_10_11/Research_Report_Chapters_1_to_6_v1_9_ME06_Verified_Highlighted_20261011.docx'
OUT=ROOT/'delivery/Research_Report_Chapters_1_to_6_v1_10_SecurityValidation_Highlighted_20261011.docx'
OUT.parent.mkdir(exist_ok=True)
QA=ROOT/'qa';QA.mkdir(exist_ok=True)
W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
R='{http://schemas.openxmlformats.org/officeDocument/2006/relationships}'
REL='{http://schemas.openxmlformats.org/package/2006/relationships}'
NS={'w':W[1:-1]}
XML='{http://www.w3.org/XML/1998/namespace}'
def sha(b):return hashlib.sha256(b).hexdigest()
assert sha(SRC.read_bytes())=='8362f01c48e0be9f6b7458d2ae5a4ad9d140f882afc5a7527ac3a6f719287c4b'
with ZipFile(SRC) as z:
    infos=z.infolist();parts={i.filename:z.read(i.filename) for i in infos}
doc=E.fromstring(parts['word/document.xml']);body=doc.find(W+'body');old=list(body)
comments=E.fromstring(parts['word/comments.xml'])
cid=max(int(c.get(W+'id')) for c in comments)+1
ledger=[]
def txt(el):return ''.join((n.text or '') if n.tag==W+'t' else '\t' for n in el.iter() if n.tag in [W+'t',W+'tab'])
def run(s,color='green',size=None,bold=False):
    r=E.Element(W+'r');pr=E.SubElement(r,W+'rPr')
    E.SubElement(pr,W+'rFonts',{W+'ascii':'Times New Roman',W+'hAnsi':'Times New Roman'})
    if bold:E.SubElement(pr,W+'b')
    if size:E.SubElement(pr,W+'sz',{W+'val':str(size)})
    E.SubElement(pr,W+'highlight',{W+'val':color});E.SubElement(pr,W+'lang',{W+'val':'en-GB'})
    E.SubElement(r,W+'t',{XML+'space':'preserve'}).text=s
    return r
def para(s,style='BodyText',color='green'):
    p=E.Element(W+'p');pr=E.SubElement(p,W+'pPr');E.SubElement(pr,W+'pStyle',{W+'val':style})
    p.append(run(s,color));return p
def annotate(p,note):
    global cid
    ident=str(cid);cid+=1
    c=E.SubElement(comments,W+'comment',{W+'id':ident,W+'author':'Research audit',W+'date':'2026-10-11T16:00:00Z'})
    cp=E.SubElement(c,W+'p');cr=E.SubElement(cp,W+'r');E.SubElement(cr,W+'t').text=note
    pos=1 if p.find(W+'pPr') is not None else 0
    p.insert(pos,E.Element(W+'commentRangeStart',{W+'id':ident}));p.append(E.Element(W+'commentRangeEnd',{W+'id':ident}))
    rr=E.SubElement(p,W+'r');E.SubElement(rr,W+'commentReference',{W+'id':ident})
def after(idx,elements,note=None):
    anchor=old[idx]
    for el in elements:
        body.insert(body.index(anchor)+1,el);anchor=el
        ledger.append({'operation':'addition','source_anchor':f'F{idx:04d}','text':txt(el),'colors':sorted(set(el.xpath('.//w:highlight/@w:val',namespaces=NS)))})
    if note:
        p=next((e for e in elements if e.tag==W+'p'),None)
        annotate(p,note)
def splice(p,needle,replacement,color='yellow',insert=False):
    boundary='\u00a0' if insert and replacement.endswith(' ') else ''
    if boundary:replacement=replacement[:-1]
    before=txt(p);assert before.count(needle)==1,(needle,before)
    start=before.index(needle);end=start+(0 if insert else len(needle));at=0
    nodes=list(p.iter(W+'t'));done=False
    for t in nodes:
        s=t.text or '';lo=at;hi=at+len(s);at=hi
        if not done and lo<=start<hi:
            r=t.getparent();assert r.tag==W+'r'
            assert len(r.findall(W+'t'))==1
            cut=start-lo;last=deepcopy(r);last.find(W+'t').text=boundary+s[cut:]
            t.text=s[:cut];t.set(XML+'space','preserve');last.find(W+'t').set(XML+'space','preserve')
            new=run(replacement,color);parent=r.getparent();pos=parent.index(r)
            parent.insert(pos+1,new);parent.insert(pos+2,last)
            if not insert:
                consume=end-start
                for target in [last.find(W+'t')]+nodes[nodes.index(t)+1:]:
                    val=target.text or '';take=min(len(val),consume);target.text=val[take:];target.set(XML+'space','preserve');consume-=take
                    if not consume:break
                assert consume==0
            done=True;break
    assert done
    expected=before[:start]+replacement+boundary+before[end:];assert txt(p)==expected
    ledger.append({'operation':'revision' if not insert else 'insertion','old':before,'new':expected,'color':color})
def table(headers,rows,widths,colors=None):
    tbl=E.Element(W+'tbl');pr=deepcopy(old[808].find(W+'tblPr'));tbl.append(pr)
    layout=E.SubElement(pr,W+'tblLayout',{W+'type':'fixed'})
    tw=pr.find(W+'tblW');tw.set(W+'w',str(sum(widths)));tw.set(W+'type','dxa')
    grid=E.SubElement(tbl,W+'tblGrid')
    for n in widths:E.SubElement(grid,W+'gridCol',{W+'w':str(n)})
    for i,row in enumerate([headers]+rows):
        tr=E.SubElement(tbl,W+'tr');trpr=E.SubElement(tr,W+'trPr');E.SubElement(trpr,W+'cantSplit')
        if i==0:E.SubElement(trpr,W+'tblHeader')
        for j,s in enumerate(row):
            tc=E.SubElement(tr,W+'tc');tp=E.SubElement(tc,W+'tcPr');E.SubElement(tp,W+'tcW',{W+'w':str(widths[j]),W+'type':'dxa'})
            E.SubElement(tp,W+'vAlign',{W+'val':'top'})
            if i==0:E.SubElement(tp,W+'shd',{W+'fill':'D9E2F3',W+'val':'clear'})
            p=E.SubElement(tc,W+'p');pp=E.SubElement(p,W+'pPr');E.SubElement(pp,W+'spacing',{W+'before':'40',W+'after':'60',W+'line':'240',W+'lineRule':'auto'})
            color='cyan' if i==0 else ('green' if colors is None else colors[i-1])
            p.append(run(s,color,size=21,bold=i==0))
    return tbl
def nav_after(idx,label):
    p=deepcopy(old[idx]);assert '\t' in txt(p)
    pr=p.find(W+'pPr');p[:]=[pr]
    p.append(run(label,'cyan'));r=E.SubElement(p,W+'r');E.SubElement(r,W+'tab');p.append(run('1','cyan'))
    body.insert(body.index(old[idx])+1,p)
    ledger.append({'operation':'navigation_entry','text':txt(p),'color':'cyan'})

# Abstract additions preserve all pre-existing rich runs and comments.
splice(old[32],'Protection claims are limited','A later bounded security-validation suite recorded 99 passing cases, one unmet controlled-rejection criterion and one diagnostic-metadata boundary; it did not certify security. ','green',True)
splice(old[36],'Tuntutan perlindungan adalah terhad','Pengujian keselamatan terhad kemudian merekodkan 99 PASS, 1 FAIL bagi penolakan terkawal dan 1 batas metadata; keselamatan tidak diperakui. ','green',True)
annotate(old[32],'Later local validation: Table 4.16 and Appendix D.9; 101 selected case records =99 PASS+1 FAIL+1 OBSERVED_BOUNDARY. No new benchmark performance claim.')
annotate(old[36],'Malay abstract updated to reflect the same later bounded validation and unmet criterion as the English abstract.')

method=[
para('Later bounded security validation (11 October 2026). After the historical benchmark and ME-06 replay, seven groups of implementation checks were executed against the retained Flower 1.22.0+mai.prg7570.1 environment. Acceptance contracts and script identities were sealed before these new executions, after the original results were already known. This was a separately dated implementation audit, not retrospective prespecification of the main study.'),
para('The checks used public arrays, in-memory participant contexts and selected direct calls to project validators. Protocol fixtures used three clients, three shares, threshold two, maximum weight 4096, clipping range 8, quantization range 2^22 and modulus 2^31. All three participants remained required. Tiny public fit budgets and one round per protocol case replaced the benchmark workload; no benchmark training, inference or learned-checkpoint loading was performed.'),
para('SV-01 checked the installed helper, wheel contents, public HMAC/decoder vectors and a constructed legacy-fold collision control. SV-02 checked numerical aggregation and range/weight/shape boundaries. SV-03 observed replies at server ingress and exercised named field allowlists. SV-04 exercised cohort, stage and round guards. SV-05 injected selected malformed keys, encrypted shares and routing lists. SV-06 compared freshly generated contexts in memory. SV-07 exercised the measurement observer and failure capsule with public canaries.'),
para('The harness executed installed Flower ClientApp/SecAgg code and the project StrictSecAggPlusWorkflow and named cohort, wire, range and restoration validators. Its toy strategy and client guard were fixtures; the guard mirrored selected project rules with a public-budget exception. The B positive control was a plain Flower reply rather than the complete EHR B application. Export tests substituted only measurement_scope() with a public fixture. Therefore these checks do not constitute a full benchmark application or network-deployment test. Appendix D.9 records the execution paths, criteria, retained attempts and unexecuted scope.','BodyText','yellow')]
after(365,method,'New execution evidence only; exact harness boundaries and main cryptographic constants are in protocol/Acceptance_Contract.json, PRG contract and export contract. Targets were not patched.')

rows=[
['SV-01\nRuntime and mask helper','28 PASS','424 installed Flower runtime files matched the candidate wheel; public vectors, 15 moduli and constructed legacy-fold control matched.'],
['SV-02\nNumerical and range checks','17 PASS','Five positive aggregation fixtures met their own numerical bounds; selected invalid range, weight and shape inputs were rejected.'],
['SV-03\nMessage ingress','7 PASS','Plain B control exposed its public array; positive C replies contained masked blobs and no populated plaintext ArrayRecord. Named extra fields were rejected.'],
['SV-04\nCohort, stage and round','28 PASS','Selected missing, duplicate, foreign and error replies were refused at each stage. No rejected fixture accepted an aggregate. SETUP restart was an allowed-behaviour characterization.'],
['SV-05\nKey/share corruption','6 PASS; 1 FAIL','Unequal ciphertext/source-list lengths caused late KeyError at UNMASK. Zero aggregate accepted, but the required controlled rejection was not achieved.'],
['SV-06\nFreshness diagnostics','1 PASS','20 three-client sessions showed no within-category reuse in the compared generated contexts. This finite diagnostic is not an entropy or unpredictability proof.'],
['SV-07\nSelected exported records','12 PASS; 1 boundary','Nine selected JSON outputs omitted all nine literal payload canaries. Permitted diagnostic metadata retained a public marker in two separate artifacts.']]
res=[para('4.11 Bounded security-validation results','Heading2'),
para('The seven groups completed on 11 October 2026 in the retained local environment. The selected result set contains 101 case records: 99 PASS, one FAIL and one OBSERVED_BOUNDARY (Table 4.16). Case records, rather than assertions or repeated sessions, are the counting unit. No selected contract case was NOT_RUN. These outcomes describe tested implementation behaviour under the local trusted-host assumptions; they do not establish a general security guarantee.'),
para('Table 4.16: Executed bounded security-validation groups','TableCaption','cyan'),table(['Group','Selected outcome','Observed result and limit'],rows,[1800,1600,5000],['green']*4+['yellow','green','yellow']),
para('All five positive aggregation fixtures completed the ordered four stages with one accepted aggregate. Equal- and unequal-weight lattice controls recovered their integer sums exactly. The largest maximum absolute aggregation error was 2.05046 × 10^-5 in the off-grid control, below its predeclared bound of 1.23978 × 10^-4. The strict boundary fixture, with weights [4096, 4096, 4096] and parameter magnitudes up to 8, had error 7.94729 × 10^-8, below 9.53674 × 10^-6. Each bound applies to its named public fixture, rather than being a privacy metric.'),
para('The retained failure was SV05_PARALLEL_LIST_LENGTH_MISMATCH. Removing one source ID while retaining its ciphertext list caused KeyError(\'22\') at UNMASK after three toy fit callbacks. No aggregate callback was accepted and the toy aggregate state did not advance. The sealed criterion required ValueError or RuntimeError rejection before an accepted aggregate; that controlled-error criterion failed. The case does not demonstrate a disclosed update or an accepted corrupted aggregate. Early explicit list-alignment validation remains an open hardening item.','BodyText','yellow'),
para('SV-07 also exposed a reporting boundary: request IDs, exception-class names and traceback file/function metadata are retained as permitted diagnostic fields. A public marker survived in two boundary artifacts. The nine separately designated payload-safe outputs contained none of the nine literal payload canaries, and the deliberately unsafe positive control contained all nine. This supports the selected payload checks, while arbitrary or sensitive content in permitted metadata still requires review before external sharing.','BodyText','yellow'),
para('Both protocol attempts are retained. Attempt 01 had 57 PASS and two FAIL records; one failure was a harness decoder call missing keep_input=True. Only that API call was repaired. Attempt 02 had 58 PASS and one target FAIL, with the acceptance contract and target code unchanged. Both exited with code 2 because an unmet criterion remained. The other groups completed in their first attempts. The original 299 source/preprocessing inventory entries and the four sealed runtime/build files matched before and after execution. Performance and system-cost tables were not recalculated or replaced.','BodyText','cyan')]
after(532,res,'Actual selected outcomes: prg/results_attempt_01.json, protocol/attempt_02/results/Protocol_Results.json, exports/attempt_01/SV07_Results.json. Earlier attempt retained; one genuine criterion FAIL remains open.')

after(545,[para('The later validation in Section 4.11 adds direct server-ingress observations for public fixtures and selected negative tests. It recorded an unexpected late error for unequal routing-list lengths, and a diagnostic-metadata boundary. These findings narrow the implementation claim: the tested C interface omitted populated plaintext parameter records, but neither inference resistance nor comprehensive malformed-message handling was established. The tests did not measure attack success or privacy loss.','BodyText','yellow')],'RQ2 interpretation qualified by observed FAIL and metadata limit; no new privacy metric.')
after(587,[para('The later bounded suite improves evidence for helper conformance, selected message checks, numerical aggregation and observed context freshness. It leaves the SV-05 controlled-rejection finding open and assumes that permitted diagnostic metadata is public and trusted. No formal cryptographic certification, arbitrary-collusion test, shared-host isolation test or TLS deployment validation was performed. These tests do not resolve the separate data-provenance, clinical-label or ethics uncertainties.','BodyText','yellow')],'New security checks do not resolve ethics/data provenance or establish production security.')
after(606,[para('The later implementation audit completed seven bounded security-test groups, with 99 PASS, one unmet controlled-rejection criterion and one diagnostic-metadata boundary among 101 selected records (Section 4.11; Appendix D.9). It strengthens evidence for the named helper and aggregation checks while identifying required input-validation hardening. It does not establish quantified privacy protection, comprehensive replay resistance or security against the shared-host administrator. The original RQ utility and cost conclusions remain unchanged.','BodyText','yellow')],'Conclusion only summarizes Results 4.11; no new findings or all-pass claim.')

# Supplement the objective/support tables without deleting previous anchors.
for index,needle,addition in [
    (550,'Execution of the pinned SecAgg+ path',' Later public-fixture checks: Section 4.11 and Appendix D.9; one controlled-rejection criterion remains unmet.'),
    (608,'Section 3.8; Tables C.2/C.5; attributed source patch','; later checks in Section 4.11 and Appendix D.9 (one FAIL; metadata boundary)')]:
    ps=[p for p in old[index].iter(W+'p') if needle in txt(p)];assert len(ps)==1
    ps[0].append(run(addition,'green'));ledger.append({'operation':'table_evidence_addition','source_anchor':f'F{index:04d}','text':addition,'color':'green'})

evidence_rows=[
['SV-01 / SV-06','prg/','contract.json; sealed_before_execution_attempt_01.json; execution_receipt_attempt_01.json; results_attempt_01.json; stdout/stderr; run_checks.py.'],
['SV-02 to SV-05','protocol/','Acceptance_Contract/Seal; both attempt folders with executed scripts, receipts, logs and 59 case JSONs each; Harness_Repair_01; final report and summary.'],
['SV-07','exports/','attempt_01 contract, receipt, logs, source seals, 13 case records, nine selected outputs, positive control and two metadata-boundary artifacts.'],
['Consolidated evidence','Root of security attachment','Results.csv; Security_Validation_Summary.json; Arabic report; independent read-only evidence checks; MANIFEST.json with payload sizes and SHA-256 identities.']]
notrun=[
['TLS/network and institutional authentication','NOT RUN','The suite used in-memory calls on the trusted local host. No deployment certificates, remote identity boundary or network scenario was introduced.'],
['Compromised host, malicious server or arbitrary collusion','NOT RUN','The stated study assumes a trusted host and honest, noncolluding participants. The harness owns all toy contexts and cannot demonstrate isolation. With three clients, the aggregate and two known contributions algebraically expose the third.'],
['Gradient inversion, membership inference or DP accounting','NOT RUN','No defined attack protocol, attack baseline, privacy budget or relevant success metric was part of these seven contracts. Named field checks are not an attack evaluation.'],
['Poisoning/Byzantine robustness and general replay security','NOT RUN','The study does not use a robust aggregation defence. Selected route/stage/round tests do not cover an arbitrary adversary; upstream SETUP restart remained allowed.'],
['Formal PRG/security or entropy certification','NOT RUN','Public conformance vectors and finite freshness comparisons cannot prove cryptographic security. Independent cryptographic analysis remains separate.'],
['New full benchmark or independent network/host replication','NOT RUN in this suite','Public fixtures isolate implementation behaviour. The earlier ME-06 computational replay is documented separately; no new detector performance or wire/isolated-crypto cost measurement was made.'],
['Complete private-log/store and arbitrary-encoding secret scan','NOT RUN','SV-07 covered selected observer/capsule outputs and literal public canaries. Host process memory, all private logs/stores and semantic secrets in permitted metadata were outside this contract.']]
d9=[para('D.9 Executed bounded security validation and retained findings','Heading2','cyan'),
para('Execution status: all seven named groups and all 101 selected contract records were executed. Selected status totals are 99 PASS, 1 FAIL and 1 OBSERVED_BOUNDARY; no selected case was NOT_RUN. PASS means that the case-specific contract was met. For negative fixtures it means the expected refusal was observed, while the SETUP-restart case records allowed behaviour. The 20 freshness sessions are one grouped diagnostic case, not 20 independent security experiments.','AppendixText','cyan'),
para('Acceptance and timing. The PRG/freshness contract SHA-256 is 133172442839c69da1553dc538fdb6e8dfc1bab673549e7f27391cbbd8bd5a22; protocol contract ad167328e3ebd66e191bccfe37b56a1245ef1c77a4af9016ebe2f9c45f826ea7; export contract 1a07f4601d6132c9db4dd8aa6c9c33ec81d0ed80e45a69511e85268bf5c3166b. New executions occurred on 11 October 2026 at 15:42–15:44 UTC (23:42–23:44 Asia/Singapore). Exact receipt times and script hashes are retained. These contracts preceded these tests, not the historical benchmark.','AppendixText','cyan'),
para('Environment and data boundary. The suite used Python 3.12.3 in the preserved Ubuntu-24.04 environment and installed Flower 1.22.0+mai.prg7570.1. The installed helper SHA-256 was 62935b91cf10f41f2036f8ccdbe65f257de86d4ada65cff7ff9fe254927c361c. A wheel/RECORD check matched 424 runtime files. Raw benchmark data and learned weights were not needed. Generated protocol secrets were compared in memory only; no secret values or digests were exported. The inventory check covered 299 sealed source/preprocessing entries and four listed runtime/build files, rather than every file on the host.','AppendixText','cyan'),
para('Table D.12: Security-validation evidence inventory','TableCaption','cyan'),table(['Scope','Attachment location','Retained evidence'],evidence_rows,[1600,1500,5300],['cyan']*4),
para('Execution-path fidelity. The protocol harness combined actual installed Flower code and named project validators with a toy strategy and a toy-aware replica client guard. Three retained public oracle cases used the upstream workflow/client path. Selected direct cases called actual project methods before data/model access. The B control was a native plain Flower reply, not the complete B benchmark app. In SV-07, observer and capsule functions were actual project code; measurement_scope() was substituted with a public fixture. These distinctions prevent interpreting every case as an end-to-end application or network test.','AppendixText','yellow'),
para('SV-06 freshness. Twenty independent three-client sessions were created while resetting the same public NumPy seed to 177 for each session. In-memory comparisons found 120 distinct public-key representations and 120 distinct private-key representations, 60 self-seed contexts, 60 pairwise mask-key contexts, 60 share-encryption-key contexts and 60 masked-reply contexts within their respective categories. Matching peers derived matching keys. The installed setup/share/collect functions ran; UNMASK was not run in this freshness group because it tested generated-context reuse. Complete four-stage numerical fixtures are reported in SV-02. No entropy or unpredictability claim follows from finite non-reuse.','AppendixText'),
para('Open finding SV-05. Unequal ciphertext/source-ID list lengths reached UNMASK and raised KeyError(\'22\') after three toy fit callbacks. Accepted aggregate callbacks and toy state advances were both zero. The expectation was a controlled ValueError or RuntimeError refusal, so the status remains FAIL in both protocol attempts. Recommended correction: add explicit equal-length and expected-source identity validation before processing the shares/local fit, version the changed implementation and rerun the unchanged case and positive controls. No target patch was applied in this validation task. No evidence shows the historical benchmark contained this malformed request.','AppendixText','yellow'),
para('SV-07 metadata boundary. Nine designated output JSONs contained none of nine literal public payload canaries; the scanner positive control detected 9/9. Two separately retained artifacts contained the permitted public-metadata marker in request ID, exception class or traceback file/function fields. The result is OBSERVED_BOUNDARY, not a universal sanitization PASS. Review permitted metadata before external release, or implement a separately tested stricter metadata policy if such fields may contain sensitive content. All fixture canaries and deliberately unsafe control files in this attachment are public synthetic markers, not real EHR data or real protocol secrets.','AppendixText','yellow'),
para('Attempt retention and evidence review. The first protocol run retained 57 PASS and 2 FAIL records. A missing keep_input=True argument in the harness B-control decoder caused one of those failures; only that API call was repaired. The selected second run retained 58 PASS and the same target FAIL; both exit codes were 2. Other groups completed on their first run. A separate read-only review completed 244 artifact/contract/hash/classification checks of SV-02–SV-05 and SV-07 with no discrepancies; these were evidence checks, not additional security tests. Root review also inspected SV-01/SV-06 code, contracts and observed results.','AppendixText','cyan'),
para('Table D.13: Unexecuted security scope and reasons','TableCaption','cyan'),table(['Additional scope','Status','Reason and claim boundary'],notrun,[2400,1500,4500],['yellow']*7),
para('Status of the earlier missing-evidence items. For ME-10, bounded implementation validation is now executed with the retained SV-05 finding and metadata limitation; broad privacy/security assurance remains unestablished. ME-11 is unchanged: these checks do not measure isolated cryptographic time or full-wire traffic. ME-06 remains the separately documented computational replay. The present validation also does not resolve ME-02 label validity, ME-04/05 historical discovery records, external generalisation or the formal ethics status.','AppendixText','yellow'),
para('Security_Validation_Evidence.zip accompanies this revision. Results.csv indexes every selected case and its underlying record. Both protocol attempts, acceptance contracts, executed harnesses, stdout/stderr, receipts, selected public output artifacts, source seals and independent evidence checks are retained. MANIFEST.json provides byte sizes and SHA-256 identities. The attachment depends on the preserved project/runtime identified in the receipts; it is not a standalone redistributed EHR dataset or a fresh-environment installation certificate. Keep ME06_Evidence.zip alongside this document for the earlier reproduction link.','AppendixText','cyan')]
after(812,d9,'Executed results and open items. No selected case omitted. Table D.13 lists scope not run and why. Security attachment contains public canary controls deliberately designed to be detected.')
after(822,[para('The later security-validation suite supports only the named implementation observations in Section 4.11. Its controlled-rejection failure and retained diagnostic-metadata boundary prevent an all-pass or comprehensive-protection statement. The suite is additional local execution evidence, not quantified privacy assurance or independent production certification.','AppendixText','yellow')],'Final protection claim aligned to actual new results including FAIL.')
after(823,[para('The separately dated bounded security validation was executed later on 11 October 2026, after the ME-06 replay. It adds the actual outcomes, retained unsuccessful attempt and open input-validation finding in Section 4.11 and Appendix D.9. Neither the source implementation nor the original predictive/system-cost tables were changed by that suite.','AppendixText','cyan')])
after(824,[para('Highlight key for this security revision: green = added executed methods, results and evidence; yellow = revised interpretation, limitations and required correction; cyan = execution status, provenance, attachment and navigation records. Existing highlights/comments remain. The four small editorial corrections are yellow; they do not alter results.','AppendixText','cyan')])

# Four bounded editorial issues already identified by the preceding final review.
splice(old[357],'Eavesdropping, malicious coordination, compromised endpoints and client collusion were not tested.','The main benchmark did not evaluate eavesdropping, malicious coordination, compromised endpoints or client collusion. The subsequent selected negative fixtures in Section 4.11 do not establish protection against these threats.')
splice(old[362],'the installed wheel payload was not supplied.','the historical installed wheel payload was not supplied. The subsequent candidate rebuild and runtime checks are documented separately in Appendix D.8 and Section 4.11.')
splice(old[364],'Tests with missing replies or mismatched identifiers','In the historical records, tests with missing replies or mismatched identifiers')
old[364].append(run(' The subsequent suite records local toy-fit and accepted-aggregate callbacks separately, including local work before late-stage rejection (Section 4.11).','yellow'))
ledger.append({'operation':'qualification','source_anchor':'F0364','text':'Historical callback evidence distinguished from later executed counts.','color':'yellow'})
splice(old[726],'The results below are from the recorded candidate-build public protocol check, not newly run cryptographic tests.','The results below are historical candidate-build public-protocol records, distinct from the later bounded suite in Section 4.11 and Appendix D.9. These historical fixtures were not rerun during the earlier source-only audit.')
bp=[p for p in old[746].iter(W+'p') if 'Recorded functional fixtures and local range guards' in txt(p)];assert len(bp)==1
splice(bp[0],'Recorded functional fixtures and local range guards, not all-dimensional saturation tests, malicious-input tests or a cryptographic proof','Historical functional fixtures and local range guards; later selected malformed-input tests are reported in Section 4.11. Neither set is an exhaustive saturation/attack assessment or cryptographic proof')
old[747].append(run(' The later bounded security-validation execution is documented separately in Section 4.11 and Appendix D.9.','yellow'))
ledger.append({'operation':'qualification','source_anchor':'F0747','text':'Later security execution cross-reference added.','color':'yellow'})
o3=[p for p in old[608].iter(W+'p') if 'Aggregation path and bounded numerical checks completed' in txt(p)];assert len(o3)==1
o3[0].append(run('; the later suite retained one unmet controlled-rejection criterion and a metadata boundary.','yellow'))
ledger.append({'operation':'table_conclusion_qualification','source_anchor':'F0608','text':'Unmet criterion and metadata boundary retained.','color':'yellow'})
splice(old[296],'Sutradhar et al. (2026) places','Sutradhar et al. (2026) place')
splice(old[665],'Lazzarini et al. supplies','Lazzarini et al. supply')
splice(old[665],'McMahan et al. supplies','McMahan et al. supply')
splice(old[430],'Note. Five-seed post-update means, not detection metrics.','Note. Five-seed reconstruction-loss means, including the initial model at iteration 0; these are not detection metrics.')
splice(old[807],'Table D.11 Completed','Table D.11: Completed')
splice(old[203],'Table D.11 Completed','Table D.11: Completed')
annotate(old[430],'Figure 4.1 includes iteration 0; corrected the note without changing the figure or values. Figure 4.2 refers to the same note.')

nav_after(98,'4.11 Bounded security-validation results')
nav_after(144,'D.9 Executed bounded security validation and retained findings')
nav_after(183,'Table 4.16: Executed bounded security-validation groups')
# Insert both new appendix table entries in order.
nav_after(203,'Table D.13: Unexecuted security scope and reasons')
nav_after(203,'Table D.12: Security-validation evidence inventory')

# Preserve visible whitespace at inherited body-run boundaries; compact only the table list.
space_nodes=0
for p in body.findall(W+'p'):
    for t in p.iter(W+'t'):
        s=t.text or ''
        if (s.startswith(' ') or s.endswith(' ')) and t.get(XML+'space')!='preserve':
            t.set(XML+'space','preserve');space_nodes+=1
    style=p.xpath('./w:pPr/w:pStyle/@w:val',namespaces=NS)
    if style and style[0]=='TOCEntry' and txt(p).startswith('Table '):
        pr=p.find(W+'pPr');sp=pr.find(W+'spacing')
        if sp is None:sp=E.SubElement(pr,W+'spacing')
        sp.set(W+'after','20')
ledger.append({'operation':'formatting','text':'Preserved boundary whitespace in direct body paragraphs and reduced list-of-tables after-spacing from 40 to 20 twips to avoid an orphan entry.','whitespace_nodes':space_nodes,'content_values_unchanged':True})
old[36].find(W+'pPr').find(W+'spacing').set(W+'line','300')
old[37].find(W+'pPr').find(W+'spacing').set(W+'before','60')
ledger.append({'operation':'formatting','text':'Malay abstract line spacing 320 to 300 twips (1.33 to 1.25 lines), keyword before-spacing 120 to 60 twips; preserve body/keywords on one page without changing font size or scientific meaning.'})

# Relative evidence hyperlink, preserving the existing ME-06 target.
rels=E.fromstring(parts['word/_rels/document.xml.rels']);used={x.get('Id') for x in rels};n=1
while f'rId{n}' in used:n+=1
rid=f'rId{n}'
E.SubElement(rels,REL+'Relationship',{'Id':rid,'Type':R[1:-1]+'/hyperlink','Target':'Security_Validation_Evidence.zip','TargetMode':'External'})
p=next(p for p in body.findall(W+'p') if txt(p).startswith('Security_Validation_Evidence.zip accompanies'))
r=p.find(W+'r');assert r.find(W+'t').text.startswith('Security_Validation_Evidence.zip')
link=E.Element(W+'hyperlink',{R+'id':rid});lr=deepcopy(r);lr.find(W+'t').text='Security_Validation_Evidence.zip';link.append(lr)
r.find(W+'t').text=r.find(W+'t').text[len('Security_Validation_Evidence.zip'):];p.insert(p.index(r),link)
parts['word/document.xml']=E.tostring(doc,xml_declaration=True,encoding='UTF-8',standalone=True)
parts['word/comments.xml']=E.tostring(comments,xml_declaration=True,encoding='UTF-8',standalone=True)
parts['word/_rels/document.xml.rels']=E.tostring(rels,xml_declaration=True,encoding='UTF-8',standalone=True)
with ZipFile(OUT,'w',ZIP_DEFLATED) as z:
    for info in infos:z.writestr(info,parts[info.filename])
shutil.copy2(SRC.parent/'ME06_Evidence.zip',OUT.parent/'ME06_Evidence.zip')
(ROOT/'Word_Change_Ledger.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2),encoding='utf-8')
(QA/'Current_Revised_Text.txt').write_text('\n\n'.join(txt(el) for el in body),encoding='utf-8')
original_comments=360
unchanged_tables=[i for i,p in enumerate(old) if p.tag==W+'tbl' and i not in [550,608,746]]
with ZipFile(SRC) as z: original_body=E.fromstring(z.read('word/document.xml')).find(W+'body')
assert all(E.tostring(old[i])==E.tostring(original_body[i]) for i in unchanged_tables)
assert all(parts[n]==ZipFile(SRC).read(n) for n in parts if n.startswith('word/media/'))
(QA/'Authoring_Integrity.json').write_text(json.dumps({'source_sha256':sha(SRC.read_bytes()),'new_docx_sha256':sha(OUT.read_bytes()),'preserved_existing_tables':len(unchanged_tables),'supplemented_evidence_tables':[550,608,746],'original_comments_retained':original_comments,'new_comments':len(comments)-original_comments,'new_tables':3,'all_media_unchanged':True,'existing_ME06_attachment_copied':True},indent=2),encoding='utf-8')
print(json.dumps({'docx':str(OUT),'sha256':sha(OUT.read_bytes()),'ledger_records':len(ledger),'comments':len(comments)}))
