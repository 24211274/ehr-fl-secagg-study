# دليل إعادة التشغيل والأدلة الخاصة بـ ME-06

هذا الدليل يشرح الوصفة المنفّذة للتجهيز، والوصفة اللاحقة للتدريب والتقييم والمقارنة. **وجود الدليل لا يعني اكتمال التدريب أو نجاح إعادة إنتاج النتائج.** تُقرأ الحالة الفعلية من الإيصالات وملفات الحالة المشار إليها أدناه. الملفات الأصلية ونتائج سبتمبر محفوظة للمقارنة، ولا تُستبدل بالمخرجات الجديدة.

## النطاق الذي يمكن إثباته

تبدأ الإعادة من **لقطة CSV الأصلية المقدمة** داخل `assets/benchmark.zip`، وليس من توليد بيانات جديدة. المولّد الأصلي الكامل وبذرته الدقيقة لم يُثبت توافرهما؛ لذلك لا تثبت هذه الإعادة القدرة على إعادة توليد لقطة البيانات نفسها. كما لا تمنح الحزمة إذنًا جديدًا بنشر البيانات للعامة.

البناء والتشغيل داخل Ubuntu-24.04، بمستخدم `mai` غير root وPython 3.12 وبيئة `.venv` جديدة، على **الجهاز نفسه**. هذا يختبر إعادة البناء والتشغيل في بيئة جديدة على نفس المضيف؛ ولا يُسمّى تجربة نفّذها باحث خارجي على جهاز مستقل. لا تحتوي الحزمة المقترحة على تثبيت نظام التشغيل أو حزم النظام الأساسية؛ تُسجّل هذه المتطلبات ويجب توفيرها وفحصها عند تشغيل خارجي لاحق.

المجلد الفعلي داخل WSL:

```text
/home/mai/ehr_me06_reproduction_20261011_v1
```

مجلد التحكم والتقارير في Windows:

```text
C:/Users/RNO/Desktop/Coureses/P1/ars_me06_execution_2026_10_11
```

الشفرة العلمية محفوظة في `source` بنسخة مطابقة لـ **215 ملفًا مدرجًا** في manifest الأصلي، إضافة إلى ملف manifest نفسه. مصدر المعالجة محفوظ في `preprocessing_source` بنسخة مطابقة لـ **84 ملفًا مدرجًا**، إضافة إلى manifest. المحوّلات الجديدة في `portable` خارج المصدر الأصلي؛ لا تغيّر النموذج أو الخسارة أو المحسّن أو الميزانية أو العتبات أو المقاييس.

## ما ثبت بالفعل عند إعداد الدليل، وما يبقى متعلقًا بالتشغيل

| المرحلة | الدليل الفعلي | معنى الحالة |
|---|---|---|
| بناء Flower والبيئة الجديدة | [Bootstrap_Status.json](C:/Users/RNO/Desktop/Coureses/P1/ars_me06_execution_2026_10_11/Bootstrap_Status.json)، و`receipts/flower_rebuild.json` و`receipts/fresh_environment.json` داخل WSL | `FRESH_ENVIRONMENT_PASS`: بناء candidate من stock وتطابق البصمة، تثبيت جديد مقيد بالبصمات، 48 إصدارًا مطابقًا، استيرادات من البيئة الجديدة |
| المعالجة من الخام وإعادتها | [fresh_preprocessing_execution.json](C:/Users/RNO/Desktop/Coureses/P1/ars_me06_execution_2026_10_11/fresh_preprocessing_execution.json)، و`preprocessing/reports/stage_status.json` و`replay.json` | تشغيل فعلي ناجح من الخام؛ إعادة المعالجة الحالية مطابقة بتًا ببت داخل البيئة الجديدة |
| مقارنة التحضير التاريخي | [Preprocessing_Comparison.json](C:/Users/RNO/Desktop/Coureses/P1/ars_me06_execution_2026_10_11/Preprocessing_Comparison.json) | المصفوفات الثلاثون مطابقة تمامًا؛ يوجد فرق تشخيصي واحد في JSON كما هو موضح أدناه |
| ربط البيانات الوصفية | [canonical_metadata_binding_execution.json](C:/Users/RNO/Desktop/Coureses/P1/ars_me06_execution_2026_10_11/canonical_metadata_binding_execution.json)، و`preprocessing/bound_trainval/ME06_Metadata_Binding.json` | إجراء فعلي ناجح ومصرّح به، مع حفظ الخام وعدم إخفاء استثناء JSON |
| إعداد التجارب والفحوص الأصلية | `campaign/prepare_reports/me06_preparation_status.json` | لا يُعد ناجحًا إلا عند `ME06_FRESH_PREPARATION_COMPLETE_NO_FINAL_TESTS` |
| التدريب والتقييم والمقارنة | `ME06_Launch_Status.json` في Windows أثناء انتظار الإعداد، ثم `ME06_Full_Execution_Status.json` و`full_chain/status.json`، و`campaign/me06_train_progress.json`، و`comparison/comparison_status.json` | لا يُستنتج الاكتمال من هذه الوصفة. يجب فحص الحالات النهائية وإيصالات التنفيذ والمقارنة نفسها |

يُرجع لملفات الحالة الحية لمعرفة المرحلة وعدد التجارب المكتملة؛ لا يثبت هذا الدليل عددًا متغيرًا أو إعلان نجاح مسبقًا. قد ينتظر المشغل المراجع اكتمال إعداد الحملة ثم يبدأ السلسلة تلقائيًا بعد تحقق الإيصالات؛ هذا استمرار للعمل المصرح به في العملية الحالية، وليس جدولة تشغيل دوري.

أُطلقت عملية الانتظار والسلسلة الفعلية في `2026-10-10 18:13:24 UTC`، بينما كان إعداد الحملة جاريًا. يبدأ التدريب بعد تحقق إيصالَي الإعداد الخارجي والداخلي فقط؛ إطلاق عملية الانتظار لا يعني أن أول نموذج تدرب. يُقرأ تقدمها الحالي من [ME06_Launch_Status.json](C:/Users/RNO/Desktop/Coureses/P1/ars_me06_execution_2026_10_11/ME06_Launch_Status.json)، ثم من ملف التنفيذ الكامل عندما يُنشأ.

**تحديث موثق بعد انتهاء التشغيل:** يسجل [ME06_Full_Execution_Status.json](C:/Users/RNO/Desktop/Coureses/P1/ars_me06_execution_2026_10_11/ME06_Full_Execution_Status.json) الاكتمال عند `2026-10-11 02:39:58 UTC` بحالة `ME06_FULL_CHAIN_COMPLETE` و`exit_code=0`: اكتملت 30 تجربة تدريب و60 خلية تقييم والمقارنة. يؤكد [إيصال العملية الفعلية](C:/Users/RNO/Desktop/Coureses/P1/ars_me06_execution_2026_10_11/full_execution_chain_execution.json) خروج العملية بنجاح. يوضح [تقرير المقارنة](C:/Users/RNO/Desktop/Coureses/P1/ars_me06_execution_2026_10_11/ME06_Comparison_Report.md) ومرفق [حالتها](C:/Users/RNO/Desktop/Coureses/P1/ars_me06_execution_2026_10_11/ME06_Comparison_Status.json) نطاق التطابق الدقيق؛ تظل قيود البيانات الثابتة والجهاز نفسه واستثناء JSON أدناه جزءًا من الحكم. الأوامر اللاحقة وصف لما نُفّذ، ولا تستلزم إعادة التشغيل في الحملة المكتملة.

## استثناء JSON: ما الذي تغير، وما الذي لم يتغير؟

ظهر اختلاف واحد فقط بين scaler التاريخي والمُعاد حسابه من الخام:

```text
client_summaries[2].M2[1]  (C3)
التاريخي: 117745.299590386    = 0x1.cbf14cb1f49e1p+16
الجديد:   117745.29959038601  = 0x1.cbf14cb1f49e2p+16
```

الفارق هو **عدد float64 مجاور واحد، أي 1 ULP**. جميع حقول scaler الأخرى، بما فيها الإحصاءات المدمجة `mean/M2/variance/scale`، متطابقة تمامًا. **معلمات التحويل المطبقة `mean/scale` والمصفوفات الثلاثون متطابقة بالقيم وdtype والشكل وبصمات ملفات NPY.** اختلاف بيئة التحضير القديمة والجديدة موثّق، لكن السبب الدقيق لهذا الفارق لم يُعزل تجريبيًا؛ لا يُنسب تلقائيًا للعشوائية أو لإصدار محدد.

المشغل الأصلي يشترط بصمة ملف scaler كاملًا، بما يشمل هذا التشخيص. لذلك أُنشئ `preprocessing/bound_trainval` كنسخة منفصلة من المخرجات الجديدة. بعد الفحوص الصارمة فقط، استُخدمت بايتات scaler المرجعي للتوافق مع العقد المثبت، وعدّلت روابط بصمته السبعة داخل نسخة `preprocessing_summary.json`، ثم أُعيد توليد seals بالدالة الأصلية `seal_artefacts`. لم تُعدّل مخرجات `preprocessing/trainval` أو `trainval_replay` أو المصدر الأصلي، ولم تُنسخ مصفوفة تاريخية أو أوزان مدرّبة قديمة كمدخل للتدريب.

الإيصال `ME06_Metadata_Binding.json` داخل المجلد المرتبط، ومن ثم داخل `campaign/frozen/development` وmanifest الحملة. يصرّح بأن **بصمة JSON الخام التاريخية لم تُستعد من الخام**، وأن التمثيل المرجعي للبيانات الوصفية أعيد استخدامه بعد إثبات التطابق الحسابي. يجب إبقاء هذا الاستثناء في أي حكم نهائي عن قابلية إعادة الإنتاج.

عدد التحضير الخام هو **40 ملفًا مدرجًا في manifest + ملفي seal = 42 ملفًا فعليًا**. التوقع الأول في فاحص المقارنة بأن الإجمالي 40 كان خطأ عدّ في الفاحص. المجلد المرتبط يضم إيصالًا إضافيًا، فيصبح 41 ملفًا مدرجًا و43 ملفًا فعليًا. لم تُعالج بيانات ناقصة بهذا التصحيح.

## الأوامر والبيئة

الأوامر التالية لـ **Bash داخل Ubuntu/WSL**. هي توثيق للوصفة وللتشغيل المصرح به، وليست أمرًا بإعادة المراحل المكتملة في المجلد الحالي. المشغلات ترفض وجود المحاولات والمخرجات السابقة؛ لا تحذفها لتجاوز الرفض. تشغيل مستقل جديد يحتاج مجلدًا جديدًا وتجهيز مسارات وإيصالات جديدة موثقة. `bootstrap_environment.py` مرتبط حاليًا بمواقع الأصول في هذا الجهاز؛ نقله إلى جهاز آخر يحتاج تهيئة موثقة لا تغيّر الحساب العلمي.

```bash
ME06_RUN=/home/mai/ehr_me06_reproduction_20261011_v1
ME06_PY="$ME06_RUN/.venv/bin/python"
ME06_CONTROL=/mnt/c/Users/RNO/Desktop/Coureses/P1/ars_me06_execution_2026_10_11
```

### 1. البناء والتثبيت الجديد — نُفّذ بالفعل

أُطلق bootstrap باستخدام Python النظام، قبل وجود مجلد التشغيل:

```bash
/usr/bin/python3.12 -I -B "$ME06_CONTROL/bootstrap_environment.py"
```

نسخ bootstrap المصادر والأصول وفحص بصماتها، ثم شغّل باني Flower المحفوظ `source/validation_support/prg_validation/build.py` على stock wheel `flwr-1.22.0-py3-none-any.whl`. أعاد بناء `flwr-1.22.0+mai.prg7570.1` ببصمة مطابقة لـ candidate المطلوب؛ لم يكتف بإعادة استعمال candidate قديم أو إيصال PASS تاريخي.

بعد إنشاء venv جديدة كانت أوامر التثبيت والفحص:

```bash
"$ME06_PY" -I -B -m pip install --no-index --no-deps --require-hashes --find-links "$ME06_RUN/wheelhouse" -r "$ME06_RUN/full_requirements.lock"
"$ME06_PY" -I -B -m pip check
```

يحوي `wheelhouse` **48 wheel مثبتًا**؛ stock Flower منفصل في `build`، وليس إصدارًا مثبتًا إضافيًا. لا يوجد تنزيل إلزامي أثناء التثبيت المذكور. الإصدارات المهمة المثبتة تشمل NumPy 2.3.5، pandas 2.2.3، PyTorch 2.10.0+cpu، وFlower 1.22.0+mai.prg7570.1. المرجع الكامل هو `full_requirements.lock` و`input_inventory.json` و`receipts/fresh_environment.json`، وليس هذه القائمة المختصرة.

### 2. المعالجة من الخام وإعادة المعالجة — نُفّذت بالفعل

```bash
"$ME06_PY" -I -B "$ME06_RUN/preprocessing_source/scripts/run_stage.py" --source "$ME06_RUN/assets/benchmark.zip" --out "$ME06_RUN/preprocessing" --replay
```

المخرجات الجديدة هي `preprocessing/trainval` و`preprocessing/trainval_replay`. يشترط الإعداد وجود إيصال raw rebuild ناجح وreplay مطابق. قراءة بايتات ملفات الاختبار للتحقق من البصمات والفلترة لا تعني ترميزها للتدريب؛ تسجّل المعالجة الأصلية هذه الحدود، ولا تنتج موترات اختبار أو مقاييس تهديد في هذه المرحلة.

### 3. ربط البيانات الوصفية المعلن — نُفّذ بالفعل

```bash
"$ME06_PY" -I -B "$ME06_RUN/portable/train_bind_metadata.py" --run-root "$ME06_RUN" --source "$ME06_RUN/source" --fresh "$ME06_RUN/preprocessing/trainval" --bound "$ME06_RUN/preprocessing/bound_trainval" --frozen-reference "$ME06_RUN/assets/frozen_reference.zip"
```

هذا المحوّل يقبل الفارق المحدد ببصمة JSON والقيم hex المعروفة فقط؛ ليس تقريبًا عامًا أو سماحًا بفروق أخرى. يفحص فعليًا تطابق ملفات الخام وإعادة المعالجة الـ42، ويفحص جميع المصفوفات الثلاثين، ويقارن summary التاريخي مع الجديد بحيث تختلف روابط scaler السبعة فقط.

### 4. الفحوص وإعداد الحملة — شرط سابق للتدريب

```bash
"$ME06_PY" -I -B "$ME06_RUN/portable/train_reproduction.py" prepare --run-root "$ME06_RUN" --source "$ME06_RUN/source" --campaign "$ME06_RUN/campaign" --prepared "$ME06_RUN/preprocessing/bound_trainval" --frozen-reference "$ME06_RUN/assets/frozen_reference.zip" --preprocessing-receipt "$ME06_RUN/preprocessing/reports/stage_status.json"
```

تشمل المرحلة: مجموعة الاختبارات الأصلية دون skips، وبروتوكول toy العام باستخدام candidate الفعلي، وخمس بدايات جديدة، وعشرة جداول سحب جديدة لـ30 جولة، ومقارنتها بالمرجع، و30 Probe أصلية و20 Probe لنسخ B/C المنقولة، وتجربة هندسية واحدة لـ A. التجربة الهندسية ليست إحدى النتائج الرئيسية الثلاثين. تُحفظ بصمات البيئة الجديدة وتُعاد مقارنتها خلال التشغيل.

### 5. التدريب الكامل، ثم الاختبار، ثم المقارنة — لا يُدّعى نجاحه قبل الإيصالات

المصفوفة المحددة هي A/B/C × reference/noniid × البذور 11/29/47/71/97 = **30 تجربة تدريب**، كل منها 30 epoch/round، حسب `source/protocol/decisions/config/main_run_order.csv`. التقييم النهائي هو كل نموذج × مجموعتي اختبار منفصلتين = **60 خلية تقييم**، وليس 60 تدريبًا جديدًا.

المشغل المتسلسل الجديد المخصص لهذه الحملة:

```bash
"$ME06_PY" -I -B "$ME06_RUN/portable/complete_reproduction.py" --run-root "$ME06_RUN" --adapter-seal "$ME06_RUN/provenance/portable_adapter_seal.json" --export-dir "$ME06_CONTROL"
```

لا يُشغّل هذا الأمر بالتوازي مع أوامر التدريب اليدوية التالية. يبدأ فقط من حملة READY لم تبدأ التدريب. يصدر إيصال TRAIN جديدًا مرتبطًا ببصمتي الحملة والمصدر، وينفذ أول تجربة ويتحقق من توقف مقصود عند حد تجربة مكتملة، ثم يكمل الـ29 المتبقية. هذا ليس إعادة محاولة لتجربة فاشلة. يفحص الثلاثة A/B/C في كل block قبل تدريب أي منها، ولا يعيد المحاولة تلقائيًا عند الفشل أو الانقطاع.

هذه أوامر المراحل التي ينفّذها المشغل، لسهولة التدقيق؛ أسماء إيصالاته الفعلية مبيّنة:

```bash
"$ME06_PY" -I -B "$ME06_RUN/portable/train_reproduction.py" train --run-root "$ME06_RUN" --source "$ME06_RUN/source" --campaign "$ME06_RUN/campaign" --authorisation "$ME06_RUN/campaign/authorisations/ME06_FULL_CHAIN_TRAIN_20261011.json" --max-jobs 1
"$ME06_PY" -I -B "$ME06_RUN/portable/train_reproduction.py" train --run-root "$ME06_RUN" --source "$ME06_RUN/source" --campaign "$ME06_RUN/campaign" --authorisation "$ME06_RUN/campaign/authorisations/ME06_FULL_CHAIN_TRAIN_20261011.json"
```

بعد اكتمال النماذج الثلاثين ومعايرتها على validation فقط، يُغلق `selected_models_manifest.json`، ويتحقق المقيم الأصلي من هويتها وبصمات الأوزان والمعايرة. بعدها فقط يصدر المشغل إيصال الاختبار النهائي المرتبط بذلك الختم. أمره:

```bash
"$ME06_PY" -I -B "$ME06_RUN/portable/evaluate_reproduction.py" --run-root "$ME06_RUN" --receipt "$ME06_RUN/campaign/authorisations/ME06_FULL_CHAIN_FINAL_TESTS_20261011.json" --expected-benchmark-sha256 b551bfdbe515ba40fc5b147163aad619788566062d5e571339aa9ef60d06700e
```

لا يجوز إنشاء إيصال اختبار يعتمد على نماذج غير مكتملة أو معايرة بعد رؤية الاختبار. إذا فشل التقييم بعد فتح البيانات، تبقى حقيقة الفتح والنتائج الجزئية محفوظة؛ لا يصبح الاختبار «لم يُمس» مجددًا.

المقارنة اللاحقة تقرأ النتائج الجديدة والقديمة المحفوظة، ولا تعيد ضبط النماذج أو العتبات:

```bash
"$ME06_PY" -I -B "$ME06_RUN/portable/compare_reproduction.py" --run-root "$ME06_RUN" --reference-assets "$ME06_RUN/reference/original_assets"
```

## ما تقارنه المراجعة، وكيف تفسّر الفرق؟

تُقارن هويات كل نموذج وشرط وبذرة، والبداية والجولة المختارة، وتنسورات النموذج المختار، ودرجات validation ومعايرتها، ودرجة كل جلسة اختبار وترتيبها وقرارات العتبات الثابتة، وجميع المقاييس والتجميعات والفروق المقترنة. يستند الفحص إلى القيم المحفوظة بالدقة الكاملة؛ أرقام Word المقربة وحدها لا تكفي. ملفات المقارنة تشمل `all_60_primary_metric_cells.csv` و`all_seed_means_and_paired_contrasts.csv` وملفات الفروق لكل جلسة، وتقارير المعايرة والتنسورات.

بصمة ملف checkpoint قد تختلف بسبب serialization رغم تطابق التنسورات؛ لذلك تُعرض المقارنتان منفصلتين. الأزمنة والذاكرة تُقاس مجددًا وتُفسّر وصفيًا في نطاق حدود القياس وحمل الجهاز. لا يوجد هامش قبول عام 5%، ولا يُعد تداخل CI أو فرق دون `1e-12` دليل تكافؤ تلقائيًا. حد `1e-12` في فاحص الحسابات هو تشخيص حسابي فقط، وليس معيار نجاح إعادة النموذج أو أهمية عملية.

### ما الذي تضبطه البذور بالفعل؟

| الجزء | ما تثبته الشفرة | ما لا يثبته ذلك وحده |
|---|---|---|
| البدايات والتدريب | [pilot_core/model.py:12](C:/Users/RNO/EHR_GitHub_Handover_v1_0/repository/executed/EHR_FL_Main_Experiments_Package_v1_0_3/app/pilot_core/model.py:12) يثبت Python وNumPy وTorch، ويطلب الخوارزميات الحتمية ويستخدم thread واحدة. جداول السحب والبدايات تُولّد وتُقارن فعليًا. | ليس ضمانًا مستقلًا للتطابق البتي عبر جميع المعالجات أو أنظمة التشغيل أو مكتبات الحساب. |
| A | [main_study/central.py:44](C:/Users/RNO/EHR_GitHub_Handover_v1_0/repository/executed/EHR_FL_Main_Experiments_Package_v1_0_3/main_study/central.py:44) يبدأ بـ `fresh_global`؛ ثم يستخدم الترتيب المجمد والمحسّن والخسارة نفسيهما، وRNG Torch مضبوطًا. | تغيير ترتيب العمليات أو batch boundaries أو البيئة قد يؤثر؛ يجب فحص أول divergence بدل افتراض العشوائية. |
| B وC: التدريب المحلي | [ehr_fedavg/task.py:85](C:/Users/RNO/EHR_GitHub_Handover_v1_0/repository/executed/EHR_FL_Main_Experiments_Package_v1_0_3/app/ehr_fedavg/task.py:85) يعيد seed قبل كل fit. [ehr_secagg/local_task.py:18](C:/Users/RNO/EHR_GitHub_Handover_v1_0/repository/executed/EHR_FL_Main_Experiments_Package_v1_0_3/app/ehr_secagg/local_task.py:18) يشتق seed من البذرة والعميل والجولة ويستعمل kernel نفسه. | لا يُسمح بإرجاع فرق لاحق إلى بذرة مختلفة دون التحقق من القيم المشتقة وتسلسل الاستدعاءات. |
| B: التجميع | [ehr_fedavg/math_checks.py:57](C:/Users/RNO/EHR_GitHub_Handover_v1_0/repository/executed/EHR_FL_Main_Experiments_Package_v1_0_3/app/ehr_fedavg/math_checks.py:57) يرتب العملاء منطقيًا، و[ehr_fedavg/strategy.py:52](C:/Users/RNO/EHR_GitHub_Handover_v1_0/repository/executed/EHR_FL_Main_Experiments_Package_v1_0_3/app/ehr_fedavg/strategy.py:52) يستخدم تجميع Flower الأصلي مع فحصه. | وصول الردود بترتيب شبكي مختلف لا يكفي بذاته لتفسير تغيير المتوسط؛ يُفحص الترتيب المطبق فعليًا. |
| C: stochastic quantization | داخل candidate wheel، `flwr/client/mod/secure_aggregation/secaggplus_mod.py:171–177` ينفّذ fit أولًا، ثم `:464–466` يستدعي quantize. `flwr/common/secure_aggregation/quantization.py:25–32` يستخدم `np.random.rand`. | هذا ليس تلقائيًا مصدر عشوائية غير مضبوط: NumPy أُعيد seed أثناء fit، والنتيجة مرتبطة بحالته وترتيب استدعاءاته. يلزم دليل على اختلاف المسار قبل نسبة فرق المقاييس إلى quantization randomness. |
| C: الأسرار والأقنعة | عضو wheel نفسه `secaggplus_mod.py:381` يستخدم `os.urandom(32)` لبذرة القناع. [ehr_secagg/client_app.py:43](C:/Users/RNO/EHR_GitHub_Handover_v1_0/repository/executed/EHR_FL_Main_Experiments_Package_v1_0_3/app/ehr_secagg/client_app.py:43) يمنع إعادة seed الأسرار أو ترقيع الدوال. | يُتوقع اختلاف الأسرار والرسائل المقنّعة، لكن الإلغاء الصحيح للأقنعة في الحساب الصحيح لا يفترض أن يغير النموذج. اختلاف الأقنعة ليس تفسيرًا تلقائيًا لاختلاف AP أو الأوزان. |

الاستنتاج من تسلسل quantization أعلاه هو تحليل لمسار الشفرة، لا إثبات مسبق لتطابق التشغيل الجديد. عند أي فرق تبقى العلة **UNATTRIBUTED** حتى تُحدّد أول جولة/epoch ذات divergence في digest أو الخسارة، وتُفحص البيئة والمدخلات وترتيب السحب والحساب وRNG والسياسات. تُستخدم أدلة الحالة العالمية والسجلات المسموح بها؛ لا تُصدّر مفاتيح أو أقنعة أو shares أو تحديثات C الفردية الخاصة لإجراء التشخيص.

## حزمة الأدلة الخاصة: ما الذي يُحفظ؟

الاختيار الموصى به هو **حفظ مجلد الحملة كاملًا** إلى جانب المصدر والأصول والقفل والمكتبات والسجلات والمقارنة. فهذا يحفظ `frozen` و`jobs` وجميع المحاولات والفحوص والسجلات وcheckpoints والمنحنيات والمعايرة والدرجات، ويضمن بقاء كل ملف يتطلبه `verify_campaign` والمقيم والمقارن. لا تختصر الحزمة بحذف `jobs` لأنها تبدو نسخة من المدخلات؛ manifest الحملة يتطلب مساراتها.

| مجموعة الملفات | السبب | سياسة الحجم |
|---|---|---|
| `source` و`preprocessing_source` و`portable` | الشفرة الأصلية، الوصفة الجديدة، بناء Flower والفحوص | تحفظ كاملة مع manifests وبصمات المحوّلات |
| `full_requirements.lock` و`wheelhouse` و`build` | إعادة تثبيت offline وبناء candidate من stock | لا تحفظ `.venv`؛ تحفظ wheels الـ48 والقفل وstock ووصفة البناء والإيصالات |
| `assets` و`reference/original_assets` | CSV الخام والمراجع الأصلية اللازمة لمقارنة الأوزان والدرجات والمقاييس | خاصة محليًا؛ وجودها لا يعني سماح النشر العام |
| `preprocessing` | المخرجات الخام وإعادتها والمجلد المرتبط والفرق التشخيصي وإيصالاته | تحفظ الثلاثة؛ لا تستبدل الخام بالمجلد المرتبط |
| `campaign` كاملًا | كافة مدخلات seal والمحاولات والنتائج والأدلة الجزئية عند الفشل | قد يتضمن نسخ reports مشتقة؛ تحفظ أولًا، ثم يدرس اختصار مستقل موثق إذا لزم |
| `logs/receipts/provenance/full_chain/comparison` | أوامر التشغيل، exit codes، الحالات، المراجعة، مقارنة الدقة الكاملة | تحفظ كاملة؛ لا يحذف الفشل أو يُستبدل بإيصال ناجح |
| ملفات التحكم وهذا الدليل | bootstrap، الفاحص، سجل التعديلات والقيود | أرشيف تحكم صغير منفصل لتجنب التباس الجذور |

كثير من مصفوفات الحملة hard-linked داخل مجلد التشغيل الجديد. مجموع أحجام المسارات **logical bytes** قد يتجاوز حجم البيانات الفريدة **unique inode bytes**. GNU tar يحفظ hardlinks افتراضيًا؛ لا تستخدم `--hard-dereference` الذي قد يضاعف المحتوى. يجب أن تبقى مسارات الروابط داخل الشجرة نفسها بعد فك الأرشيف، وتُعاد مقارنة البصمات. لا يُعطى حجم نهائي تقديري قبل الجرد الفعلي بعد انتهاء التشغيل.

### جرد الحجم فقط أثناء العمل

[create_private_bundle_inventory.py](C:/Users/RNO/Desktop/Coureses/P1/ars_me06_execution_2026_10_11/create_private_bundle_inventory.py) يكتب فهرسًا صغيرًا فقط، ولا ينسخ أو يضغط المحتويات ولا ينشرها. يمكن طلب لقطة حجم أثناء التشغيل:

```bash
/usr/bin/python3.12 -I -B "$ME06_CONTROL/create_private_bundle_inventory.py" --run-root "$ME06_RUN" --control-dir "$ME06_CONTROL" --output-dir "$ME06_CONTROL/bundle_budget_snapshot" --budget-only
```

تُصنف هذه اللقطة `DRAFT_SIZE_SNAPSHOT_NOT_FINAL_EVIDENCE`، لأن الحملة ما زالت تنتج ملفات. يجب اختيار output جديد إذا كان مجلد اللقطة موجودًا؛ لا تُحذف اللقطة السابقة بصمت.

### الجرد النهائي قبل أي ضغط كبير

بعد انتهاء المشغل نهائيًا واكتمال جميع تقارير التحكم، وعدم وجود كتابة مستمرة:

```bash
/usr/bin/python3.12 -I -B "$ME06_CONTROL/create_private_bundle_inventory.py" --run-root "$ME06_RUN" --control-dir "$ME06_CONTROL" --output-dir "$ME06_CONTROL/private_bundle_inventory_final"
```

يشترط هذا الجرد حالة مشغل نهائية ناجحة **أو فشلًا محفوظًا**؛ الحالة النهائية للفشل لا تُسمّى نجاحًا. يمسك قفل المشغل الفعلي دون انتظار، ويرفض العمل إن كان المشغل لا يزال يكتب ملفاته النهائية. يتحقق من مصادر manifests، وكل مدخلات حملة seal، والنماذج والمعايرة إن وجدت، وكل ملفات seal التقييم إن وجد. يحسب SHA-256، ويرفض الملفات التي تغيرت أثناء الجرد أو إضافة/حذف ملف من المجموعة المحددة. ينتج `Private_Bundle_Inventory.json` وقائمتي ملفات NUL آمنتين للأرشفة؛ يستثني `.venv` وbytecode وملفات lock التشغيلية فقط من شجرة التشغيل، ويحتفظ بجميع النتائج العلمية.

**الأوامر التالية تصميم للأرشفة اللاحقة؛ لم تُنفّذ عند إعداد هذا الدليل.** تنشئ أرشيف الأدلة وأرشيف التحكم منفصلين، وتستخدم القوائم التي جرى التحقق منها:

```bash
tar --create --gzip --file "$ME06_CONTROL/ME06_Run_Evidence_Private.tar.gz" --directory "$ME06_RUN" --null --verbatim-files-from --files-from "$ME06_CONTROL/private_bundle_inventory_final/RunRoot_Files.nul"
tar --create --gzip --file "$ME06_CONTROL/ME06_Controls_Private.tar.gz" --directory "$ME06_CONTROL" --null --verbatim-files-from --files-from "$ME06_CONTROL/private_bundle_inventory_final/Control_Files.nul" -- private_bundle_inventory_final/Private_Bundle_Inventory.json private_bundle_inventory_final/RunRoot_Files.nul private_bundle_inventory_final/Control_Files.nul
sha256sum "$ME06_CONTROL/ME06_Run_Evidence_Private.tar.gz" "$ME06_CONTROL/ME06_Controls_Private.tar.gz"
```

يلزم قبل الأرشفة النهائية تأكيد أن الاسمين غير موجودين، وتجميد الكتابة على الشجرة حتى انتهاء الأرشفة. لا تُستبدل أرشيفات سابقة. يضم أرشيف التحكم فهرس الجرد وقائمتيه صراحةً؛ ليس للفهرس بصمة ذاتية دائرية، وتربطه بصمة الأرشيف ببياناته. بعد فكها في موقع منفصل، تُعاد بصمات فهرس الحزمة وتحقق المصادر والحملة والنماذج/التقييم؛ نجاح إنشاء tar وحده لا يثبت سلامة محتوياته.

هذه حزمة أدلة **خاصة**. لا تتضمن الوصفة رفعًا إلى GitHub أو أي خدمة، ولا تمنح تصريح إعادة توزيع للبيانات. يمكن لاحقًا تصميم نسخة أخف أو نسخة مشاركة بعد مراجعة الترخيص والخصوصية وكل dependencies الخاصة بالـ manifests؛ لا تُحذف الملفات الأصلية لتحقيق ذلك.

## شرط الحكم النهائي على ME-06

لا تُغلق النقطة لمجرد أن البرنامج يعمل أو أن بعض المتوسطات قريبة. يُعرض: هل اكتملت التجارب الثلاثون والتقييم الستون؟ هل اجتازت أدلة المصدر والمدخلات والبيئة؟ أين تطابقت القيم تمامًا وأين اختلفت؟ هل فُسرت الفروق بدليل أم بقيت UNATTRIBUTED؟ ثم يُحدد نطاق النتيجة على اللقطة الثابتة والجهاز نفسه، مع استثناء JSON المعلن. لا يثبت هذا العمل تلقائيًا الصلاحية السريرية للوسوم، أو التعميم الخارجي، أو ضمان الخصوصية، أو التكافؤ/عدم الدونية، أو صلاحية نشر البيانات.
