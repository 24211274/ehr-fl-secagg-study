# Independent completion evidence QA

**PASS** — all 30 fresh training jobs and 60 final evaluation cells completed. The outer runner and all four stage receipts exited zero. Completion time: `2026-10-11T02:39:58.560261+00:00`.

Read-only verification checked the preserved 215-file scientific source, 84-file preprocessing source, 2,884 campaign members, all 30 selected checkpoint/calibration/validation-score hashes, 130 final-evaluation members and 104 comparison members. The six exported Windows evidence files match their Linux originals by SHA-256.

An independent scan of all 90,270 saved comparison rows found exact raw/calibrated scores, ranks and alert decisions at all three fixed quantiles. The sealed model diagnostics report all 30 initial/selected tensor states and validation score sets exact; no model inference or recalibration was performed by this reviewer.

The exactness statement concerns predictive numerical results. Resource measurements differ. Across ten cells per method:

| Method | Historical mean elapsed seconds | Fresh mean elapsed seconds | Descriptive change |
|---|---:|---:|---:|
| A | 302.458 | 353.596 | +16.907% |
| B | 835.431 | 916.955 | +9.758% |
| C | 1385.833 | 1467.833 | +5.917% |

A and B/C have different elapsed measurement scopes. C application-fit-record byte changes range from −90 to +180 across its ten cells; B's corresponding bytes are unchanged. These are descriptive observations without an established causal explanation or isolated cryptographic-cost estimate.

Raw preprocessing and its current replay remain identical across all 42 files, and all 30 fresh arrays remain byte-identical to the historical reference. Historical scaler metadata retains the disclosed single float64 ULP difference at `client_summaries[2].M2[1]`: `117745.299590386` versus `117745.29959038601`. All applied transformations and other scaler values are exact; historical scaler JSON bytes were explicitly reused only in the separately sealed compatibility view. Complete historical raw metadata byte reproduction is not claimed, and the cause remains unattributed.

This establishes the completed replay and exact predictive numerical reproduction on the supplied fixed CSV snapshot in a fresh Python environment on the same WSL host. It does not establish independent external-host replication, original data-generator recreation, clinical label validity, external generalization, privacy certification or public redistribution rights.

No packages, training, scoring, recalibration, re-evaluation or scientific edits were performed by this reviewer. Next steps are to preserve the final private evidence inventory and update the thesis/audit ME-06 wording with these results and explicit limits.
