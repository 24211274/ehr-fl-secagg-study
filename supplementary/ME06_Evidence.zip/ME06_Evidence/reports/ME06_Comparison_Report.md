# ME-06 fresh-run comparison

**Status:** ME06_COMPARISON_COMPLETE_EXACT_REPORTED_VALUES

The comparison covers 30 freshly trained selected models, all 60 final metric cells, all three fixed validation quantiles, 90,270 test score rows, calibration values, and every prespecified paired seed endpoint. Raw labels and session identities are joined exactly; no inner join, score-direction reversal or test retuning was used.

| Check | Finding |
|---|---:|
| Unequal test metric leaves | 0 |
| Unequal calibration leaves | 0 |
| Unequal paired-summary leaves | 0 |
| Unequal raw test score rows | 0 |
| Unequal calibrated test score rows | 0 |
| q=.99 alert decision flips | 0 |
| Changed selected rounds | 0 |
| Changed initial tensor states | 0 |
| Selected tensor comparisons available | 30/30 |
| Changed selected tensor states | 0 |

Exact equality is distinguished from the 1e-12 arithmetic diagnostic. No generic percentage tolerance, equivalence conclusion, or explanation by randomness is inferred from these diagnostics. Checkpoint serialization SHA is separate from the numerical tensor state digest. New timing is descriptive, not an equality target.

## Global Average Precision (all five original seeds)

| Condition/test | Method | Reference mean | Fresh mean | Difference |
|---|---|---:|---:|---:|
| reference/test_held_out | A | 0.48581136589175261 | 0.48581136589175261 | 0 |
| reference/test_held_out | B | 0.41613971822557411 | 0.41613971822557411 | 0 |
| reference/test_held_out | C | 0.42079141735531278 | 0.42079141735531278 | 0 |
| reference/test_known | A | 0.47664207910765272 | 0.47664207910765272 | 0 |
| reference/test_known | B | 0.40245435011432601 | 0.40245435011432601 | 0 |
| reference/test_known | C | 0.40399724162878486 | 0.40399724162878486 | 0 |
| noniid/test_held_out | A | 0.40548265573086789 | 0.40548265573086789 | 0 |
| noniid/test_held_out | B | 0.42930873813359283 | 0.42930873813359283 | 0 |
| noniid/test_held_out | C | 0.42944788221099528 | 0.42944788221099528 | 0 |
| noniid/test_known | A | 0.47240534491341102 | 0.47240534491341102 | 0 |
| noniid/test_known | B | 0.41070509415546086 | 0.41070509415546086 | 0 |
| noniid/test_known | C | 0.41128659445672761 | 0.41128659445672761 | 0 |

## Evidence and interpretation limits

- `all_60_primary_metric_cells.csv`: per-seed primary metrics and exact count/decision changes.
- `all_seed_means_and_paired_contrasts.csv`: all endpoints, SDs and the original exploratory intervals.
- `metric_and_calibration_unequal_leaves.csv`: every unequal metric/calibration/paired field.
- `test_per_session/`: raw/calibrated scores, ranks and three threshold decisions for every test row.
- `all_model_and_validation_comparisons.json`: selected rounds, serialization hashes, tensor errors and validation diagnostics.
- `new_vs_historical_system_costs_descriptive.csv`: newly measured costs compared descriptively with the historical run.

This tests the fixed raw snapshot in a newly created Python environment on the same machine. It does not establish a new independent clinical/security validation of labels, public redistribution rights, the unavailable original data generator, external-data generalization, or independent external-host reproducibility. Any observed numeric difference needs separately evidenced investigation; it is not automatically attributed to a random seed or environment.
